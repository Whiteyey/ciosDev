function readURL(input, imgdrag) {
	if (input.files && input.files[0]) {
		var reader = new FileReader();

		reader.onload = function(e) {
			$('#' + imgdrag).attr('src', e.target.result)
		};

		reader.readAsDataURL(input.files[0]);
	}
}

function operateFormatterSend(value, row, index) {
	return [ '<button  name="btnSendRow" class="fa fa-refresh grayIcon btnSendRow" type="button"></button>' ]
	.join('');
}

function operateFormatterDelete(value, row, index) {
	return [ '<button  name="btnDeleteRow" class="fa fa-trash grayIcon btnDeleteRow" onclick="confirmDeleteRow('+row.id+')" type="button"></button>' ]
	.join('');
}

function operateFormatterEdit(value, row, index) {
	return [ '<button  name="btnDeleteRow" class="fa fa-pencil-square-o grayIcon btnEditRow" onclick="editE('+row.id+')" type="button"></button>' ]
	.join('');
}

function operateFormatterMove(value, row, index) {
	return [ '<button  name="btnDeleteRow" class="fa fa-refresh grayIcon btnMoveRow" onclick="assign('+row.id+')" type="button"></button>' ]
	.join('');
}

function operateFormatterMessage(value, row, index) {
	return [ '<button  name="btnDeleteRow" class="fa fa-envelope-o grayIcon btnMessageRow" type="button"></button>' ]
	.join('');
}