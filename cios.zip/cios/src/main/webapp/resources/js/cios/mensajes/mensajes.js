//variables para mensajes
var $table = $('#tableMessages');

//funciones para mensajes
$(function () {
	/*Funcion para checar todos los checkboxes*/
    $("#checkAll").change(function () {
        $("input:checkbox").prop('checked', $(this).prop("checked"));
    });

    /*Cuenta los caracteres de un textarea y actualiza el contador de la pagina*/
    $("#messageID").keyup(function () {
    	var total = $(this).val().length;
    	$("#characterCounter").html("("+total + "/1000)");
    });
    
    $('#tableMessages').bootstrapTable(); // init via javascript
    setInterval(function(){
    	$('#tableMessages').bootstrapTable('resetView');
	},500);
});

/*funcion para borrar un mensaje*/
function confirmDeleteRow(index){
	 pages.showConfirm('', '&iquest;Est&aacute; seguro de eliminar el mensaje?', index);
}
function deleteRow(index){
	var jSONObject = {};
	jSONObject["id"] = index;
	
	$.ajax({
		 
		 url: app.appWebContextRoot+"deleteMessage",
		 data: JSON.stringify(jSONObject),
		 type: "POST",
		 headers: {
		        'Accept': 'application/json',
		        'Content-Type': 'application/json' 
		    },
		 success : function(json) {
		    	$('#tableMessages').bootstrapTable('refresh');
			 pages.showSuccess('', 'Mensaje eliminado');
		 },
		
		 error : function(xhr, status) {
			 pages.showError('', 'El mensaje no pudo ser eliminado');
		 },
			  
		 });
}
/*Funcion para obtener los datos del mensaje*/
function sendMessage() {
	var title = $('#messageTitle').val();
	var message = $('#messageID').val();
	var destinatarios = "";
	if($("#checkSupervisores").is(':checked')) {  
		destinatarios += "supervisores";  
    }
	if($("#checkClientes").is(':checked')) {
		if(destinatarios == ""){
			destinatarios += "clientes";  
		}
		destinatarios = "todos"
    }
	
	if(destinatarios == ""){
		pages.showError('Error al enviar', 'Seleccione un destinatario'); 
	}

	//se crea el objeto json
	var jSONObject = {};
	
	jSONObject["title"] = title;
	jSONObject["message"] = message;
	jSONObject["destinatarios"] = destinatarios;

	 $.ajax({
		 
	 url: app.appWebContextRoot+"sendMessage",
	 data: JSON.stringify(jSONObject),
	 type: "POST",
	 headers: {
	        'Accept': 'application/json',
	        'Content-Type': 'application/json' 
	    },
	 success : function(json) {
		 pages.showSuccessRedirect('', 'Mensaje enviado');
	 },
	
	 error : function(xhr, status) {
		 pages.showError('', 'El mensaje no pudo ser enviado');
	 },
		  
	 });
}

function redirect() {
	window.location = app.appWebContextRoot+"mensajes";
}
