$(document).keypress(function(e) {
    if(e.which == 13) {
        entrar();
    }
});
function entrar() {
	//window.location = app.appWebContextRoot + 'main/';
	
	var thedata = $("#Login").serialize();
	var data={};
	data['login']= $('#username').val();
	data['password']= $('#password').val();

	$.ajax({
		type : 'POST',
		url : app.appWebContextRoot + 'userAuthWs/',
		cache : false,
		 headers: {
		        'Accept': 'application/json',
		        'Content-Type': 'application/json' 
		    },
		data:JSON.stringify(data),
		beforeSend : function() {
			pages.showPleaseWait();
		},
		success : function(data) {
			
			if (data.estatus) {
					window.location = app.appWebContextRoot + 'main/'
			} else {
				pages.showNotLogin();
			}
		},
		error : function(jqXHR, textStatus, errorThrown) {
			pages.showError(textStatus,errorThrown);
		}
	});

};
