$(function(){

	getClientsData(0);
	 
	/*Funcion para checar si fue elegido el tab de guardias*/
    $("#guards").click(function () {
    	$("#guards").addClass("active_tab_button");
    	$("#scorts").addClass("inactive_tab_button");
    	$("#drivers").addClass("inactive_tab_button");

    	$("#guards").removeClass("inactive_tab_button");
    	$("#scorts").removeClass("active_tab_button");
    	$("#drivers").removeClass("active_tab_button");

    	$('#tableElements').bootstrapTable('refresh', {
    	    url: 'elementos/elementosDataGuards'
    	});
    });

	/*Funcion para checar si fue elegido el tab de escoltas*/
    $("#scorts").click(function () {
    	$("#guards").addClass("inactive_tab_button");
    	$("#scorts").addClass("active_tab_button");
    	$("#drivers").addClass("inactive_tab_button");

    	$("#guards").removeClass("active_tab_button");
    	$("#scorts").removeClass("inactive_tab_button");
    	$("#drivers").removeClass("active_tab_button");
    	
    	$('#tableElements').bootstrapTable('refresh', {
    	    url: 'elementos/elementosDataScorts'
    	});
    });

	/*Funcion para checar si fue elegido el tab de conductores*/
    $("#drivers").click(function () {
    	$("#guards").addClass("inactive_tab_button");
    	$("#scorts").addClass("inactive_tab_button");
    	$("#drivers").addClass("active_tab_button");

    	$("#guards").removeClass("active_tab_button");
    	$("#scorts").removeClass("active_tab_button");
    	$("#drivers").removeClass("inactive_tab_button");

    	$('#tableElements').bootstrapTable('refresh', {
    	    url: 'elementos/elementosDataDrivers'
    	});
    });
    
    $('#tableMessages').bootstrapTable(); // init via javascript
    setInterval(function(){
    	$('#tableElements').bootstrapTable('resetView');
	},500);
});

function changeClassification(){
    var classify = document.getElementById("type").value;
    var newClassify = "";
    
    switch(classify){
    case "Cucarma":
		newClassify = "60200";
    	break;
    case "Cusarma":
		newClassify = "60300";
    	break;
    case "Esconductor":
		newClassify = "10100-003";
    	break;
	default:
		newClassify = "10200-001";
		break;
    }
    document.getElementById("classification").value = newClassify;
}

/*funcion para borrar un mensaje*/
function confirmDeleteRow(index){
	 pages.showConfirm('', '&iquest;Est&aacute; seguro de borrar al usuario?', index);
}

function confirmAssignElement(){
	 pages.showConfirmUpdate('', '&iquest;Est&aacute; seguro de asignar al usuario?');
}

function updateData(){
	var jSONObject = {};

	var idElement = $('#clave').val();
	var selection = document.getElementById( "clients" );
	var idClient = selection.options[selection.selectedIndex].value;
	var selectionTurn = document.getElementById( "turn" );
	var turn = selectionTurn.options[selectionTurn.selectedIndex].value;
	
	jSONObject["idElement"] = idElement;
	jSONObject["giro"] = turn;
	jSONObject["idCliente"] = selection.value;
	
	$.ajax({
		 
		 url: app.appWebContextRoot+"updateRelElement",
		 data: JSON.stringify(jSONObject),
		 type: "POST",
		 headers: {
		        'Accept': 'application/json',
		        'Content-Type': 'application/json' 
		    },
		 success : function(json) {
			    pages.showSuccessRedirect('', 'Elemento asignado satisfactoriamente');
		 },
		
		 error : function(xhr, status) {
			 pages.showError('', 'El elemento no pudo ser asignado');
		 },
			  
		 });
}

/*funcion para borrar un elemento*/
function deleteRow(index){
	var jSONObject = {};
	jSONObject["id"] = index;
	
	$.ajax({
		 
		 url: app.appWebContextRoot+"deleteElement",
		 data: JSON.stringify(jSONObject),
		 type: "POST",
		 headers: {
		        'Accept': 'application/json',
		        'Content-Type': 'application/json' 
		    },
		 success : function(json) {
		    	$('#tableMessages').bootstrapTable('refresh');
			 pages.showSuccess('', 'Elemento eliminado');
		 },
		
		 error : function(xhr, status) {
			 pages.showError('', 'El elemento no pudo ser eliminado');
		 },
			  
		 });
}

function addElement(){
	var jSONObject = {};
	
	/*Datos del elemento*/
	var id = $('#clave').val();
	var tipo = document.getElementById("type").value;
	var clasificacion = $('#classification').val();
	var estatus = document.getElementById("estatus").value;
	var alta = $('#alta').val();
	var dotacion = $('#dotacion').val();
	var turn = document.getElementById("turn").value;

	jSONObject["id"] = id;
	jSONObject["clasificacion"] = clasificacion;
	jSONObject["tipo"] = tipo;
	jSONObject["estatus"] = estatus;
	jSONObject["alta"] = alta;
	jSONObject["dotacion"] = dotacion;
	jSONObject["turn"] = turn;
	
	/*Datos personales*/
	var nombre = $('#nombre').val();
	var apellidop = $('#apellidop').val();
	var apellidom = $('#apellidom').val();
	var direccion = $('#direccion').val();
	var telefono = $('#telefono').val();
	var imss = $('#imss').val();
	var nombrec = $('#nombrec').val();
	var direccionc = $('#direccionc').val();
	var telefonoc = $('#telefonoc').val();
	
	var foto = "";

	jSONObject["nombre"] = nombre;
	jSONObject["apellidoP"] = apellidop;
	jSONObject["apellidoM"] = apellidom;
	jSONObject["imss"] = imss;
	jSONObject["direccion"] = direccion;
	jSONObject["telefono"] = telefono;
	jSONObject["nombreContacto"] = nombrec;
	jSONObject["direccionContacto"] = direccionc;
	jSONObject["telefonoContacto"] = telefonoc;

	jSONObject["foto"] = foto;

	 $.ajax({
		 
	 url: app.appWebContextRoot+"addElement",
	 data: JSON.stringify(jSONObject),
	 type: "POST",
	 headers: {
	        'Accept': 'application/json',
	        'Content-Type': 'application/json' 
	    },
	 success : function(json) {
		 pages.showSuccessRedirect('', 'El usuario se dio de alta satisfactoriamente');
	 },
	
	 error : function(xhr, status) {
		 pages.showError('', 'El usuario no pudo ser dado de alta');
	 },
		  
	 });
}

function redirect() {
	window.location = app.appWebContextRoot+"elementos";
}

function assign(id){
	window.location = app.appWebContextRoot+"elementos/asignar?id="+id;
}

function editE(id){
	window.location = app.appWebContextRoot+"editarElemento?id="+id;
}

function getClientsData(pos){
	var selection = document.getElementById( "clients" );
	if(pos != 0){
		pos = selection.selectedIndex;
	}
	$.ajax({
		type : 'POST',
		url : app.appWebContextRoot + 'clientesData',
		cache : false,
		data : null,
		beforeSend : function() {
			
		},
		success : function(data) {
			document.getElementById("direction").value = data.data[pos].direccion;
			document.getElementById("contact").value = data.data[pos].correoElectronico + ",   Tel: " + data.data[pos].telefono;
			document.getElementById("admin").value = data.data[pos].director;

			$("#clients option").remove();
			$.each(data.data, function(key, value){
				if(key == pos){
					$("#clients").append("<option value="+value.idCliente+" selected>"+value.nombre+"</option>");
				}else{
					$("#clients").append("<option value="+value.nombre+">"+value.nombre+"</option>");
				}
			});
		},
		error : function() {
			
		}
	});
}

function validateClave(e){
    key = (document.all) ? e.keyCode : e.which;

    //Tecla de retroceso para borrar, siempre la permite
    if (key==8){
        return true;
    }

	var nombre = $('#clave').val();
	if(nombre.length > 7){
        return false;
	}
    // Patron de entrada, en este caso solo acepta numeros
    patron =/[0-9]/;
    tecla_final = String.fromCharCode(key);
    return patron.test(tecla_final);
}

function validateCharacters(e){
    key = (document.all) ? e.keyCode : e.which;

    //Tecla de retroceso para borrar, siempre la permite
    if (key==8){
        return true;
    }

    tecla_final = String.fromCharCode(key);
    
    var reg = /[A-Za-zñÑ\s]/;

    return reg.test(tecla_final);
}

function validatePhone(e){
    key = (document.all) ? e.keyCode : e.which;

    //Tecla de retroceso para borrar, siempre la permite
    if (key==8){
        return true;
    }

	var nombre = $('#clave').val();
	if(nombre.length > 9){
        return false;
	}
    // Patron de entrada, en este caso solo acepta numeros
    patron =/[0-9]/;
    tecla_final = String.fromCharCode(key);
    return patron.test(tecla_final);
}

function validateImss(e){
    key = (document.all) ? e.keyCode : e.which;

    //Tecla de retroceso para borrar, siempre la permite
    if (key==8){
        return true;
    }

	var nombre = $('#imss').val();
	if(nombre.length > 11){
        return false;
	}
    // Patron de entrada, en este caso solo acepta numeros
    patron =/[0-9\-]/;
    tecla_final = String.fromCharCode(key);
    return patron.test(tecla_final);
}

function changeClientData(){
    getClientsData(document.getElementById("clients").id);
}