/*Carga los clientes*/
$(document).ready(function() {
	$.ajax({
		type : 'POST',
		url : app.appWebContextRoot + 'clientesData',
		cache : false,
		data : null,
		beforeSend : function() {
			
		},
		success : function(data) {
			if (data.estatus) {
				loadClients(data.data);
				loadClient(data.data);
			} else {}
		},
		error : function() {
			
		}
	});
});

/* Funcion para obtener los datos del mensaje */
function addNewClient() {
	var name = $('#name').val();
	var ra = $('#ra').val();
	var giro = $('#giro').val();
	var direction = $('#direction').val();
	var rfc = $('#rfc').val();
	var phone = $('#phone').val();
	var email = $('#email').val();
	var director = $('#director').val();

	var img1 = $('#dropImage1').val();
	var img2 = $('#dropImage2').val();
	var img3 = $('#dropImage3').val();

	// se crea el objeto json
	var jSONObject = {};

	jSONObject["nombre"] = name;
	jSONObject["telefono"] = phone;
	jSONObject["correoElectronico"] = email;
	jSONObject["giro"] = giro;
	jSONObject["director"] = director;
	jSONObject["direccion"] = direction;
	jSONObject["rfc"] = rfc;
	jSONObject["ra"] = ra;

	jSONObject["logoA"] = img1;
	jSONObject["logoB"] = img2;
	jSONObject["logoC"] = img3;

	$.ajax({

		url : app.appWebContextRoot + "addClient",
		data : JSON.stringify(jSONObject),
		type : "POST",
		headers : {
			'Accept' : 'application/json',
			'Content-Type' : 'application/json'
		},
		success : function(json) {
			 pages.showSuccessRedirect('', 'Cliente agregado');
		},

		error : function(xhr, status) {
			console.log("no pasa", xhr);
			// pages.showSuccessAlertRedirect('', 'Mensaje no enviado');
		},

	});
}

function redirect() {
	window.location = app.appWebContextRoot+"clientes";
}

function loadClients(data){
	var body = "";
	for(i=0; i<data.length; i++){
		body +=
		"<div class='col-md-4 left_clients'> "
		+ "<a href='/cios/clientes/details?id="+data[i].idCliente+"'> "
		+ "<img class='imageClient' src='"+data[i].logoA+"'></a> "
		+ "</div>"
		+ "";
	}
	
	$("#ClientList").html(body)
}

function loadClient(data){
	var id = Request.parameter('id');
	var clientData;
	
	for(i=0; i<data.length; i++){
		if(data[i].idCliente == id){
			clientData =
				"<img class='imageClient' "
				+ "src='"+data[i].logoA+"'/> "
				
				+"<p class='title_medium'>Direcci&oacute;n</p>"
				+"<p class='text_simple_small'>"+data[i].direccion+"</p>"
				
				+"<p class='title_medium'>Contacto</p>"
				+"<p class='text_simple_small'>"+data[i].correoElectronico+" "+data[i].telefono+"</p>"
				
				+"<p class='title_medium'>Administrador</p>"
				+"<p class='text_simple_small'>"+data[i].director+"</p>"
				
				+"<div class='col-md-4'>"
				+"	<a href='"+app.appWebContextRoot+"clientes/asistencia?id="+data[i].idCliente+"'><img class='imageElementButton'" 
				+"	src='"+app.appWebContextRoot+"/resources/img/elementos/guards_1.png'>"
				+"	<p class='title_medium'>Guardias</p></a>"
				+"</div>"
				+"<div class='col-md-4'>"
				+"	<a href='"+app.appWebContextRoot+"clientes/asistencia?id="+data[i].idCliente+"'><img class='imageElementButton' "
				+"	src='"+app.appWebContextRoot+"/resources/img/elementos/scorts_1.png'>"
				+"	<p class='title_medium'>Escoltas</p></a>"
				+"</div>"
				+"<div class='col-md-4'>"
				+"	<a href='"+app.appWebContextRoot+"clientes/asistencia?id="+data[i].idCliente+"'><img class='imageElementButton' "
				+"	src='"+app.appWebContextRoot+"/resources/img/elementos/drivers_1.png'>"
				+"	<p class='title_medium'>Conductores</p></a>"
				+"</div>"
		}
	}

	$("#client_data_container").html(clientData);
}

/*funcion para obtener parametros*/
var Request = {
	    parameter: function(name) {
	      return this.parameters()[name];
	    },
	    parameters: function(uri) {
	      var i, parameter, params, query, result;
	      result = {};
	      if (!uri) {
	        uri = window.location.search;
	      }
	      if (uri.indexOf("?") === -1) {
	        return {};
	      }
	      query = uri.slice(1);
	      params = query.split("&");
	      i = 0;
	      while (i < params.length) {
	        parameter = params[i].split("=");
	        result[parameter[0]] = parameter[1];
	        i++;
	      }
	      return result;
	    }
	  };