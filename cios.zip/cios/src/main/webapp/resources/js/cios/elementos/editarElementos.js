$(function(){
	
});

function confirmEditElement(){
	 pages.showConfirmEdit('', '&iquest;Est&aacute; seguro de modificar al elemento?');
}

function editElement(){
	var jSONObject = {};

	var idElement = $('#clave').val();
	var classify = $('#classify').val();
	var status = $('#status').val();
	var alta = $('#alta').val();
	var dotacion = $('#dotacion').val();
	var selection = document.getElementById( "type" );
	var type = selection.options[selection.selectedIndex].value;
	var turn = document.getElementById("turn").value;
	
	jSONObject["id"] = idElement;
	jSONObject["clasificacion"] = classify;
	jSONObject["estatus"] = status;
	jSONObject["alta"] = alta;
	jSONObject["dotacion"] = dotacion;
	jSONObject["tipo"] = type;
	jSONObject["turn"] = turn;

	var nombre = $('#nombre').val();
	var apellidoP = $('#apellidop').val();
	var apellidoM = $('#apellidom').val();
	var direccion = $('#direccion').val();
	var telefono = $('#telefono').val();
	var imss = $('#imss').val();
	var nombreContacto = $('#nombrec').val();
	var direccionContacto = $('#direccionc').val();
	var telefonoContacto = $('#telefonoc').val();

	jSONObject["nombre"] = nombre;
	jSONObject["apellidoP"] = apellidoP;
	jSONObject["apellidoM"] = apellidoM;
	jSONObject["direccion"] = direccion;
	jSONObject["telefono"] = telefono;
	jSONObject["imss"] = imss;
	jSONObject["nombreContacto"] = nombreContacto;
	jSONObject["direccionContacto"] = direccionContacto;
	jSONObject["telefonoContacto"] = telefonoContacto;
	
	$.ajax({
		 
		 url: app.appWebContextRoot+"updateElement",
		 data: JSON.stringify(jSONObject),
		 type: "POST",
		 headers: {
		        'Accept': 'application/json',
		        'Content-Type': 'application/json' 
		    },
		 success : function(json) {
			    pages.showSuccessRedirect('', 'Elemento editado satisfactoriamente');
		 },
		
		 error : function(xhr, status) {
			 pages.showError('', 'El elemento no pudo ser editado');
		 },
			  
		 });
}


function changeClassification(){
    var classify = document.getElementById("type").value;
    var newClassify = "";
    
    switch(classify){
    case "Cucarma":
		newClassify = "60200";
    	break;
    case "Cusarma":
		newClassify = "60300";
    	break;
    case "Esconductor":
		newClassify = "10100-003";
    	break;
	default:
		newClassify = "10200-001";
		break;
    }
    document.getElementById("classify").value = newClassify;
}