//variables para reportes
var $table = $('#tableReports');

//funciones para reportes
$(function () {
    $('#tableReports').bootstrapTable(); // init via javascript
    setInterval(function(){
    	$('#tableReports').bootstrapTable('resetView');
	},500);
});

/*Funcion para obtener los datos del mensaje*/
function sendReport() {
	var supervisor = $('#supervisor').val();
	var client = $('#client').val();
	var type = $('#type').val();
	var comments = $('#comments').val();
	var date = $('#dateTime').val();
	
	//se crea el objeto json
	var jSONObject = {};
	
	jSONObject["supervisor"] = supervisor;
	jSONObject["client"] = client;
	jSONObject["type"] = type;
	jSONObject["comments"] = comments;
	jSONObject["date"] = date;

	 $.ajax({
		 
	 url: app.appWebContextRoot+"sendReport",
	 data: JSON.stringify(jSONObject),
	 type: "POST",
	 headers: {
	        'Accept': 'application/json',
	        'Content-Type': 'application/json' 
	    },
	 success : function(json) {
		 pages.showSuccessRedirect('', 'Reporte enviado');
	 },
	
	 error : function(xhr, status) {
		 pages.showError('', 'El reporte no pudo ser enviado');
	 },
		  
	 });
}

/*funcion para borrar un reporte*/
function confirmDeleteRow(index){
	 pages.showConfirm('', '&iquest;Est&aacute; seguro de eliminar el reporte?', index);
}
function deleteRow(index){
	var jSONObject = {};
	jSONObject["id"] = index;
	
	$.ajax({
		 
		 url: app.appWebContextRoot+"deleteReport",
		 data: JSON.stringify(jSONObject),
		 type: "POST",
		 headers: {
		        'Accept': 'application/json',
		        'Content-Type': 'application/json' 
		    },
		 success : function(json) {
		    	$('#tableReports').bootstrapTable('refresh');
			 pages.showSuccess('', 'Reporte eliminado');
		 },
		
		 error : function(xhr, status) {
			 pages.showError('', 'El reporte no pudo ser eliminado');
		 },
			  
		 });
}

function redirect() {
	window.location = app.appWebContextRoot+"reportes";
}