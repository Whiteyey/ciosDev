/**
 * app, objeto global
 */
var app = {
		appWebContextRoot : ambiente
}

var pages;
pages = pages
	|| (function() {
		var pleaseWaitDiv = $('<div class="modal hide" id="pleaseWaitDialog" data-backdrop="static" data-keyboard="false"><div class="modal-header"><h1>Processing...</h1></div><div class="modal-body"><div class="progress progress-striped active"><div class="bar" style="width: 100%;"></div></div></div></div>');
		return {
			showPleaseWait : function() {
				pleaseWaitDiv.modal();
			},
			hidePleaseWait : function() {
				pleaseWaitDiv.modal('hide');
			},
			showError:function(title, msg){
				pleaseWaitDiv.modal('hide');
				var error = $(
						'<div class="modal fade" role="dialog">'
						+	'    <div class="modal-dialog window-container">'
						+	'      <div class="modal-content">'
						+	'        <div class="modal-header">'
						+	'          <button type="button" class="close" data-dismiss="modal">&times;</button>'
						// );
						
						+	'          <h4 class="modal-title">'+title+'</h4>'
						+	'        </div>'
						
						+	'        <div class="modal-body">'
						+	'			<p>'+msg+'</p>'
						
						+	'        </div>'
						+	'        <div class="modal-footer">'
						+	'          <button type="button" class="btn green_cios_button" data-dismiss="modal">Aceptar</button>'
						+	'        </div>'
						+	'      </div>'
						+	'    </div>'
						+	'  </div>'
						+	'</div>');
				error.modal();
			},
			showSuccess:function(title, msg){
				pages.showError(title, msg);
			},
			showSuccessRedirect:function(title, msg){
				pleaseWaitDiv.modal('hide');
				var redirect = $(
						'<div class="modal fade" role="dialog">'
						+	'    <div class="modal-dialog window-container">'
						+	'      <div class="modal-content">'
						+	'        <div class="modal-header">'
						+	'          <button type="button" class="close" data-dismiss="modal">&times;</button>'
						
						+	'          <h4 class="modal-title">'+title+'</h4>'
						+	'        </div>'
						
						+	'        <div class="modal-body">'
						+	'			<p>'+msg+'</p>'
						
						+	'        </div>'
						+	'        <div class="modal-footer">'
						+	'          <button type="button" class="btn green_cios_button" data-dismiss="modal" onclick="redirect()">Aceptar</button>'
						+	'        </div>'
						+	'      </div>'
						+	'    </div>'
						+	'  </div>'
						+	'</div>');
				redirect.modal();
			},
			showConfirm:function(title, msg, index){
				pleaseWaitDiv.modal('hide');
				var confirm = $(
						'<div class="modal fade" role="dialog">'
						+	'    <div class="modal-dialog window-container">'
						+	'      <div class="modal-content">'
						+	'        <div class="modal-header">'
						+	'          <button type="button" class="close" data-dismiss="modal">&times;</button>'
						// );
						
						+	'          <h4 class="modal-title">'+title+'</h4>'
						+	'        </div>'
						
						+	'        <div class="modal-body">'
						+	'			<p>'+msg+'</p>'
						
						+	'        </div>'
						+	'        <div class="modal-footer">'
						+	'          <button type="button" class="btn green_cios_button_dialog" data-dismiss="modal">Cancelar</button>'
						+	'          <button type="button" class="btn green_cios_button_dialog" data-dismiss="modal" onclick="deleteRow('+index+')">Aceptar</button>'
						+	'        </div>'
						+	'      </div>'
						+	'    </div>'
						+	'  </div>'
						+	'</div>');
				confirm.modal();
			},
			showConfirmUpdate:function(title, msg){
				pleaseWaitDiv.modal('hide');
				var confirm = $(
						'<div class="modal fade" role="dialog">'
						+	'    <div class="modal-dialog window-container">'
						+	'      <div class="modal-content">'
						+	'        <div class="modal-header">'
						+	'          <button type="button" class="close" data-dismiss="modal">&times;</button>'
						
						+	'          <h4 class="modal-title">'+title+'</h4>'
						+	'        </div>'
						
						+	'        <div class="modal-body">'
						+	'			<p>'+msg+'</p>'
						
						+	'        </div>'
						+	'        <div class="modal-footer">'
						+	'          <button type="button" class="btn green_cios_button_dialog" data-dismiss="modal">Cancelar</button>'
						+	'          <button type="button" class="btn green_cios_button_dialog" data-dismiss="modal" onclick="updateData()">Aceptar</button>'
						+	'        </div>'
						+	'      </div>'
						+	'    </div>'
						+	'  </div>'
						+	'</div>');
				confirm.modal();
			},
			showConfirmEdit:function(title, msg){
				pleaseWaitDiv.modal('hide');
				var confirm = $(
						'<div class="modal fade" role="dialog">'
						+	'    <div class="modal-dialog window-container">'
						+	'      <div class="modal-content">'
						+	'        <div class="modal-header">'
						+	'          <button type="button" class="close" data-dismiss="modal">&times;</button>'
						
						+	'          <h4 class="modal-title">'+title+'</h4>'
						+	'        </div>'
						
						+	'        <div class="modal-body">'
						+	'			<p>'+msg+'</p>'
						
						+	'        </div>'
						+	'        <div class="modal-footer">'
						+	'          <button type="button" class="btn green_cios_button_dialog" data-dismiss="modal">Cancelar</button>'
						+	'          <button type="button" class="btn green_cios_button_dialog" data-dismiss="modal" onclick="editElement()">Aceptar</button>'
						+	'        </div>'
						+	'      </div>'
						+	'    </div>'
						+	'  </div>'
						+	'</div>');
				confirm.modal();
			},
			showNotLogin:function(){
				pleaseWaitDiv.modal('hide');
				var notLogin = $(
						'<div class="modal fade" role="dialog">'
						+	'    <div class="modal-dialog window-container">'
						+	'      <div class="modal-content">'
						+	'        <div class="modal-header">'
						+	'          <button type="button" class="close" data-dismiss="modal">&times;</button>'
						+	'          <h4 class="modal-title"></h4>'
						+	'        </div>'
						
						+	'        <div class="modal-body">'
						+	'			<p>El usuario y/o la contrase&ntilde;a son incorrectos</p>'
						
						+	'        </div>'
						+	'        <div class="modal-footer">'
						+	'          <button type="button" class="btn btn-active" data-dismiss="modal">OK</button>'
						+	'        </div>'
						+	'      </div>'
						+	'    </div>'
						+	'  </div>'
						+	'</div>');
				notLogin.modal();
			}
		};
	})();

/**
 * Función pára manejar los botones en las plantilla
 * 
 * @param btn
 * @author Jhonatan Pacheco <jhonatanpachecohernandez@gmail.com>
 */
function btn_status(btn) {
	$("#botones-lf").children("div").children(":button").each(function(index, button) {

		if (btn.id == button.id) {
			$(button).removeClass("btn-default");
			$(button).addClass("btn-active");
		} else {
			$(button).removeClass("btn-active");
			$(button).addClass("btn-default");
		}
	});
}