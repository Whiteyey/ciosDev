package com.app.cios.utilerias.archivoxls;

import java.util.List;

/**
 * Interface que permite la creaci�n de archivos de xls mediente un data source.
 * 
 * @author jshernandez
 * @date 14/04/2014 12:17:54 p.m.
 *
 */
public interface IDatosArchivoXls {

	/**
	 *	Devuelve un objeto de tipo <tt>List</tt>, con los datos de los campos de la celda.
	 * Este m�todo obligatoriamente debe regresar valor.<br>
	 * <br>
	 * El Data Source List puede llevar los siguientes tipos de instrucciones:<br>
	 * <pre>
	 * <code>
	 *
	 * // Instrucciones de Control
	 *
	 * INTRUCCION						TIPO DE DATO ESPERADO
	 * ____________________________________________________________________
	 * Intruccion.SALTO_LINEA 		Integer
	 * Intruccion.OFFSET 	  		Integer || Integer[]
	 * Intruccion.COLSPAN	 		Integer || Integer[] // new Integer("3") 
	 * Intruccion.ESTILO				Estilo  || Estilo[]  // Estilo de la Celda. Ejemplos:
	 *																	// 	Estilos.TITULO_TABLA 	 
	 *																	//    new Estilos[]{ TEXTO_CENTRADO_AZUL, Estilo.NEGRITAS_DERECHA },
	 * Intruccion.HOJA_NUEVA		String 					// Si no se ha creado ninguna hoja todav�a, asigna a la hoja actual un valor
	 * Intruccion.RESET_FORMATO	Ninguno					// Quita el formato indicado en las siguientes instrucciones:
	 *																	// Intruccion.OFFSET, Intruccion.COLSPAN y Intruccion.ESTILO
	 *
	 * // Con respecto a los datos, se interpretara as� a cualquier objeto que no sea parte de los
	 * // argumentos de alguna instrucci�n; se tiene soporte para cuatro tipos de dato:
	 *
	 * String 		// "Reporte de Actividades" 			// Se asignar� a la celda correspondiente del rengl�n en curso.
	 * String[] 	// new String[]{ "Campo", "Valor" } // Se asignar�n a las celdas correspondientes del rengl�n en curso
	 * Registros	// Objeto Registros						// Se asignar�n a las celdas correspondientes de acuerdo 
	 *																	// al n�mero de renglones que traiga el objeto de registros.
	 * Object      // object.toString(), para obtener  // Se asignar� a la celda correspondiente del rengl�n en curso.
	 * 				// valor.
	 *
	 * Ejemplo:
	 *
	 * List dataSourceList = new ArrayList();
	 *
	 * dataSourceList.add(Instruccion.ESTILO);
	 * dataSourceList.add(Estilo.TITULO);
	 * dataSourceList.add(Instruccion.COLSPAN);
	 * dataSourceList.add(new Integer(2));
	 * // Agregar contenido del T�tulo
	 * dataSourceList.add("Reporte Generado el D�a 24/04/2014");
	 * // 3. Agregar Renglon Vac�o.
	 * dataSourceList.add(""); 
	 * // Quitar formato anterior
	 * dataSourceList.add(Instruccion.RESET_FORMATO); 
	 * // 4. Agregar Cabecera de la Tabla		
	 * dataSourceList.add(Instruccion.ESTILO);
	 * dataSourceList.add(Estilo.TITULO_CENTRADO_TABLA);
	 * dataSourceList.add(new String[] { "Nombre del Intermediario", "Monto", "Reporte Total", "N�mero de Operaciones" }); 
	 * // 5. Agregar Contenido de la Tabla
	 * dataSourceList.add(Instruccion.ESTILO);
	 * dataSourceList.add(new Estilo[]{ textoCentradoTablaAzul, Estilo TEXTO_DERECHA_TABLA } );
	 * dataSourceList.add(registros); // Objeto Registros
	 * // Tambien se pudo haber usado:
	 * // dataSourceList.add(new String[] { "Bank National", "00.00", "--", "0" });
	 * 
	 * // En caso de se especifique un array de Estilo, Offset o Colspan y las dimensiones de este array
	 * // sean menores al numero de columnas de los datos, se considerar� el ultimo estilo, offset o colspan
	 * // indicado.
	 * 
	 * @return Objeto <tt>List</tt> con datos de las celdas. 
	 */
	List  getDataSourceList();

	/**
	 * Ruta del directorio temporal donde se creara el documento de xls con los datos de
	 * la lista. Este campo es obligatorio.
	 * 
	 * @return <tt>String</tt> con la ruta f�sica del directorio temporal.
	 */
	String  getRutaDirectorioTemporal();
		
	/**
	 * Devuelve el login del usuario que creo el archivo.
	 *
	 * @return <tt>String</tt> con el login del usuario que creo el archivo. 
	 * <tt>null</tt> si esta funcionalidad no es requerida.
	 */
	String  getLoginUsuario();
		
}
