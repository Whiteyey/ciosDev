package com.app.cios.utilerias.archivoxls;

import org.apache.commons.beanutils.PropertyUtils;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.util.HSSFColor;

/**
 * Clase Auxiliar para indicar los estilos de las Celdas.
 *
 * @author jshernandez
 * @since 25/04/2014 06:06:53 p.m.
 */
public class Estilo {
	
	// ESTILOS GENERICOS

	public static final Estilo TITULO;
	public static final Estilo SUBTITULO;
	public static final Estilo TEXTO;
	public static final Estilo TEXTO_CENTRADO;
	public static final Estilo TEXTO_DERECHA;
	public static final Estilo NEGRITAS;
	public static final Estilo NEGRITAS_CENTRADO;
	public static final Estilo NEGRITAS_DERECHA;
	public static final Estilo TITULO_TABLA;
	public static final Estilo TITULO_CENTRADO_TABLA;
	public static final Estilo TITULO_DERECHA_TABLA;
	public static final Estilo TEXTO_TABLA;
	public static final Estilo TEXTO_CENTRADO_TABLA;
	public static final Estilo TEXTO_DERECHA_TABLA;

	// CONSTRUCTORES
	
	public Estilo() { }
	
	/**
	 * Para cuando se quiera modificar un estilo base. Si el estilo es lo suficiente generico
	 * considerar a�adir la clase como constante.
	 */
	public Estilo(Estilo estiloOriginal) 
		throws Exception{
		PropertyUtils.copyProperties(this, estiloOriginal);
   }
   
	// ATRIBUTOS
	
	// Atributos de la fuente del estilo
	private short 	fontHeightInPoints;  // { 10, 12, etc }
	private short 	color; 					// HSSFColor.BLACK.index,    HSSFColor.RED.index, HSSFColor.BLUE.index y HSSFColor.TEAL.index
	private short 	boldweight; 			// HSSFFont.BOLDWEIGHT_BOLD, HSSFFont.BOLDWEIGHT_NORMAL
	private String fontName;				// "Arial"
	// Atributos del estilo
	private short 	fillForegroundColor; // new HSSFColor.GREY_25_PERCENT().getIndex(), new HSSFColor.YELLOW().getIndex()
	private short 	fillPattern;         // HSSFCellStyle.SOLID_FOREGROUND || HSSFCellStyle.FINE_DOTS 
	private short 	borderBottom;			// HSSFCellStyle.BORDER_THIN
	private short 	borderLeft;				// HSSFCellStyle.BORDER_THIN
	private short 	borderRight;			// HSSFCellStyle.BORDER_THIN
	private short 	borderTop;				// HSSFCellStyle.BORDER_THIN
	private short 	alignment;				// HSSFCellStyle.ALIGN_LEFT, HSSFCellStyle.ALIGN_CENTER y HSSFCellStyle.ALIGN_RIGHT
	private short 	verticalAlignment;	// HSSFCellStyle.VERTICAL_TOP, HSSFCellStyle.VERTICAL_CENTER, HSSFCellStyle.VERTICAL_BOTTOM y HSSFCellStyle.VERTICAL_JUSTIFY
	 
	// SETTERS / GETTERS
	
	// Atributos de la fuente del estilo
	
	public short getFontHeightInPoints() {
		return fontHeightInPoints;
	}

	public void setFontHeightInPoints(short fontHeightInPoints) {
		this.fontHeightInPoints = fontHeightInPoints;
	}

	public short getColor() {
		return color;
	}

	public void setColor(short color) {
		this.color = color;
	}

	public short getBoldweight() {
		return boldweight;
	}

	public void setBoldweight(short boldweight) {
		this.boldweight = boldweight;
	}

	public String getFontName() {
		return fontName;
	}

	public void setFontName(String fontName) {
		this.fontName = fontName;
	}

	// Atributos del estilo
	
	public short getFillForegroundColor() {
		return fillForegroundColor;
	}

	public void setFillForegroundColor(short fillForegroundColor) {
		this.fillForegroundColor = fillForegroundColor;
	}

	public short getFillPattern() {
		return fillPattern;
	}

	public void setFillPattern(short fillPattern) {
		this.fillPattern = fillPattern;
	}

	public short getBorderBottom() {
		return borderBottom;
	}

	public void setBorderBottom(short borderBottom) {
		this.borderBottom = borderBottom;
	}

	public short getBorderLeft() {
		return borderLeft;
	}

	public void setBorderLeft(short borderLeft) {
		this.borderLeft = borderLeft;
	}

	public short getBorderRight() {
		return borderRight;
	}

	public void setBorderRight(short borderRight) {
		this.borderRight = borderRight;
	}

	public short getBorderTop() {
		return borderTop;
	}

	public void setBorderTop(short borderTop) {
		this.borderTop = borderTop;
	}

	public short getAlignment() {
		return alignment;
	}

	public void setAlignment(short alignment) {
		this.alignment = alignment;
	}

	public short getVerticalAlignment() {
		return verticalAlignment;
	}

	public void setVerticalAlignment(short verticalAlignment) {
		this.verticalAlignment = verticalAlignment;
	}

   // METODOS AUXILIARES
   
   // Generar metodo equals y generar metodo hascode
  
   @Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + alignment;
		result = prime * result + boldweight;
		result = prime * result + borderBottom;
		result = prime * result + borderLeft;
		result = prime * result + borderRight;
		result = prime * result + borderTop;
		result = prime * result + color;
		result = prime * result + fillForegroundColor;
		result = prime * result + fillPattern;
		result = prime * result + fontHeightInPoints;
		result = prime * result
				+ ((fontName == null) ? 0 : fontName.hashCode());
		result = prime * result + verticalAlignment;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Estilo other = (Estilo) obj;
		if (alignment != other.alignment)
			return false;
		if (boldweight != other.boldweight)
			return false;
		if (borderBottom != other.borderBottom)
			return false;
		if (borderLeft != other.borderLeft)
			return false;
		if (borderRight != other.borderRight)
			return false;
		if (borderTop != other.borderTop)
			return false;
		if (color != other.color)
			return false;
		if (fillForegroundColor != other.fillForegroundColor)
			return false;
		if (fillPattern != other.fillPattern)
			return false;
		if (fontHeightInPoints != other.fontHeightInPoints)
			return false;
		if (fontName == null) {
			if (other.fontName != null)
				return false;
		} else if (!fontName.equals(other.fontName))
			return false;
		if (verticalAlignment != other.verticalAlignment)
			return false;
		return true;
	}
	
   // INICIALIZAR ESTILOS
   
   static {
 	
   	// 1. TITULO
		TITULO = new Estilo();
		TITULO.setFontHeightInPoints( (short)  12 );
		//TITULO.setColor( HSSFColor.BLACK.index, HSSFColor.RED.index, HSSFColor.BLUE.index y HSSFColor.TEAL.index  );
		TITULO.setBoldweight( HSSFFont.BOLDWEIGHT_BOLD );
		TITULO.setFontName( "Arial" );
		//TITULO.setFillForegroundColor( new HSSFColor.GREY_25_PERCENT().getIndex(), new HSSFColor.YELLOW().getIndex() );
		//TITULO.setFillPattern( HSSFCellStyle.SOLID_FOREGROUND || HSSFCellStyle.FINE_DOTS  );
		//TITULO.setBorderBottom( HSSFCellStyle.BORDER_THIN );
		//TITULO.setBorderLeft( HSSFCellStyle.BORDER_THIN );
		//TITULO.setBorderRight( HSSFCellStyle.BORDER_THIN );
		//TITULO.setBorderTop( HSSFCellStyle.BORDER_THIN );
		TITULO.setAlignment( HSSFCellStyle.ALIGN_CENTER );
		//TITULO.setVerticalAlignment( HSSFCellStyle.VERTICAL_TOP, HSSFCellStyle.VERTICAL_CENTER, HSSFCellStyle.VERTICAL_BOTTOM y HSSFCellStyle.VERTICAL_JUSTIFY );

   	// 2. SUBTITULO
		SUBTITULO = new Estilo();
		SUBTITULO.setFontHeightInPoints( (short)  10 );
		//SUBTITULO.setColor( HSSFColor.BLACK.index, HSSFColor.RED.index, HSSFColor.BLUE.index y HSSFColor.TEAL.index );
		SUBTITULO.setBoldweight( HSSFFont.BOLDWEIGHT_BOLD );
		SUBTITULO.setFontName( "Arial" );
		//SUBTITULO.setFillForegroundColor( new HSSFColor.GREY_25_PERCENT().getIndex(), new HSSFColor.YELLOW().getIndex() );
		//SUBTITULO.setFillPattern( HSSFCellStyle.SOLID_FOREGROUND || HSSFCellStyle.FINE_DOTS  );
		//SUBTITULO.setBorderBottom( HSSFCellStyle.BORDER_THIN );
		//SUBTITULO.setBorderLeft( HSSFCellStyle.BORDER_THIN );
		//SUBTITULO.setBorderRight( HSSFCellStyle.BORDER_THIN );
		//SUBTITULO.setBorderTop( HSSFCellStyle.BORDER_THIN );
		SUBTITULO.setAlignment( HSSFCellStyle.ALIGN_CENTER );
		//SUBTITULO.setVerticalAlignment( HSSFCellStyle.VERTICAL_TOP, HSSFCellStyle.VERTICAL_CENTER, HSSFCellStyle.VERTICAL_BOTTOM y HSSFCellStyle.VERTICAL_JUSTIFY );

   	// 3. TEXTO
		TEXTO = new Estilo();
		TEXTO.setFontHeightInPoints( (short)  10 );
		//TEXTO.setColor( HSSFColor.BLACK.index, HSSFColor.RED.index, HSSFColor.BLUE.index y HSSFColor.TEAL.index );
		//TEXTO.setBoldweight( HSSFFont.BOLDWEIGHT_BOLD, HSSFFont.BOLDWEIGHT_NORMAL );
		TEXTO.setFontName( "Arial" );
		//TEXTO.setFillForegroundColor( new HSSFColor.GREY_25_PERCENT().getIndex(), new HSSFColor.YELLOW().getIndex() );
		//TEXTO.setFillPattern( HSSFCellStyle.SOLID_FOREGROUND || HSSFCellStyle.FINE_DOTS  );
		//TEXTO.setBorderBottom( HSSFCellStyle.BORDER_THIN );
		//TEXTO.setBorderLeft( HSSFCellStyle.BORDER_THIN );
		//TEXTO.setBorderRight( HSSFCellStyle.BORDER_THIN );
		//TEXTO.setBorderTop( HSSFCellStyle.BORDER_THIN );
		//TEXTO.setAlignment( HSSFCellStyle.ALIGN_LEFT, HSSFCellStyle.ALIGN_CENTER y HSSFCellStyle.ALIGN_RIGHT );
		//TEXTO.setVerticalAlignment( HSSFCellStyle.VERTICAL_TOP, HSSFCellStyle.VERTICAL_CENTER, HSSFCellStyle.VERTICAL_BOTTOM y HSSFCellStyle.VERTICAL_JUSTIFY );

   	// 4. TEXTO_CENTRADO
		TEXTO_CENTRADO = new Estilo();
		TEXTO_CENTRADO.setFontHeightInPoints( (short)  10 );
		//TEXTO_CENTRADO.setColor( HSSFColor.BLACK.index, HSSFColor.RED.index, HSSFColor.BLUE.index y HSSFColor.TEAL.index );
		//TEXTO_CENTRADO.setBoldweight( HSSFFont.BOLDWEIGHT_BOLD, HSSFFont.BOLDWEIGHT_NORMAL );
		TEXTO_CENTRADO.setFontName( "Arial" );
		//TEXTO_CENTRADO.setFillForegroundColor( new HSSFColor.GREY_25_PERCENT().getIndex(), new HSSFColor.YELLOW().getIndex() );
		//TEXTO_CENTRADO.setFillPattern( HSSFCellStyle.SOLID_FOREGROUND || HSSFCellStyle.FINE_DOTS  );
		//TEXTO_CENTRADO.setBorderBottom( HSSFCellStyle.BORDER_THIN );
		//TEXTO_CENTRADO.setBorderLeft( HSSFCellStyle.BORDER_THIN );
		//TEXTO_CENTRADO.setBorderRight( HSSFCellStyle.BORDER_THIN );
		//TEXTO_CENTRADO.setBorderTop( HSSFCellStyle.BORDER_THIN );
		TEXTO_CENTRADO.setAlignment( HSSFCellStyle.ALIGN_CENTER );
		//TEXTO_CENTRADO.setVerticalAlignment( HSSFCellStyle.VERTICAL_TOP, HSSFCellStyle.VERTICAL_CENTER, HSSFCellStyle.VERTICAL_BOTTOM y HSSFCellStyle.VERTICAL_JUSTIFY );

   	// 5. TEXTO_DERECHA
		TEXTO_DERECHA = new Estilo();
		TEXTO_DERECHA.setFontHeightInPoints( (short)  10 );
		//TEXTO_DERECHA.setColor( HSSFColor.BLACK.index, HSSFColor.RED.index, HSSFColor.BLUE.index y HSSFColor.TEAL.index );
		//TEXTO_DERECHA.setBoldweight( HSSFFont.BOLDWEIGHT_BOLD, HSSFFont.BOLDWEIGHT_NORMAL );
		TEXTO_DERECHA.setFontName( "Arial" );
		//TEXTO_DERECHA.setFillForegroundColor( new HSSFColor.GREY_25_PERCENT().getIndex(), new HSSFColor.YELLOW().getIndex() );
		//TEXTO_DERECHA.setFillPattern( HSSFCellStyle.SOLID_FOREGROUND || HSSFCellStyle.FINE_DOTS  );
		//TEXTO_DERECHA.setBorderBottom( HSSFCellStyle.BORDER_THIN );
		//TEXTO_DERECHA.setBorderLeft( HSSFCellStyle.BORDER_THIN );
		//TEXTO_DERECHA.setBorderRight( HSSFCellStyle.BORDER_THIN );
		//TEXTO_DERECHA.setBorderTop( HSSFCellStyle.BORDER_THIN );
		TEXTO_DERECHA.setAlignment( HSSFCellStyle.ALIGN_RIGHT );
		//TEXTO_DERECHA.setVerticalAlignment( HSSFCellStyle.VERTICAL_TOP, HSSFCellStyle.VERTICAL_CENTER, HSSFCellStyle.VERTICAL_BOTTOM y HSSFCellStyle.VERTICAL_JUSTIFY );

   	// 6. NEGRITAS
		NEGRITAS = new Estilo();
		NEGRITAS.setFontHeightInPoints( (short)  10 );
		//NEGRITAS.setColor( HSSFColor.BLACK.index, HSSFColor.RED.index, HSSFColor.BLUE.index y HSSFColor.TEAL.index );
		NEGRITAS.setBoldweight( HSSFFont.BOLDWEIGHT_BOLD );
		NEGRITAS.setFontName( "Arial" );
		//NEGRITAS.setFillForegroundColor( new HSSFColor.GREY_25_PERCENT().getIndex(), new HSSFColor.YELLOW().getIndex() );
		//NEGRITAS.setFillPattern( HSSFCellStyle.SOLID_FOREGROUND || HSSFCellStyle.FINE_DOTS  );
		//NEGRITAS.setBorderBottom( HSSFCellStyle.BORDER_THIN );
		//NEGRITAS.setBorderLeft( HSSFCellStyle.BORDER_THIN );
		//NEGRITAS.setBorderRight( HSSFCellStyle.BORDER_THIN );
		//NEGRITAS.setBorderTop( HSSFCellStyle.BORDER_THIN );
		//NEGRITAS.setAlignment( HSSFCellStyle.ALIGN_LEFT, HSSFCellStyle.ALIGN_CENTER y HSSFCellStyle.ALIGN_RIGHT );
		//NEGRITAS.setVerticalAlignment( HSSFCellStyle.VERTICAL_TOP, HSSFCellStyle.VERTICAL_CENTER, HSSFCellStyle.VERTICAL_BOTTOM y HSSFCellStyle.VERTICAL_JUSTIFY );

   	// 7. NEGRITAS_CENTRADO
		NEGRITAS_CENTRADO = new Estilo();
		NEGRITAS_CENTRADO.setFontHeightInPoints( (short)  10 );
		//NEGRITAS_CENTRADO.setColor( HSSFColor.BLACK.index, HSSFColor.RED.index, HSSFColor.BLUE.index y HSSFColor.TEAL.index );
		NEGRITAS_CENTRADO.setBoldweight( HSSFFont.BOLDWEIGHT_BOLD );
		NEGRITAS_CENTRADO.setFontName( "Arial" );
		//NEGRITAS_CENTRADO.setFillForegroundColor( new HSSFColor.GREY_25_PERCENT().getIndex(), new HSSFColor.YELLOW().getIndex() );
		//NEGRITAS_CENTRADO.setFillPattern( HSSFCellStyle.SOLID_FOREGROUND || HSSFCellStyle.FINE_DOTS  );
		//NEGRITAS_CENTRADO.setBorderBottom( HSSFCellStyle.BORDER_THIN );
		//NEGRITAS_CENTRADO.setBorderLeft( HSSFCellStyle.BORDER_THIN );
		//NEGRITAS_CENTRADO.setBorderRight( HSSFCellStyle.BORDER_THIN );
		//NEGRITAS_CENTRADO.setBorderTop( HSSFCellStyle.BORDER_THIN );
		NEGRITAS_CENTRADO.setAlignment( HSSFCellStyle.ALIGN_CENTER );
		//NEGRITAS_CENTRADO.setVerticalAlignment( HSSFCellStyle.VERTICAL_TOP, HSSFCellStyle.VERTICAL_CENTER, HSSFCellStyle.VERTICAL_BOTTOM y HSSFCellStyle.VERTICAL_JUSTIFY );

   	// 8. NEGRITAS_DERECHA
		NEGRITAS_DERECHA = new Estilo();
		NEGRITAS_DERECHA.setFontHeightInPoints( (short)  10 );
		//NEGRITAS_DERECHA.setColor( HSSFColor.BLACK.index, HSSFColor.RED.index, HSSFColor.BLUE.index y HSSFColor.TEAL.index );
		NEGRITAS_DERECHA.setBoldweight( HSSFFont.BOLDWEIGHT_BOLD );
		NEGRITAS_DERECHA.setFontName( "Arial" );
		//NEGRITAS_DERECHA.setFillForegroundColor( new HSSFColor.GREY_25_PERCENT().getIndex(), new HSSFColor.YELLOW().getIndex() );
		//NEGRITAS_DERECHA.setFillPattern( HSSFCellStyle.SOLID_FOREGROUND || HSSFCellStyle.FINE_DOTS  );
		//NEGRITAS_DERECHA.setBorderBottom( HSSFCellStyle.BORDER_THIN );
		//NEGRITAS_DERECHA.setBorderLeft( HSSFCellStyle.BORDER_THIN );
		//NEGRITAS_DERECHA.setBorderRight( HSSFCellStyle.BORDER_THIN );
		//NEGRITAS_DERECHA.setBorderTop( HSSFCellStyle.BORDER_THIN );
		NEGRITAS_DERECHA.setAlignment( HSSFCellStyle.ALIGN_RIGHT );
		//NEGRITAS_DERECHA.setVerticalAlignment( HSSFCellStyle.VERTICAL_TOP, HSSFCellStyle.VERTICAL_CENTER, HSSFCellStyle.VERTICAL_BOTTOM y HSSFCellStyle.VERTICAL_JUSTIFY );

   	// 9. TITULO_TABLA
		TITULO_TABLA = new Estilo();
		TITULO_TABLA.setFontHeightInPoints( (short)  10 );
		//TITULO_TABLA.setColor( HSSFColor.BLACK.index, HSSFColor.RED.index, HSSFColor.BLUE.index y HSSFColor.TEAL.index );
		TITULO_TABLA.setBoldweight( HSSFFont.BOLDWEIGHT_BOLD );
		TITULO_TABLA.setFontName( "Arial" );
		TITULO_TABLA.setFillForegroundColor( new HSSFColor.GREY_25_PERCENT().getIndex() );
		TITULO_TABLA.setFillPattern( HSSFCellStyle.SOLID_FOREGROUND );
		TITULO_TABLA.setBorderBottom( HSSFCellStyle.BORDER_THIN );
		TITULO_TABLA.setBorderLeft( HSSFCellStyle.BORDER_THIN );
		TITULO_TABLA.setBorderRight( HSSFCellStyle.BORDER_THIN );
		TITULO_TABLA.setBorderTop( HSSFCellStyle.BORDER_THIN );
		//TITULO_TABLA.setAlignment( HSSFCellStyle.ALIGN_LEFT, HSSFCellStyle.ALIGN_CENTER y HSSFCellStyle.ALIGN_RIGHT );
		//TITULO_TABLA.setVerticalAlignment( HSSFCellStyle.VERTICAL_TOP, HSSFCellStyle.VERTICAL_CENTER, HSSFCellStyle.VERTICAL_BOTTOM y HSSFCellStyle.VERTICAL_JUSTIFY );

		// 10. TITULO_CENTRADO_TABLA
		TITULO_CENTRADO_TABLA = new Estilo();
		TITULO_CENTRADO_TABLA.setFontHeightInPoints( (short)  10 );
		//TITULO_CENTRADO_TABLA.setColor( HSSFColor.BLACK.index, HSSFColor.RED.index, HSSFColor.BLUE.index y HSSFColor.TEAL.index );
		TITULO_CENTRADO_TABLA.setBoldweight( HSSFFont.BOLDWEIGHT_BOLD );
		TITULO_CENTRADO_TABLA.setFontName( "Arial" );
		TITULO_CENTRADO_TABLA.setFillForegroundColor( new HSSFColor.GREY_25_PERCENT().getIndex() ); //new HSSFColor.GREY_25_PERCENT().getIndex(), new HSSFColor.YELLOW().getIndex() );
		TITULO_CENTRADO_TABLA.setFillPattern( HSSFCellStyle.SOLID_FOREGROUND );
		TITULO_CENTRADO_TABLA.setBorderBottom( HSSFCellStyle.BORDER_THIN );
		TITULO_CENTRADO_TABLA.setBorderLeft( HSSFCellStyle.BORDER_THIN );
		TITULO_CENTRADO_TABLA.setBorderRight( HSSFCellStyle.BORDER_THIN );
		TITULO_CENTRADO_TABLA.setBorderTop( HSSFCellStyle.BORDER_THIN );
		TITULO_CENTRADO_TABLA.setAlignment( HSSFCellStyle.ALIGN_CENTER );
		//TITULO_CENTRADO_TABLA.setVerticalAlignment( HSSFCellStyle.VERTICAL_TOP, HSSFCellStyle.VERTICAL_CENTER, HSSFCellStyle.VERTICAL_BOTTOM y HSSFCellStyle.VERTICAL_JUSTIFY );

   	// 11. TITULO_DERECHA_TABLA
		TITULO_DERECHA_TABLA = new Estilo();
		TITULO_DERECHA_TABLA.setFontHeightInPoints( (short)  10 );
		//TITULO_DERECHA_TABLA.setColor( HSSFColor.BLACK.index, HSSFColor.RED.index, HSSFColor.BLUE.index y HSSFColor.TEAL.index );
		TITULO_DERECHA_TABLA.setBoldweight( HSSFFont.BOLDWEIGHT_BOLD );
		TITULO_DERECHA_TABLA.setFontName( "Arial" );
		TITULO_DERECHA_TABLA.setFillForegroundColor( new HSSFColor.GREY_25_PERCENT().getIndex() );
		TITULO_DERECHA_TABLA.setFillPattern( HSSFCellStyle.SOLID_FOREGROUND );
		TITULO_DERECHA_TABLA.setBorderBottom( HSSFCellStyle.BORDER_THIN );
		TITULO_DERECHA_TABLA.setBorderLeft( HSSFCellStyle.BORDER_THIN );
		TITULO_DERECHA_TABLA.setBorderRight( HSSFCellStyle.BORDER_THIN );
		TITULO_DERECHA_TABLA.setBorderTop( HSSFCellStyle.BORDER_THIN );
		TITULO_DERECHA_TABLA.setAlignment( HSSFCellStyle.ALIGN_RIGHT );
		//TITULO_DERECHA_TABLA.setVerticalAlignment( HSSFCellStyle.VERTICAL_TOP, HSSFCellStyle.VERTICAL_CENTER, HSSFCellStyle.VERTICAL_BOTTOM y HSSFCellStyle.VERTICAL_JUSTIFY );

		// 12. TEXTO_TABLA
		TEXTO_TABLA = new Estilo();
		TEXTO_TABLA.setFontHeightInPoints( (short)  10 );
		//TEXTO_TABLA.setColor( HSSFColor.BLACK.index, HSSFColor.RED.index, HSSFColor.BLUE.index y HSSFColor.TEAL.index );
		//TEXTO_TABLA.setBoldweight( HSSFFont.BOLDWEIGHT_BOLD, HSSFFont.BOLDWEIGHT_NORMAL );
		TEXTO_TABLA.setFontName( "Arial" );
		//TEXTO_TABLA.setFillForegroundColor( new HSSFColor.GREY_25_PERCENT().getIndex(), new HSSFColor.YELLOW().getIndex() );
		//TEXTO_TABLA.setFillPattern( HSSFCellStyle.SOLID_FOREGROUND || HSSFCellStyle.FINE_DOTS  );
		TEXTO_TABLA.setBorderBottom( HSSFCellStyle.BORDER_THIN );
		TEXTO_TABLA.setBorderLeft( HSSFCellStyle.BORDER_THIN );
		TEXTO_TABLA.setBorderRight( HSSFCellStyle.BORDER_THIN );
		TEXTO_TABLA.setBorderTop( HSSFCellStyle.BORDER_THIN );
		//TEXTO_TABLA.setAlignment( HSSFCellStyle.ALIGN_LEFT, HSSFCellStyle.ALIGN_CENTER y HSSFCellStyle.ALIGN_RIGHT  );
		//TEXTO_TABLA.setVerticalAlignment( HSSFCellStyle.VERTICAL_TOP, HSSFCellStyle.VERTICAL_CENTER, HSSFCellStyle.VERTICAL_BOTTOM y HSSFCellStyle.VERTICAL_JUSTIFY );

		// 13. TEXTO_CENTRADO_TABLA
		TEXTO_CENTRADO_TABLA = new Estilo();
		TEXTO_CENTRADO_TABLA.setFontHeightInPoints( (short)  10 );
		//TEXTO_CENTRADO_TABLA.setColor( HSSFColor.BLACK.index, HSSFColor.RED.index, HSSFColor.BLUE.index y HSSFColor.TEAL.index );
		//TEXTO_CENTRADO_TABLA.setBoldweight( HSSFFont.BOLDWEIGHT_BOLD, HSSFFont.BOLDWEIGHT_NORMAL );
		TEXTO_CENTRADO_TABLA.setFontName( "Arial" );
		//TEXTO_CENTRADO_TABLA.setFillForegroundColor( new HSSFColor.GREY_25_PERCENT().getIndex(), new HSSFColor.YELLOW().getIndex() );
		//TEXTO_CENTRADO_TABLA.setFillPattern( HSSFCellStyle.SOLID_FOREGROUND || HSSFCellStyle.FINE_DOTS  );
		TEXTO_CENTRADO_TABLA.setBorderBottom( HSSFCellStyle.BORDER_THIN );
		TEXTO_CENTRADO_TABLA.setBorderLeft( HSSFCellStyle.BORDER_THIN );
		TEXTO_CENTRADO_TABLA.setBorderRight( HSSFCellStyle.BORDER_THIN );
		TEXTO_CENTRADO_TABLA.setBorderTop( HSSFCellStyle.BORDER_THIN );
		TEXTO_CENTRADO_TABLA.setAlignment( HSSFCellStyle.ALIGN_CENTER );
		//TEXTO_CENTRADO_TABLA.setVerticalAlignment( HSSFCellStyle.VERTICAL_TOP, HSSFCellStyle.VERTICAL_CENTER, HSSFCellStyle.VERTICAL_BOTTOM y HSSFCellStyle.VERTICAL_JUSTIFY );

		// 14. TEXTO_DERECHA_TABLA
		TEXTO_DERECHA_TABLA = new Estilo();
		TEXTO_DERECHA_TABLA.setFontHeightInPoints( (short)  10 );
		//TEXTO_DERECHA_TABLA.setColor( HSSFColor.BLACK.index, HSSFColor.RED.index, HSSFColor.BLUE.index y HSSFColor.TEAL.index );
		//TEXTO_DERECHA_TABLA.setBoldweight( HSSFFont.BOLDWEIGHT_BOLD, HSSFFont.BOLDWEIGHT_NORMAL );
		TEXTO_DERECHA_TABLA.setFontName( "Arial" );
		//TEXTO_DERECHA_TABLA.setFillForegroundColor( new HSSFColor.GREY_25_PERCENT().getIndex(), new HSSFColor.YELLOW().getIndex() );
		//TEXTO_DERECHA_TABLA.setFillPattern( HSSFCellStyle.SOLID_FOREGROUND || HSSFCellStyle.FINE_DOTS  );
		TEXTO_DERECHA_TABLA.setBorderBottom( HSSFCellStyle.BORDER_THIN );
		TEXTO_DERECHA_TABLA.setBorderLeft( HSSFCellStyle.BORDER_THIN );
		TEXTO_DERECHA_TABLA.setBorderRight( HSSFCellStyle.BORDER_THIN );
		TEXTO_DERECHA_TABLA.setBorderTop( HSSFCellStyle.BORDER_THIN );
		TEXTO_DERECHA_TABLA.setAlignment( HSSFCellStyle.ALIGN_RIGHT );
		//TEXTO_DERECHA_TABLA.setVerticalAlignment( HSSFCellStyle.VERTICAL_TOP, HSSFCellStyle.VERTICAL_CENTER, HSSFCellStyle.VERTICAL_BOTTOM y HSSFCellStyle.VERTICAL_JUSTIFY );

		// Nota: Se agrega plantilla para clases futuras.
		/*
		// ##. $1
		$1 = new Estilo();
		$1.setFontHeightInPoints( (short)  10, 12 );
		$1.setColor( HSSFColor.BLACK.index, HSSFColor.RED.index, HSSFColor.BLUE.index y HSSFColor.TEAL.index );
		$1.setBoldweight( HSSFFont.BOLDWEIGHT_BOLD, HSSFFont.BOLDWEIGHT_NORMAL );
		$1.setFontName( "Arial" );
		$1.setFillForegroundColor( new HSSFColor.GREY_25_PERCENT().getIndex(), new HSSFColor.YELLOW().getIndex() );
		$1.setFillPattern( HSSFCellStyle.SOLID_FOREGROUND || HSSFCellStyle.FINE_DOTS  ); 
		$1.setBorderBottom( HSSFCellStyle.BORDER_THIN );
		$1.setBorderLeft( HSSFCellStyle.BORDER_THIN );
		$1.setBorderRight( HSSFCellStyle.BORDER_THIN );
		$1.setBorderTop( HSSFCellStyle.BORDER_THIN );
		$1.setAlignment( HSSFCellStyle.ALIGN_LEFT, HSSFCellStyle.ALIGN_CENTER y HSSFCellStyle.ALIGN_RIGHT );
		$1.setVerticalAlignment( HSSFCellStyle.VERTICAL_TOP, HSSFCellStyle.VERTICAL_CENTER, HSSFCellStyle.VERTICAL_BOTTOM y HSSFCellStyle.VERTICAL_JUSTIFY );

		*/
		
	}
		
}
