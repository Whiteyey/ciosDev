/**
 * 
 */
package com.app.cios.beans;

/**
 * @author Jhonatan Pacheco <jhonatanpachecohernandez@gmail.com>
 *
 */
public class ClientesDTO {

	
	private int idCliente;
	private int idElement;
	private String nombre;
	private String telefono;
	private String correoElectronico;
	private String giro;
	private String director;
	private String direccion;
	private String rfc;
	private String ra;
	private String logoA;
	private String logoB;
	private String logoC;
	
	public ClientesDTO(){
	}
	
	/*constructor para las relaciones de clientes y elementos*/
	public ClientesDTO(int idCliente, int idElement, String giro){
		this.idCliente = idCliente;
		this.idElement = idElement;
		this.giro = giro;
	}
	
	
	/*constructor para asignacion de elementos*/
	public ClientesDTO(int idCliente, String nombre, String direccion,
			String correoElectronico, String telefono, String director){
		this.idCliente = idCliente;
		this.nombre = nombre;
		this.direccion = direccion;
		this.correoElectronico = correoElectronico;
		this.telefono = telefono;
		this.director = director;
	}
	
	/**
	 * @param idCliente
	 * @param nombre
	 * @param telefono
	 * @param correoElectronico
	 * @param giro
	 * @param direcctor
	 * @param direccion
	 * @param rfc
	 * @param logoA
	 * @param logoB
	 * @param logoC
	 */
	public ClientesDTO(int idCliente, String nombre, String telefono, String correoElectronico, String giro,
			String director, String direccion, String rfc, String ra, String logoA, String logoB, String logoC) {
		super();
		this.idCliente = idCliente;
		this.nombre = nombre;
		this.telefono = telefono;
		this.correoElectronico = correoElectronico;
		this.giro = giro;
		this.director = director;
		this.direccion = direccion;
		this.ra = ra;
		this.rfc = rfc;
		this.logoA = logoA;
		this.logoB = logoB;
		this.logoC = logoC;
	}
	/**
	 * @return the idCliente
	 */
	public int getIdCliente() {
		return idCliente;
	}
	/**
	 * @param idCliente the idCliente to set
	 */
	public void setIdCliente(int idCliente) {
		this.idCliente = idCliente;
	}
	/**
	 * @return the idCliente
	 */
	public int getIdElement() {
		return idElement;
	}
	/**
	 * @param idCliente the idCliente to set
	 */
	public void setIdElement(int idElement) {
		this.idElement = idElement;
	}
	/**
	 * @return the nomnre
	 */
	public String getNombre() {
		return nombre;
	}
	/**
	 * @param nomnre the nomnre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	/**
	 * @return the telefono
	 */
	public String getTelefono() {
		return telefono;
	}
	/**
	 * @param telefono the telefono to set
	 */
	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}
	/**
	 * @return the correoElectronico
	 */
	public String getCorreoElectronico() {
		return correoElectronico;
	}
	/**
	 * @param correoElectronico the correoElectronico to set
	 */
	public void setCorreoElectronico(String correoElectronico) {
		this.correoElectronico = correoElectronico;
	}
	/**
	 * @return the giro
	 */
	public String getGiro() {
		return giro;
	}
	/**
	 * @param giro the giro to set
	 */
	public void setGiro(String giro) {
		this.giro = giro;
	}
	/**
	 * @return the direcctor
	 */
	public String getDirector() {
		return director;
	}
	/**
	 * @param direcctor the direcctor to set
	 */
	public void setDirector(String direcctor) {
		this.director = direcctor;
	}
	/**
	 * @return the direccion
	 */
	public String getDireccion() {
		return direccion;
	}
	/**
	 * @param direccion the direccion to set
	 */
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	/**
	 * @return the rfc
	 */
	public String getRfc() {
		return rfc;
	}
	/**
	 * @param rfc the rfc to set
	 */
	public void setRfc(String rfc) {
		this.rfc = rfc;
	}
	
	public String getRa() {
		return ra;
	}
	public void setRa(String ra) {
		this.ra = ra;
	}
	/**
	 * @return the logoA
	 */
	public String getLogoA() {
		return logoA;
	}
	/**
	 * @param logoA the logoA to set
	 */
	public void setLogoA(String logoA) {
		this.logoA = logoA;
	}
	/**
	 * @return the logoB
	 */
	public String getLogoB() {
		return logoB;
	}
	/**
	 * @param logoB the logoB to set
	 */
	public void setLogoB(String logoB) {
		this.logoB = logoB;
	}
	/**
	 * @return the logoC
	 */
	public String getLogoC() {
		return logoC;
	}
	/**
	 * @param logoC the logoC to set
	 */
	public void setLogoC(String logoC) {
		this.logoC = logoC;
	}
	
	
}
