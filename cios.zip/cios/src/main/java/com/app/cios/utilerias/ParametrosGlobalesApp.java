package com.app.cios.utilerias;

import java.io.IOException;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * Esta clase tiene por objeto mantener el valor de los par�metros
 * Globales de la Aplicaci�n, los cuales est�n enfocados b�sicamente
 * a evitar cierta funcionalidad para fines de desarrollo.
 *
 * Implementada como singleton. Su uso requiere obtener la instancia
 * mediante ParametrosGlobalesApp.getInstance();
 */
public class ParametrosGlobalesApp implements java.io.Serializable {
	private static ParametrosGlobalesApp singleton = null;
	private static Properties parametros = null;

	private ParametrosGlobalesApp() {
	}

	public static synchronized ParametrosGlobalesApp getInstance() {
		if (singleton == null) {
			singleton = new ParametrosGlobalesApp();
		}
		return singleton;
	}

	/**
	 * Obtiene el valor del par�metro especificado.
	 * Si el par�metro no existe regresa una cadena vacia
	 * @return Cadena con el valor del par�metro
	 * @param clave Clave del parametro como esta
	 * 		definido en ParametrosGlobalesApp.properties
	 */
	public String getParametro(String clave) {
		if (parametros == null) {
			try {
				parametros = Comunes.loadParams("ParametrosGlobalesApp");
			} catch (IOException e) {
				//Se ignora el error y se crea un Porperties vacio
				parametros = new Properties();
			}
		}
		//si el valor no se encuentra, se regresa una cadena vacia
		String valorParametro = parametros.getProperty(clave, "");
		return valorParametro;
	}
}
