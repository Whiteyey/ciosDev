package com.app.cios.utilerias;

//import com.aspose.words.Document;

import java.io.File;
import java.util.Map;
import java.util.List;

import javax.mail.internet.InternetAddress;

import com.app.cios.utilerias.archivo.ArchivoBean;
import com.app.cios.utilerias.consulta.QueryBean;
//import com.app.cios.utilerias.usuarios.Usuario;

import org.apache.commons.logging.Log;

public class Validaciones {

	//Variable para enviar mensajes al log.
	private final static Log log = ServiceLocator.getInstance().getLog(Validaciones.class);
	
	private static final String emailRegex = "^([a-zA-Z0-9_\\.\\-])+\\@(([a-zA-Z0-9\\-])+\\.)+([a-zA-Z0-9]{2,4})+$";
	
	/**
	 *
	 * Revisa si el String proporcionado en el parametro: <tt>campo</tt> corresponde a un espacio en blanco o
	 * a una cadena vac�a.
	 *
	 * @param campo <tt>String</tt> a validar.
	 * @return <tt>boolean</tt> con valor <tt>true</tt> si se trata de un campo vac�o;
	 *         regresa <tt>false</tt> en caso contrario.
	 *
	 * @author Salim Hernandez
	 * @date 31/03/2014 05:22:23 p.m.
	 *
	 */
	public static boolean esVacio(String campo){
		
		boolean espacioEnBlanco = false;
		if( campo == null || campo.matches("^\\s*$") ){
			espacioEnBlanco = true;
		}
		return espacioEnBlanco;
		
	}
	
	/**
	 *
	 * Revisa si el <tt>Map</tt> ( <tt>LinkedHashMap</tt>, <tt>HashMap</tt>, etc) proporcionado en el 
	 * par�metro: <tt>campo</tt> es <tt>null</tt> o tiene 0 elementos.
	 *
	 * @param campo <tt>Map</tt> a validar.
	 * @return <tt>boolean</tt> con valor <tt>true</tt> si se trata de un campo vac�o;
	 *         regresa <tt>false</tt> en caso contrario.
	 *
	 * @author Salim Hernandez
	 * @date 22/04/2014 04:48:22 p.m.
	 *
	 */
	public static boolean esVacio(Map campo){
		
		boolean campoVacio = false;
		if( campo == null || campo.size() == 0 ){
			campoVacio = true;
		}
		return campoVacio;
		
	}
	
	/**
	 *
	 * Revisa si el <tt>List</tt> ( <tt>ArrayList</tt>, <tt>LinkedList</tt>, etc) proporcionado en el 
	 * par�metro: <tt>campo</tt> es <tt>null</tt> o tiene 0 elementos.
	 *
	 * @param campo <tt>List</tt> a validar.
	 * @return <tt>boolean</tt> con valor <tt>true</tt> si se trata de un campo vac�o;
	 *         regresa <tt>false</tt> en caso contrario.
	 *
	 * @author Salim Hernandez
	 * @date 24/04/2014 04:51:49 p.m.
	 *
	 */
	public static boolean esVacio(List campo){
		
		boolean campoVacio = false;
		if( campo == null || campo.size() == 0 ){
			campoVacio = true;
		}
		return campoVacio;
		
	}
	
	/**
	 *
	 * Revisa si el Object[] proporcionado en el parametro: <tt>campo</tt> corresponde a un array vacio o
	 * a un objeto nulo.
	 *
	 * @param campo <tt>Object[]</tt> a validar.
	 * @return <tt>boolean</tt> con valor <tt>true</tt> si viene vac�o;
	 *         o <tt>false</tt> en caso contrario.
	 *
	 * @author Salim Hernandez
	 * @date 15/05/2014 01:05:09 p.m.
	 *
	 */
	public static boolean esVacio(Object[] campo){
		
		boolean arrayVacio = false;
		if( campo == null || campo.length == 0 ){
			arrayVacio = true;
		}
		return arrayVacio;
		
	}
	
  /**
   * Este metodo valida una direccion de email
   *
   * <P>Regresa <tt>true</tt> si y solo si  <tt>emailAddress</tt> puede convertirse en 
   * una direccion de correo de internet {@link javax.mail.internet.InternetAddress} de acuerdo 
   * con el RFC822 pero con la restriccion que no pueden ir sin el dominio
   * <p>
   *	@param emailAddress 	Direccion de correo que se validara
   *	@param boolean 		Resultado de la validacion: <tt>true</tt> si la direccion de correo
   *								es valida, <tt>false</tt> en caso contrario
   */
  public static boolean esDireccionCorreo(String emailAddress){
  	  
  	 if ( emailAddress == null ){
  	 	 return false;
  	 }
  	 
    try {
    	 
			//La direccion de correo cumple con el RFC 822
			InternetAddress 	emailAddr 	= new InternetAddress(emailAddress);	
      
			// Existen nombre y dominio en la direccion ( y subdominios )
			if( !emailAddress.matches(Validaciones.emailRegex) ){
				return false;
			}
		
			// Esta seccion la dejo comentada con por causa de la carga masiva de proveedores, ya que cuando
			// no se conoce la direccion de correo se ingresa una direccion de la forma correo@correo, 
			// Lo que ocasionaria que no se pudiera dar de alta el proveedor
		
			// Verficar que haya al menos un subdominio especificado
			//tokens = getListTokenizer(dominio,".");
			//if(tokens.size() < 2) return false;
			//String campo = null;
			//for(int indice=0;indice<tokens.size();indice++){
			//	campo = tokens.get(indice).toString();
			//	if(campo.length()< 1) return false;
			//}
			// Verificar longitud del dominio superior (debe ser de entre 2 y 6 caracteres)
			//if(campo.length()<2 || campo.length()>6) return false;
		
    } catch (Exception e){
    	return false;
    }
    
    return true;
    
  }
  
  /**
   * Este m�todo valida una lista de direcciones de email.
   *
   * <P>Regresa <tt>true</tt> si y solo si  los elementos de <tt>emailAddressList</tt> pueden convertirse en 
   * en direcciones de correo de internet {@link javax.mail.internet.InternetAddress} de acuerdo 
   * con el RFC822 pero con la restriccion que no pueden ir sin el dominio.
   * <p>
   *	@param emailAddressesList 	Direcciones de correo que se validaran.
   *	@param boolean 				Resultado de la validacion: <tt>true</tt> si la direccion de correo
   *										es valida, <tt>false</tt> en caso contrario.
   */
  public static boolean esListaDireccionesCorreo(String emailAddressList){
  	  
  	 if ( emailAddressList == null ){
  	 	 return false;
  	 }
  	 
    try {

		String[] tokens = emailAddressList.split(",",-1);
		for (int i=0;i<tokens.length;i++) {
			String item = tokens[i].trim();
			//Existen nombre y dominio en la direccion
			if( !esDireccionCorreo(item) ){
				return false;
			}
    	}
		
    } catch (Exception e){
    	return false;
    }
    
    return true;
    
  }
  
  /**
	 *
	 * Revisa si el archivo indicado en <tt>rutaAbsolutaArchivo</tt> existe, no es un
	 * directorio y se puede leer.
	 *
	 * @param rutaAbsolutaArchivo <tt>rutaAbsolutaArchivo</tt> a validar.
	 * @return <tt>boolean</tt> con valor <tt>true</tt> si el archivo es valido;
	 *         y <tt>false</tt> en caso contrario.
	 *
	 * @author Salim Hernandez
	 * @date 15/04/2014 05:37:33 p.m.
	 *
	 */
  public static boolean esArchivoValido(String rutaAbsolutaArchivo){
  	  
  	 if ( rutaAbsolutaArchivo == null ){
  	 	 return false;
  	 }
  	 
    try {

		 File f = new File(rutaAbsolutaArchivo);
		 if( !f.exists() || !f.canRead() || f.isDirectory() ) {  // Debug info: pendiente validar.
		 	return false; 
		 }
		
    } catch (Exception e){
    	return false;
    }
    
    return true;
    
  }
  
   /**
	 *
	 * Revisa si el archivo indicado en <tt>rutaAbsolutaArchivo</tt> existe, no es un
	 * directorio y se puede leer.
	 *
	 * @param rutaAbsolutaArchivo <tt>rutaAbsolutaArchivo</tt> a validar.
	 * @return <tt>boolean</tt> con valor <tt>true</tt> si el archivo es valido;
	 *         y <tt>false</tt> en caso contrario.
	 *
	 * @author Salim Hernandez
	 * @date 23/04/2014 12:42:35 p.m.
	 *
	 */
  public static boolean esArchivoValido( ArchivoBean archivoBean ){
  	  
  	 if ( archivoBean == null ){
  	 	 return false;
  	 }
  	 
    return esArchivoValido( archivoBean.getRutaAbsoluta() );
    
  }
  
  	/**
	 * Valida que el objeto cadena no exceda la longitud m�xima.
	 *
	 * @param cadena String a validar
	 * @param longitudMaxima Longitud M�xima de la cadena
	 *
	 * @return <tt>boolean</tt> con valor <tt>true</tt> si la cadena excede la longitud m�xima;
	 *         y <tt>false</tt> en caso contrario.
	 *
	 * @author Salim Hernandez
	 *
	 */
	public static boolean excedeLongitudMaxima( String cadena, int longitudMaxima ){
		
		if ( cadena != null && cadena.length() > longitudMaxima ) {
			return true;
		}
		return false;
		
	}
	
	/**
	 * Valida que el objeto archivoBean no exceda la longitud m�xima.
	 *
	 * @param archivoBean <tt>ArchivoBean</tt> a validar.
	 * @param longitudMaxima Longitud M�xima permitida del archivo.
	 *
	 * @return <tt>boolean</tt> con valor <tt>true</tt> si se excede la longitud m�xima;
	 *         y <tt>false</tt> en caso contrario.
	 *
	 * @author Salim Hernandez
	 * @since 30/04/2014 12:33:21 p.m.
	 *
	 */
	public static boolean excedeLongitudMaxima( ArchivoBean archivoBean, long longitudMaxima ){
		
		boolean excedeLongitud = false;
		try {
			
			File   file			  = new File(archivoBean.getRutaAbsoluta());
			if( file.length() > longitudMaxima ){
				excedeLongitud = true;
			}
			
		} catch(Exception e){
			excedeLongitud = false;
		}
		
		return excedeLongitud;
		
	}
	
	/**
	 * Valida que el objeto archivoBean cumpla con la extensi�n requerida.
	 *
	 * @param archivoBean <tt>ArchivoBean</tt> a validar.
	 * @param extensionRequerida <tt>String</tt> con la extensi�n a verificar.
	 *
	 * @return <tt>boolean</tt> con valor <tt>true</tt> si cumple con la extensi�n requerida;
	 *         y <tt>false</tt> en caso contrario.
	 *
	 * @author Salim Hernandez
	 * @since 30/04/2014 12:33:21 p.m.
	 *
	 */
	public static boolean tieneExtensionRequerida( ArchivoBean archivoBean, String extensionRequerida ){
		
		boolean tieneExtensionRequerida = false;
		try {

			tieneExtensionRequerida = tieneExtensionRequerida( archivoBean.getRutaAbsoluta(), extensionRequerida);
						
		} catch(Exception e){
			tieneExtensionRequerida = false;
		}
		
		return tieneExtensionRequerida;
		
	}
	
	/**
	 * Valida que el objeto archivoBean cumpla con la extensi�n requerida.
	 *
	 * @param nombreArchivo <tt>String</tt> con el nombre del archivo a validar.
	 * @param extensionRequerida <tt>String</tt> con la extensi�n a verificar.
	 *
	 * @return <tt>boolean</tt> con valor <tt>true</tt> si cumple con la extensi�n requerida;
	 *         y <tt>false</tt> en caso contrario.
	 *
	 * @author Salim Hernandez
	 * @since 19/05/2014 01:12:27 p.m.
	 *
	 */
	public static boolean tieneExtensionRequerida( String nombreArchivo, String extensionRequerida ){
		
		boolean tieneExtensionRequerida = false;
		try {
			
			if ( nombreArchivo.matches("(?i).+\\Q" + extensionRequerida + "\\E$") ){
				tieneExtensionRequerida = true;
			}
			
		} catch(Exception e){
			tieneExtensionRequerida = false;
		}
		
		return tieneExtensionRequerida;
		
	}
	
	/**
	 * Valida que el objeto archivoBean cumpla con la extensi�n requerida.
	 *
	 * @param archivoBean <tt>ArchivoBean</tt> a validar.
	 * @param extensionesRequeridas <tt>String</tt> con la extensi�n a verificar.
	 *
	 * @return <tt>boolean</tt> con valor <tt>true</tt> si cumple con la extensi�n requerida;
	 *         y <tt>false</tt> en caso contrario.
	 *
	 * @author Salim Hernandez
	 * @since 30/04/2014 12:55:43 p.m.
	 *
	 */
	public static boolean tieneExtensionRequerida( ArchivoBean archivoBean, String[] extensionesRequeridas ){
		
		boolean tieneExtensionRequerida = false;
		try {
			
		   tieneExtensionRequerida = tieneExtensionRequerida(  archivoBean.getRutaAbsoluta(), extensionesRequeridas );
			
		} catch(Exception e){
			tieneExtensionRequerida = false;
		}
		
		return tieneExtensionRequerida;
		
	}
	
	/**
	 * Valida que el objeto archivoBean cumpla con la extensi�n requerida.
	 *
	 * @param nombreArchivo <tt>String</tt> con el nombre del archivo a validar.
	 * @param extensionesRequeridas <tt>String</tt> con la extensi�n a verificar.
	 *
	 * @return <tt>boolean</tt> con valor <tt>true</tt> si cumple con la extensi�n requerida;
	 *         y <tt>false</tt> en caso contrario.
	 *
	 * @author Salim Hernandez
	 * @since 19/05/2014 01:15:26 p.m.
	 *
	 */
	public static boolean tieneExtensionRequerida( String nombreArchivo, String[] extensionesRequeridas ){
		
		boolean tieneExtensionRequerida = false;
		try {
			
			for(int i=0;i<extensionesRequeridas.length;i++){
				if ( nombreArchivo.matches("(?i).+\\Q" + extensionesRequeridas[i] + "\\E$") ){
					tieneExtensionRequerida = true;
					break;
				}
			}
			
		} catch(Exception e){
			tieneExtensionRequerida = false;
		}
		
		return tieneExtensionRequerida;
		
	}

	/**
	 * Valida que el objeto archivoBean tenga al menos un campo de combinacion de correspondencia.
	 * Esta validaci�n s�lo es �til para archivos con formato: .docx y doc.
	 *
	 * @param archivoBean <tt>ArchivoBean</tt> a validar.
	 *
	 * @return <tt>boolean</tt> con valor <tt>true</tt> si tiene campos;
	 *         y <tt>false</tt> en caso contrario.
	 *
	 * @author Salim Hernandez
	 * @since 13/05/2014 06:44:35 p.m.
	 *
	 */
//	public static boolean tieneCamposCombinacionCorrespondencia( ArchivoBean archivoBean ){
//		
//	   // Cargar archivo en WORD
//	   Document doc         = null;
//	   boolean  tieneCampos = false;
//		try {
//			
//			String rutaAbsolutaArchivo = archivoBean.getRutaAbsoluta();
//		   doc = new Document(archivoBean.getRutaAbsoluta());
//			if( doc.getMailMerge().getFieldNames().length > 0 ){
//			   tieneCampos = true;
//			}
//						
//		} catch(Exception e){
//			tieneCampos = false;
//		}
//		
//		return tieneCampos;
//		
//	}
	
	/**
	 *
	 * Verifica que se haya proporcionado un numero positivo; no permite notacion cientifica.
	 *
	 * @param numero    Numero a validar.
	 *
	 * @return <tt>true</tt> si la validaci�n es exitosa y <tt>false</tt> en caso contrario.
	 *
	 */
	public static boolean esNumeroPositivo(
		String        numero
	){
	
		boolean error = false;
		try{
			numero = numero.trim();
			if( !numero.matches("[\\d]+[\\.]?") && !numero.matches("[\\d]*[\\.][\\d]+") ){
				error = true;
			}
		}catch(Exception e){
			error = true;
		}
		return !error;
		
	}
	
	/**
	 *
	 * Valida la longitud de un campo entero o decimal.
	 *
	 * Nota: Una precision de 5 y una escala de 2, permiten tener 3 enteros y 2 decimales
	 *
	 * @debugInfo Se consideran dentro de la parte entera los signos: '-' '+', lo podr�a
	 * ocasionar una validacion erronea de la precion
	 *
	 * @param numero      Valor del campo a Validar
	 * @param precision   Numero de digitos que conforman el valor
	 * @param decimales   Numero de digitos permitidos como decimales
	 *
	 * @return            <tt>false</tt> si cualquiera de las partes del n�mero excede la precisi�n 
	 *                    especificada. <tt>true</tt> en caso contrario.
	 *
	 */
	public static boolean cumplePrecisionDecimal(
			String        numero,
			int           precision, 
			int           decimales
	){
	
		boolean validacion    = true;
		numero                = numero == null?"":numero;

		String[] componentes  = numero.split("\\.",-1);
		
		String   parteEntera  = componentes.length > 0?componentes[0]:""; 
		String   parteDecimal = componentes.length > 1?componentes[1]:""; 

		if (        parteDecimal.length() > decimales              ) {
			//Error. El numero de decimales es mayor al especificado
			validacion = false;
		} else if ( parteEntera.length() > precision - decimales   ) {
			//Error. El numero de enteros es mayor al permitido
			validacion = false;
		}

		return validacion;
		
	}
		
	/**
	 * Verifica si el usuario proporcionado posee el rol indicado.
	 * @throws AppException
	 *
	 * @param icProyecto  <tt>int</tt> con el id del proyecto a validar.
	 * @param usuario     <tt>Usuario</tt> cuyo rol ser� validado.
	 * @param rol   		 <tt>String</tt> con el rol a validar.
	 *
	 * @return            <tt>true</tt> si el usuario especificado posee el rol indicado
	 *							 y false en caso contrario. 						
	 *
	 */
//	public static boolean tieneRol(
//		int 	  icProyecto,
//		Usuario usuario,
//		String  rol
//	){
//	
//		boolean poseeRol = false;
//		
//		if( 			icProyecto 	<  1 			){
//			poseeRol = false;
//			return poseeRol;
//		} else if(	usuario 		== null 		){
//			poseeRol = false;
//			return poseeRol;
//		} else if( 	rol 			== null 		){
//			poseeRol = false;
//			return poseeRol;
//		} else if( 	rol.matches("^\\s*$")	){
//			poseeRol = false;
//			return poseeRol;
//		}
//		
//		try {
//			
//			QueryBean query = new QueryBean();
//			query.appendQueryString(
//				"SELECT                                             "  +
//				"   DECODE(COUNT(1),0,'false','true') AS POSEE_ROL  "  +
//				"FROM                                               "  +
//				"   SGAPS_USUARIO_PROYECTO                          "  +
//				"WHERE                                              "  +
//				"   CC_USUARIO  = ? AND                             "  +
//				"   IC_PROYECTO = ? AND                             "  +
//				"   CC_ROL      = ?                                 "
//			);
//			query.appendCondition(usuario.getLogin());
//			query.appendCondition(icProyecto);
//			query.appendCondition(rol);
//			
//			Registros registros = AccesoDB.consultarDB(query);
//			if( registros.next() ){
//				poseeRol = "true".equals( registros.getString("POSEE_ROL") )?true:false;
//			}
//			
//		} catch(Exception e){
//			
//			poseeRol = false;
//			
//			log.error("tieneRol(Exception)");
//			log.error("tieneRol.usuario = <" + usuario + ">");
//			log.error("tieneRol.rol     = <" + rol     + ">");
//			e.printStackTrace();
//			
//			throw new AppException("No se pudo validar el rol del usuario: " + e.getMessage());
//			
//		}
//		
//		return poseeRol;
//			
//	}
	
}
