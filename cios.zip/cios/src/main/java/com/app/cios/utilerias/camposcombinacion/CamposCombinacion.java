//package com.app.cios.utilerias.camposcombinacion;
//
//import com.aspose.words.Document;
//
//import com.aspose.words.IFieldMergingCallback;
//
//import java.util.Iterator;
//import java.util.LinkedHashMap;
//import java.util.List;
//
//import java.util.Map;
//
//import com.app.cios.utilerias.AppException;
//import com.app.cios.utilerias.Comunes;
//import com.app.cios.utilerias.Registros;
//import com.app.cios.utilerias.ServiceLocator;
//
//import org.apache.commons.logging.Log;
//
///**
// * Clase que se encarga de crear archivos de word y pdf a partir de plantillas con campos de
// * combinacion de correo mediante el uso de un objeto de datos, el cual debe implementar
// * la interface <tt>IDatosCamposCombinacion</tt>.
// *
// * @author jshernandez
// * @date 19/03/2014 10:50:13 a.m.
// *
// */
//public class CamposCombinacion {
//
//	//Variable para enviar mensajes al log.
//	private static final Log log = ServiceLocator.getInstance().getLog(CamposCombinacion.class);
//	
//	public static final String EXTENSION_PDF		= ".pdf"; 
//	public static final String EXTENSION_DOC		= ".doc";
//	public static final String EXTENSION_DOCX		= ".docx";
//	
//	private IDatosCamposCombinacion datosCamposCombinacion;
//	
//	/**
//	 * Asigna el objeto de datos que se combinar� con la plantilla para crear el documento de word requerido.
//	 *
//	 * @param datosCamposCombinacion Objeto de datos, de tipo <tt>IDatosCamposCombinacion</tt>.
//	 *
//	 */
//	public void setIDatosCamposCombinacion(IDatosCamposCombinacion datosCamposCombinacion){
//		this.datosCamposCombinacion = datosCamposCombinacion;
//	}
//	
//	/**
//	 * Crea un archivo con extension indicada en el par�metro: <tt>extension</tt>, cuyo nombre
//	 * lo regresa en primer elemento del parametro <tt>nombreArchivo</tt>. En caso de que haya
//	 * errores, estos se regresan en el objeto <tt>errores</tt>. Es requisito que la validacion
//	 * del m�todo <tt>validaPlantilla</tt> del objeto que implementa la interfaz 
//	 * <tt>IDatosCamposCombinacion</tt> regrese true, para que el archivo pueda ser creado
//	 * exitosamente.
//	 *
//	 * @throws Exception
//	 * 
//	 * @param error	     <tt>String[]</tt> en cuyo primer elemento viene un error, que no es
//	 *							  espec�fico a un campo de combianci�n de correspondencia.
//	 * @param erroresCampo <tt>List</tt> con los errores en los campos de combinaci�n de correo.
//	 * @param nombreArchivo <tt>String</tt> array con el nombre del archivo generado en el 
//	 *                      primer elemento.
//	 * @param extension <tt>String</tt> con el nombre de la extension se usar� para crear
//	 *                  el documento, los valores posibles son: <tt>EXTENSION_PDF</tt>, 
//	 *                  <tt>EXTENSION_DOC</tt> y <tt>EXTENSION_DOCX</tt>.
//	 *
//	 * @return <tt>true</tt> si la creaci�n del  archivo fue exitosa y <tt>false</tt> en caso 
//	 * contrario.
//	 *
//	 */
//	public boolean creaArchivo( String[] error, List erroresCampo, String[] nombreArchivo, String extension )
//		throws Exception {
//		
//		try {
//
//			// Validar extension
//			boolean extensionValida = false;
//			if(        EXTENSION_PDF.equalsIgnoreCase(extension)  ){
//				extensionValida = true;
//			} else if( EXTENSION_DOC.equalsIgnoreCase(extension)  ){
//				extensionValida = true;
//			} else if( EXTENSION_DOCX.equalsIgnoreCase(extension) ){
//				extensionValida = true;
//			}
//			if( !extensionValida ){
//				throw new AppException("La extensi�n especificada no es v�lida: " + extension );
//			}
//	
//			// Validar que se haya especificado al menos un Data Source
//			Registros      registrosRaiz     = this.datosCamposCombinacion.getDataSourceRaiz();
//			Registros      registrosTabla    = this.datosCamposCombinacion.getDataSourceTabla();
//         LinkedHashMap  registrosTabla01  = this.datosCamposCombinacion.getDataSourcesTabla(); 
//			if( registrosRaiz == null && registrosTabla == null && registrosTabla01 == null ){
//				throw new AppException("Se requiere que especifique al menos un Data Source");
//			}
//			
//			// Validar que se haya especificado el nombre de la tabla
//			String nombreTabla = this.datosCamposCombinacion.getDataSourceNombreTabla();
//			if( registrosTabla != null && nombreTabla == null ){
//				throw new AppException("Se especifico el data source de la tabla con campos de combinacion, pero no se especific� su nombre");
//			} else if( registrosTabla01 != null ){
//            Iterator iterator = registrosTabla01.entrySet().iterator();
//            while(iterator.hasNext()){
//               Map.Entry   entry             = (Map.Entry) iterator.next();
//               String      nombreTabla02     = (String) entry.getKey();
//               Registros   registrosTabla02  = (Registros) entry.getValue(); 
//               if( registrosTabla02 != null && nombreTabla02 == null ){
//                  throw new AppException("Se especifico el data source tabla con campos de combinacion, pero no se especific� su nombre");
//               }
//            }
//         }
//			
//			// Validar que se haya especificado la ruta del directorio temporal donde se crear� el archivo.
//			String rutaDirectorioTemporal = this.datosCamposCombinacion.getRutaDirectorioTemporal();
//			if( rutaDirectorioTemporal == null ){
//				throw new AppException("No se especific� la ruta del directorio temporal donde se crear� el archivo");
//			}
//			
//			// Cargar archivo en WORD
//			Document doc = new Document(this.datosCamposCombinacion.getRutaPlantilla());
//			
//			// Validar plantilla
//			String[] nombresCampo = doc.getMailMerge().getFieldNames();
//			if( !this.datosCamposCombinacion.validaPlantilla( error, erroresCampo, nombresCampo ) ){
//				nombreArchivo[0] = null;
//				return false;
//			} 
// 
//			// Debug info: Por el momento esta opci�n queda deshabilitada, se usar� para subrayar campos
//		   // de combinaci�n sin valor.
//		   IFieldMergingCallback fieldMergingCallback = this.datosCamposCombinacion.getFieldMergingCallback();
//		   if(fieldMergingCallback != null ){
//		   	doc.getMailMerge().setFieldMergingCallback(fieldMergingCallback);
//		   }
//		   
//			// Combinar Datos con Plantilla
//			AuxiliarCamposCombinacion dataSource = null; 
//			if( registrosRaiz  != null ){
//				dataSource = new AuxiliarCamposCombinacion(registrosRaiz);
//				doc.getMailMerge().execute(dataSource);
//			}
//			if( registrosTabla != null ){
//				dataSource = new AuxiliarCamposCombinacion(registrosTabla,nombreTabla);
//				doc.getMailMerge().executeWithRegions(dataSource);
//			} 
//		   if( registrosTabla01 != null ){
//            Iterator iterator = registrosTabla01.entrySet().iterator();
//            while(iterator.hasNext()){
//               Map.Entry   entry             = (Map.Entry) iterator.next();
//               String      nombreTabla02     = (String) entry.getKey();
//               Registros   registrosTabla02  = (Registros) entry.getValue(); 
//		       
//               dataSource = new AuxiliarCamposCombinacion(registrosTabla02,nombreTabla02);
//               doc.getMailMerge().executeWithRegions(dataSource);
//            }
//         }
//
//			// Generar nombre aleatorio del archivo
//			nombreArchivo[0] 	= Comunes.cadenaAleatoria(16) + extension;
//			
//			// Generar la ruta fisica del archivo
//			String loginUsuario  	= this.datosCamposCombinacion.getLoginUsuario();
//			String rutaArchivo		= null;
//			if( loginUsuario != null ){
//				rutaArchivo 			= rutaDirectorioTemporal + loginUsuario + "." + nombreArchivo[0];
//			} else {
//				rutaArchivo 			= rutaDirectorioTemporal + nombreArchivo[0];     
//			}
//			
//			
//		   
//			// Guardar archivo con los datos combinados
//			doc.save(rutaArchivo);
//			
//		} catch(Exception e ){
//
//			log.error("creaArchivo(Exception)");
//			log.error("creaArchivo.error         = <" + error         + ">");
//			log.error("creaArchivo.erroresCampo  = <" + erroresCampo  + ">");
//			log.error("creaArchivo.nombreArchivo = <" + nombreArchivo + ">");
//			log.error("creaArchivo.extension     = <" + extension     + ">");
//			e.printStackTrace();
//
//			throw e;
//			
//		}
//		
//		return true;
//		
//	}
//			
//	/**
//	 *
//	 * M�todo que se encarga de validar la plantilla indicada en el m�todo: <tt>getRutaPlantilla()</tt>.
//	 * Regresa <tt>true</tt> si la validaci�n es exitosa y <tt>false</tt> en caso contrario.
//	 * En el parametro <tt>errores</tt>, se regresa todos los errores encontrados en la validaci�n.
//	 * @throws Exception
//	 * 
//	 * @param error	     <tt>String[]</tt> en cuyo primer elemento viene un error, que no es
//	 *							  espec�fico a un campo de combianci�n de correspondencia.
//	 * @param erroresCampo <tt>List</tt> con los errores en los campos de combinaci�n de correo.
//	 *
//	 * @return <tt>true</tt> si la validaci�n fue exitosa y <tt>false</tt> en caso contrario.
//	 *
//	 */
//	public boolean validaPlantilla( String[] error, List erroresCampo )
//		throws Exception {
//	
//		// Cargar archivo en WORD
//		Document doc 	= null;
//		boolean  exito = true;
//		
//		try {
//		
//			doc = new Document(this.datosCamposCombinacion.getRutaPlantilla());
//		
//			// Validar plantilla
//			String[] nombresCampo = doc.getMailMerge().getFieldNames();
//			if( !this.datosCamposCombinacion.validaPlantilla( error, erroresCampo, nombresCampo ) ){
//				exito = false;
//			} 
//	
//	   } catch(Exception e) {
//	   	
//			exito  = false;
//			
//			log.error("validaPlantilla(Exception)");
//			log.error("validaPlantilla.error   = <" + error         + ">");
//			log.error("validaPlantilla.errores = <" + erroresCampo  + ">");
//			e.printStackTrace();
//			
//	      throw e;
//	      
//	   }
//		
//		return exito;
//		
//	}
//	
//}
