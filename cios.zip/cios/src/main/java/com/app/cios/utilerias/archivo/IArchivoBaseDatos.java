package com.app.cios.utilerias.archivo;

import com.app.cios.utilerias.AccesoDB;

/**
 * Interface que se utiliza para facilitar la inserci�n y/o extracci�n de archivo
 * de la Base de Datos, solicitando al usuario, unicamente que defina los m�todos 
 * siguientes.
 * 
 * @author jshernandez
 * @date 22/04/2014 03:18:27 p.m.
 */
public interface IArchivoBaseDatos {
	
	/**
	 * Ruta del directorio temporal donde se creara el documento de xls con los datos de
	 * la lista. Este campo es obligatorio.
	 * 
	 * @return <tt>String</tt> con la ruta f�sica del directorio temporal.
	 */
	String  getRutaDirectorioTemporal();
	
	/**
	 * Devuelve el login del usuario que creo el archivo.
	 *
	 * @return <tt>String</tt> con el login del usuario que creo el archivo. 
	 * <tt>null</tt> si esta funcionalidad no es requerida.
	 */
	public String  getLoginUsuario();
		
	
	/**
	 * Regresa la conexion a la Base de Datos.
	 * IMPORTANTE: Si se trata de una transacci�n, este m�todo deber� regresar la conexion a la base de datos, en caso contrario
	 * deber� regresar <tt>null</tt>.
	 */
	public AccesoDB getAccesoDB();
	
	/**
	 * Este m�todo debe regresar un <tt>ArchivoStatement</tt> con los atributos necesarios
	 * para extraer un archivo de la Base de Datos.
	 * Se deber� regresar <tt>null</tt> cuando no se requiera hacer uso de esta 
	 * funcionalidad.
	 *
	 * @return <tt>ArchivoStatement</tt> configurado para la extraccion de archivos.
	 */
	public ArchivoStatement getStatementExtraeArchivo();
	
	/**
	 * Este m�todo debe regresar un <tt>ArchivoStatement</tt> con los atributos necesarios
	 * para actualizar/insertar un archivo de la Base de Datos.
	 * Se deber� regresar <tt>null</tt> cuando no se requiera hacer uso de esta 
	 * funcionalidad.
	 *
	 * @return <tt>ArchivoStatement</tt> configurado para la insercion de archivos.
	 */
	public ArchivoStatement getStatementGuardaArchivo();
	
	

}
