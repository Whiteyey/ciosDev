package com.app.cios.utilerias.archivo;

import java.sql.Types;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;

import java.util.Map;

import com.app.cios.utilerias.AppException;
import com.app.cios.utilerias.ServiceLocator;
import com.app.cios.utilerias.Validaciones;

import org.apache.commons.logging.Log;

/**
 * Objeto de propiedades que facilita la extracci�n / inserci�n de archivos de la base de datos.<br>
 * <br>
 * Ejemplo de Configuraci�n para la extracci�n de un archivo:<br>
 * <pre>
 * <code>
 *    // IMPORTANTE: Si se trata de una transacci�n, el m�todo: IArchivoBaseDatos.getAccesoDB() deber� regresar la 
 *    // conexion a la base de datos, en caso contrario deber� regresar null.
 *     
 *    archivoStatement.setTable("SGAPS_BIT_ENVIO_EMAIL_ARCH");
 *    archivoStatement.setColumnArchivo("BI_ARCHIVO");
 *    archivoStatement.setColumnExtension("CG_NOMBRE"); 
 *    // Especificar el siguiente atributo en caso de que no se haya especificado el atributo columnExtension.
 *    // archivoStatement.setExtension(".zip"); 
 *    archivoStatement.addParameter("IC_ENVIO_EMAIL",icEnvioEmailValue);
 *    archivoStatement.addParameter("IC_ENVIO_EMAIL_ARCH",icEnvioEmailArchValue);
 *    archivoStatement.addField("BI_ARCHIVO","nombreArchivo");
 *    archivoStatement.addField("CG_NOMBRE","tituloArchivo"); 
 * </code>
 * </pre>
 * Ejemplo de Configuraci�n para guardar un archivo:<br>
 * <pre>
 * <code>
 *    // IMPORTANTE: Si se trata de una transacci�n, el m�todo: IArchivoBaseDatos.getAccesoDB() deber� regresar la 
 *    // conexion a la base de datos, en caso contrario deber� regresar null.
 *     
 *    archivoStatement.setTable("SGAPS_BIT_ENVIO_EMAIL_ARCH");
 *    archivoStatement.setColumnArchivo("BI_ARCHIVO");
 *    archivoStatement.addPrimaryKeyParameter("IC_ENVIO_EMAIL",		icEnvioEmailValue );
 *    archivoStatement.addPrimaryKeyParameter("IC_ENVIO_EMAIL_ARCH",	icEnvioEmailArchValue);
 *    archivoStatement.addParameter("BI_ARCHIVO",				archivoBean);
 *    archivoStatement.addParameter("CG_NOMBRE",				"Reporte Proyecto.pdf");
 *    archivoStatement.addParameter("CS_TIPO",					"H"); // HTML
 *    archivoStatement.addField("CG_NOMBRE",  "tituloArchivo"); // Se puede utilizar el addField para indicar que propiedades adicionales del ArchivoBean se llenar�n 
 * </code>
 * </pre>
 * @author jshernandez
 * @since 22/04/2014 01:11:31 p.m.
 */
public class ArchivoStatement {

	public static final int UNDEFINED 	= 100; // El usuario no especific� el tipoStatement.
	public static final int SELECT 		= 101; // El uso de este tipoStatement en la extracci�n es opcional.
	public static final int UPDATE 		= 102; // El usuario especificamente requiere que se realice un insert.
	public static final int INSERT 		= 103; // El usuario especificamente requiere que se realice un update.
	
	public ArchivoStatement() {
		this.parameters 				= new LinkedHashMap();
		this.nullParametersTypes 	= new HashMap();
		this.primaryKeys				= new LinkedHashMap();
		this.fields 	 				= new LinkedHashMap();
		this.tipoStatement			= ArchivoStatement.UNDEFINED;
	}
	//Variable para enviar mensajes al log.
	
	private static final Log log = ServiceLocator.getInstance().getLog(ArchivoStatement.class);

	// Atributos de la Clase
	
	private String 			table;
	private LinkedHashMap	parameters;
	private LinkedHashMap	fields;
	private String 			columnArchivo;
	private String 			columnExtension;
	private String 			extension;
	private int 				tipoStatement;	
	
	private HashMap			nullParametersTypes; // Variable de apoyo para parametros nulos
	private LinkedHashMap	primaryKeys;         // Variable de apoyo para indetificar la llave primaria de la tabla, se requiere en el guardado para
	// para los tipos de Statement: UNDEFINED, UPDATE e INSERT.
	
	// setters / getters
	
	public String getTable() {
		return table;
	}

	public void setTable(String table) {
		this.table = table;
	}

	public LinkedHashMap getParameters() {
		return parameters;
	}

	public void setParameters(LinkedHashMap parameters, HashMap nullParametersTypes, LinkedHashMap primaryKeys ) {
		
		this.parameters = parameters;
		
		if( nullParametersTypes != null ){
			this.nullParametersTypes = nullParametersTypes;
		} else {
			this.nullParametersTypes.clear();
		}
		
		if( primaryKeys != null ){
			this.primaryKeys = primaryKeys;
		} else {
			this.primaryKeys.clear();
		}
		
	}
	
	public void setParameters(LinkedHashMap parameters ) {
		setParameters( parameters, null, null );
	}
	
	public LinkedHashMap getFields() {
		return fields;
	}

	public void setFields(LinkedHashMap fields) {
		this.fields = fields;
	}

	public String getColumnArchivo() {
		return columnArchivo;
	}

	public void setColumnArchivo(String columnArchivo) {
		this.columnArchivo = columnArchivo;
	}

	public String getColumnExtension() {
		return columnExtension;
	}

	public void setColumnExtension(String columnExtension) {
		this.columnExtension = columnExtension;
	}

	public String getExtension() {
		return extension;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}

	public int getTipoStatement() {
		return tipoStatement;
	}

	public void setTipoStatement(int tipoStatement) {
		this.tipoStatement = tipoStatement;
	}

	public HashMap getNullParametersTypes() {
		return nullParametersTypes;
	}

	// Nota: Se recomienda utilizar la version sobrecargada del metodo setParameters
	public void setNullParametersTypes(HashMap nullParametersTypes) {
		this.nullParametersTypes = nullParametersTypes;
	}

	public LinkedHashMap getPrimaryKeys() {
		return primaryKeys;
	}

	// Nota: Se recomienda utilizar la version sobrecargada del metodo setParameters
	public void setPrimaryKeys(LinkedHashMap primaryKeys) {
		this.primaryKeys = primaryKeys;
	}

	// M�todos auxiliares
	
	public void clearParameters(){
		this.parameters.clear();
		this.nullParametersTypes.clear();
	   this.primaryKeys.clear();
	}
	
	public void clearFields(){
		this.fields.clear();
	}
	
	public void addNullParameter( String parameterName, int types ){
		if(        !Validaciones.esVacio(parameterName) && types == Types.BLOB ){
			if( !parameterName.equalsIgnoreCase(this.columnArchivo) ){
				throw new AppException("ArchivoStatement.addParameter: parameterName debe coincidir con el parametro columnArchivo ya que especific� un objeto BLOB como valor.");
			}
			this.parameters.put(parameterName,null);
			this.nullParametersTypes.put(parameterName, new Integer(types) );
		} else if( !Validaciones.esVacio(parameterName) ){
			this.parameters.put(parameterName,null);
			this.nullParametersTypes.put(parameterName, new Integer(types) );
		} else {
			throw new AppException("ArchivoStatement.addNullParameter: parameterName no puede ser null, cadena vac�a o solo contener espacios en blanco.");	
		}
	}
	
	public void addPrimaryKeyParameter( String parameterName, Object value ){
		
		if(        !Validaciones.esVacio(parameterName) && value != null && value instanceof ArchivoBean ){
			throw new AppException("ArchivoStatement.addPrimaryKeyParameter: parameterName no puede tener un archivoBean como valor si se requiere utilizarlo como llave primaria.");
		} else if( !Validaciones.esVacio(parameterName) && value != null ){
			this.primaryKeys.put(parameterName,value);
			this.parameters.put(parameterName,value);
		} else {
			throw new AppException("ArchivoStatement.addPrimaryKeyParameter: parameterName no puede ser null, cadena vac�a o solo contener espacios en blanco; el parametro value no puede ser null.");	
		}
		
	}
	
	public void addParameter( String parameterName, Object value ){
		if(        !Validaciones.esVacio(parameterName) && value != null && value instanceof ArchivoBean ){
			if( !parameterName.equalsIgnoreCase(this.columnArchivo) ){
				throw new AppException("ArchivoStatement.addParameter: parameterName debe coincidir con el parametro columnArchivo ya que especific� un objeto ArchivoBean como valor.");
			}
			this.parameters.put(parameterName,value);
		} else if( !Validaciones.esVacio(parameterName) && value != null ){
			this.parameters.put(parameterName,value);
		} else {
			throw new AppException("ArchivoStatement.addParameter: parameterName no puede ser null, cadena vac�a o solo contener espacios en blanco; el parametro value no puede ser null.");	
		}
	}
	
	public void addField( String field, String alias ){
		if( !Validaciones.esVacio(field) && !Validaciones.esVacio(alias) ){
			this.fields.put(field,alias);
		} else {
			throw new AppException("ArchivoStatement.addField: Ninguno de los parametros puede ser null, cadena vac�a o solo contener espacios en blanco.");	
		}
	}
	
	public void dump(){
		
		log.error("ArchivoStatement.table              = <" + table              + ">");
		log.error("ArchivoStatement.parameters         = <" + parameters         + ">");
		log.error("ArchivoStatement.fields             = <" + fields             + ">");
		log.error("ArchivoStatement.columnArchivo      = <" + columnArchivo      + ">");
		log.error("ArchivoStatement.columnExtension    = <" + columnExtension    + ">");
		log.error("ArchivoStatement.extension          = <" + extension          + ">");
		log.error("ArchivoStatement.tipoStatement      = <" + tipoStatement      + ">");
		
		if( parameters != null ){
			
			Iterator parametersIterator = parameters.entrySet().iterator();
			while ( parametersIterator.hasNext() ) {
			  Map.Entry entry = (Map.Entry) parametersIterator.next();
			  log.error("ArchivoStatement.parameters." + entry.getKey() + " = <" + entry.getValue() + ">");
			}
			
      }
      
      if( fields != null ){
      	
			Iterator fieldsIterator = fields.entrySet().iterator();
			while ( fieldsIterator.hasNext() ) {
			  Map.Entry entry = (Map.Entry) fieldsIterator.next();
			  log.error("ArchivoStatement.fields." + entry.getKey() + " = <" + entry.getValue() + ">");
			}
			
      }
	
	}
}
