package com.app.cios.utilerias;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;

import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.apache.commons.logging.Log;


public class Fecha {

	public Fecha() {}

	//Variable para enviar mensajes al log.
	private final static Log log = ServiceLocator.getInstance().getLog(Fecha.class);

	/**
	 * Devuelve la fecha actual haciendo consulta a la base de datos
	 *
	 * @return Cadena de Texto con la Fecha Actual en formato DD/MM/YYYY.
	 * @author jshernandez
	 *
	 */
	public static String getFechaActual()
	 	throws AppException{

			log.info("getFechaActual(E)");
			// Obtener mes actual y a�o actual
			AccesoDB 		con 				= new AccesoDB();
			String 			qrySentencia	= null;
			List 				lVarBind			= new ArrayList();
			Registros		registros		= null;
			String 			fecha 			= null;
			try {
				con.conexionDB();
				qrySentencia = "SELECT TO_CHAR(TRUNC(SYSDATE),'DD/MM/YYYY') FECHA_ACTUAL FROM DUAL";
				registros = con.consultarDB(qrySentencia, lVarBind, false);
				if(registros != null && registros.next() ){
					fecha = registros.getString("FECHA_ACTUAL");
				}
			} catch(Exception e) {
				log.error("getFechaActual(Exception)");
				log.error("getFechaActual.qrySentencia = <" + qrySentencia + ">");
				e.printStackTrace();
				throw new AppException("getFechaActual(Exception): Error al obtener la fecha actual. \n" + e.getMessage());
			} finally {
				if(con.hayConexionAbierta())
				con.cierraConexionDB();
			}
			log.info("getFechaActual(S)");
			return fecha;
	}


	/**
	 * Devuelve la fecha actual haciendo consulta a la base de datos 
	 * con el formato especificado
	 * @return Cadena de Texto con la Fecha Actual en formato especificado (Oracle)
	 * @author gaparicio
	 *
	 */
	public static String getFechaActual(String formato)
		throws AppException{

			log.info("getFechaActual(E)");
			// Obtener mes actual y a�o actual
			AccesoDB       con            = new AccesoDB();
			String         qrySentencia   = null;
			List           lVarBind       = new ArrayList();
			lVarBind.add(formato);
			Registros      registros      = null;
			String         fecha          = null;
			try {
				con.conexionDB();
				qrySentencia = "SELECT TO_CHAR(SYSDATE,?) FECHA_ACTUAL FROM DUAL";
				registros = con.consultarDB(qrySentencia, lVarBind, false);
				if(registros.next() ){
					fecha = registros.getString("FECHA_ACTUAL");
				}
			} catch(Exception e) {
				throw new AppException("getFechaActual(Exception): Error al obtener la fecha actual.", e);
			} finally {
				if(con.hayConexionAbierta())
				con.cierraConexionDB();
			}
			log.info("getFechaActual(S)");
			return fecha;
	}

	/**
		 * Este metodo recibe en el parametro <tt>fecha</tt> una cadena de texto con una fecha
		 * con el siguiente formato: dd/mm/yyyy, sustituyendo el numero de mes por su nombre
		 * <p>
		 * Ejemplo:<br>
		 *       Fecha.fechaConNombreDelMes("21/01/2000")
		 *       El resultado sera: "21 de enero de 2000"
		 * <p>
		 * @return La fecha en el numero formato
		 * @param fecha         Fecha
		 *
		 */
		public static String getFechaConNombreDelMes(String fecha){
			return getFechaConNombreDelMes(fecha," de ");
		}

		/**
		 * Este metodo recibe en el parametro <tt>fecha</tt> una cadena de texto con una fecha
		 * con el siguiente formato: dd/mm/yyyy, sustituyendo el numero de mes por su nombre
		 * <p>
		 * Ejemplo:<br>
		 *       Fecha.fechaConNombreDelMes("21/01/2000","-")
		 *       El resultado sera: "21-enero-2000"
		 * <p>
		 * @return La fecha en el numero formato
		 * @param fecha         Fecha
		 * @param delimitador   Delimitador de los campos de la fecha
		 *
		 */
		public static String getFechaConNombreDelMes(String fecha, String delimitador){
			if (fecha == null) return fecha;
			if (delimitador == null) delimitador = "";
			int numMes = 0;

			String []datos=fecha.split("\\/");
			if(datos.length != 3) return fecha;

			String dia  = datos[0];
			String mes  = datos[1];
			String anio = datos[2];

			try {
				numMes = Integer.parseInt(mes);
			} catch(Exception e) {
				return fecha;
			}

			switch(numMes){
				case 1:  mes = "enero"; break;
				case 2:  mes = "febrero"; break;
				case 3:  mes = "marzo"; break;
				case 4:  mes = "abril"; break;
				case 5:  mes = "mayo"; break;
				case 6:  mes = "junio"; break;
				case 7:  mes = "julio"; break;
				case 8:  mes = "agosto"; break;
				case 9:  mes = "septiembre"; break;
				case 10: mes = "octubre"; break;
				case 11: mes = "noviembre"; break;
				case 12: mes = "diciembre"; break;
				default: return fecha;
			}

			return dia + delimitador + mes + delimitador + anio;

		}

}//Fecha

