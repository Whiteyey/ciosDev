/**
 * 
 */
package com.app.cios.modulos;

import java.util.HashMap;

import com.app.cios.beans.LoginDataDTO;

/**
 * @author Jhonatan Pacheco <jhonatanpachecohernandez@gmail.com>
 *
 */
public interface OperacionesBD {
	
	public int add(int tipo);
	
	public int delete(HashMap<String,String>data);
	
	public int update(HashMap<String,String> data);
	
	public Object get(HashMap<String,String> data);

}
