/**
 * 
 */
package com.app.cios.web.controllers;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.app.cios.beans.AssistanceDTO;
import com.app.cios.beans.ElementosDTO;
import com.app.cios.beans.ResponseDTO;
import com.app.cios.beans.SesUsuarioCiosDTO;
import com.app.cios.utilerias.Registros;
import com.app.cios.web.services.ElementosQueries;

/**
 * 
 * @author JR Alvarado <jr.alvaradogarcia@gmail.com>
 *
 */
@Controller
public class SupervisoresController {

	ElementosQueries elementosQueries;
	
	@RequestMapping(value = "/supervisores", method = RequestMethod.GET)
	public String mainPage(ModelMap model,HttpServletRequest request) {

		ModelAndView aux= com.app.cios.utilerias.LoginUtil.isValidLogin(request);
		if(aux!=null){
			return "redirect:/";
		}
		
		HttpSession session = request.getSession();
		SesUsuarioCiosDTO u = (SesUsuarioCiosDTO) session.getAttribute("sesUsuario");

//		model.addAttribute("titlePage", "Main");
		model.addAttribute("title","Supervisores");
		model.addAttribute("user", u.getNombreCompleto());
		model.addAttribute("addNew", "/supervisores/add");
		
		return "supervisores/supervisores";
	}

	@RequestMapping(value="supervisores/addNewElement", method = RequestMethod.GET)
	public ModelAndView add(HttpServletRequest request){
		ModelAndView  model = new ModelAndView ();
		ModelAndView aux= com.app.cios.utilerias.LoginUtil.isValidLogin(request);

		if(aux!=null){
			return aux;
		}
		
		HttpSession session = request.getSession();

		SesUsuarioCiosDTO u = (SesUsuarioCiosDTO) session.getAttribute("sesUsuario");

		model.addObject("title", "Nuevo Supervisor");
		model.addObject("user", u.getNombreCompleto());
		model.setViewName("supervisores/nuevoSupervisor");
		return model;
	}

	@RequestMapping(value="/deleteElement", method = RequestMethod.POST)
	@ResponseBody
	public ResponseDTO deleteMessage(@RequestBody ElementosDTO element) throws ParseException {
		elementosQueries = new ElementosQueries();
		return elementosQueries.deleteElement(element);
	}
	
	@RequestMapping(value = "/supervisores/supervisoresData", method = RequestMethod.POST)
	public @ResponseBody ResponseDTO gestionData(HttpServletRequest request) {

		ElementosQueries mQueries = new ElementosQueries();
		
		Registros registros = mQueries.getRegistrosSupervisores();
		
		List<ElementosDTO> data = new ArrayList<>();

		while (registros.next()) {

			Registros registrosRate = mQueries.getElementRate(Integer.parseInt(registros.getString("ID_ELEMENTO")));
			int rate = 0;
			String rate_s = "0";
			while (registrosRate.next()) {
				rate += Integer.parseInt(registrosRate.getString("RATE"));
			}

			if(registrosRate.getNumeroRegistros() > 0){
				rate_s = "" + (rate/registrosRate.getNumeroRegistros());
			}
			data.add(new ElementosDTO(Integer.parseInt(registros.getString("ID_ELEMENTO")),
					registros.getString("NOMBRE_COMPLETO"), rate_s));
		}
		return new ResponseDTO("elementosData", true, data);
	}


	@RequestMapping(value="/NewAssistanceControl", method = RequestMethod.POST)
	@ResponseBody
	public ResponseDTO addNewAssistanceControl(@RequestBody AssistanceDTO assistance) throws ParseException {
		elementosQueries = new ElementosQueries();
		return elementosQueries.addNewAssistanceControl(assistance);
	}
	

	@RequestMapping(value="elementos/asignarSupervisor", method = RequestMethod.GET)
	public ModelAndView assignSupervisor(HttpServletRequest request){
		ModelAndView  model = new ModelAndView ();
		ModelAndView aux= com.app.cios.utilerias.LoginUtil.isValidLogin(request);

		if(aux!=null){
			return aux;
		}
		
		HttpSession session = request.getSession();
		SesUsuarioCiosDTO u = (SesUsuarioCiosDTO) session.getAttribute("sesUsuario");

		/*parte para buscar al elemento*/
		ElementosQueries mQueries = new ElementosQueries();
		Registros registros = mQueries.getRegistrosElements(
				request.getQueryString().substring(3, request.getQueryString().length()));
		ElementosDTO data = null;

		while (registros.next()) {
			data = new ElementosDTO(Integer.parseInt(registros.getString("ID_ELEMENTO")),
					registros.getString("NOMBRE_COMPLETO"), registros.getString("TIPO"),
					registros.getString("ESTATUS"));
		}
		
		/*asigna los datos recuperados*/
		model.addObject("name", data.getNombre());
		model.addObject("key", data.getId());
		model.addObject("type", data.getTipo());
		model.addObject("status", data.getEstatus());

		model.addObject("title", "Asignar Supervisor");
		model.addObject("user", u.getNombreCompleto());
		model.setViewName("supervisores/asignarSupervisor");
		return model;
	}
}

