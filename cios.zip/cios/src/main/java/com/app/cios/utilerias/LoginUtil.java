package com.app.cios.utilerias;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.servlet.ModelAndView;

public class LoginUtil {
	public static ModelAndView isValidLogin(HttpServletRequest request) {
		
		if (!Comunes.validaSession(request)) {
			ModelAndView model = new ModelAndView();
			model.addObject("title", "Spring Security Remember Me");
			model.addObject("message", "This is default page!");
			// model.setViewName("pages/hello");

			model.setViewName("auth/login");
			return model;
		} else {
			return null;
		}
	}

}
