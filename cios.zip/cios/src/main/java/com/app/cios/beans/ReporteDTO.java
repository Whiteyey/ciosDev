/**
 * 
 */
package com.app.cios.beans;

public class ReporteDTO {

	private int id;
	private String supervisor;
	private String client;
	private String type;
	private String comments;
	private String date;
	
	private String evidence1;
	private String evidence2;
	private String evidence3;
	
	
	public ReporteDTO(){}
	
	public ReporteDTO(int id, String supervisor, String client, String type, String comments, String date){
		this.id = id;
		this.supervisor = supervisor;
		this.client = client;
		this.type = type;
		this.comments = comments;
		this.date = date;
	}

	public ReporteDTO(int id, String supervisor, String client, String type, String comments, String date,
			String img1, String img2, String img3){
		this.id = id;
		this.supervisor = supervisor;
		this.client = client;
		this.type = type;
		this.comments = comments;
		this.date = date;

		this.evidence1 = img1;
		this.evidence2 = img2;
		this.evidence3 = img3;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSupervisor() {
		return supervisor;
	}

	public void setSupervisor(String supervisor) {
		this.supervisor = supervisor;
	}

	public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getEvidence1() {
		return evidence1;
	}

	public void setEvidence1(String evidence1) {
		this.evidence1 = evidence1;
	}

	public String getEvidence2() {
		return evidence2;
	}

	public void setEvidence2(String evidence2) {
		this.evidence2 = evidence2;
	}

	public String getEvidence3() {
		return evidence3;
	}

	public void setEvidence3(String evidence3) {
		this.evidence3 = evidence3;
	}
	
}
