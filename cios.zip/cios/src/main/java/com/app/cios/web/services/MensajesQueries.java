package com.app.cios.web.services;

import com.app.cios.beans.MensajeDTO;
import com.app.cios.beans.ResponseDTO;
import com.app.cios.utilerias.AccesoDB;
import com.app.cios.utilerias.Registros;
import com.app.cios.utilerias.consulta.QueryBean;

public class MensajesQueries {
	
	public ResponseDTO sendMessage(MensajeDTO json) {
		//se obtienen los parametros
		String title = json.getTitle();
		String message = json.getMessage();
		String dest = json.getDestinatarios();
		
		//se crea el query y la conexion
		QueryBean masterQuery = new QueryBean();
		AccesoDB con = new AccesoDB();
		boolean bandera = false;
		
		try {
			con.conexionDB();
			masterQuery.appendQueryString(
					"INSERT INTO tbl_mensajes "
							+ "(titulo, mensaje, destinatarios) "
							+ "VALUES (?, ?, ?)");
			masterQuery.appendCondition(title);
			masterQuery.appendCondition(message);
			masterQuery.appendCondition(dest);

			bandera = con.ejecutaUpdateDB(masterQuery) == 1 ? true : false;
			
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseDTO("Error al crear mensaje",bandera);

		} finally {
			if (con.hayConexionAbierta()) {
				con.terminaTransaccion(bandera);
				con.cierraConexionDB();
			}
		}
		return new ResponseDTO("Mensaje creado",bandera);
	}
	
	public Registros getRegistrosMessages(){
		//se crea el query y la conexion
		QueryBean masterQuery = new QueryBean();

		masterQuery.appendQueryString(
				"SELECT ID_MENSAJE, TITULO, MENSAJE, "
				+ "FECHA, DESTINATARIOS FROM tbl_mensajes");
		Registros registro = null;
		
		try {
			registro = AccesoDB.consultarDB(masterQuery);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error :: " + e.getMessage());

		}
		
		return registro;
	}
	
	public ResponseDTO deleteMessage(MensajeDTO json) {
		//se obtienen los parametros
		int id = json.getId();
		
		//se crea el query y la conexion
		QueryBean masterQuery = new QueryBean();
		AccesoDB con = new AccesoDB();
		boolean bandera = false;
		
		try {
			con.conexionDB();
			masterQuery.appendQueryString(
					"DELETE FROM tbl_mensajes WHERE ID_MENSAJE = ?");
			masterQuery.appendCondition(id);

			bandera = con.ejecutaUpdateDB(masterQuery) == 1 ? true : false;
			
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseDTO("Error al borrar mensaje",bandera);

		} finally {
			if (con.hayConexionAbierta()) {
				con.terminaTransaccion(bandera);
				con.cierraConexionDB();
			}
		}
		return new ResponseDTO("Mensaje borrado",bandera);
	}
}
