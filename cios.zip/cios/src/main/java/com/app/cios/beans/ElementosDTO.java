/**
 * 
 */
package com.app.cios.beans;

public class ElementosDTO {

	/*parte para elemento*/
	private int id;
	private String clasificacion;
	private String tipo;
	private String estatus;
	private String alta;
	private String dotacion;
	private String rate;
	private String turn;

	/*parte para informacion*/
	private String nombre;
	private String apellidoP;
	private String apellidoM;
	private String imss;
	private String foto;
	private String direccion;
	private String telefono;
	private String nombreContacto;
	private String direccionContacto;
	private String telefonoContacto;
	
	public ElementosDTO(){}
	
	/*constructor de datos para elementos*/
	public ElementosDTO(int id, String clasificacion, String tipo, String estatus,
			String alta, String dotacion, String rate){
		this.id = id;
		this.clasificacion = clasificacion;
		this.tipo = tipo;
		this.estatus = estatus;
		this.alta = alta;
		this.dotacion = dotacion;
		this.rate = rate;
	}

	/*constructor de informacion personal del elemento*/
	public ElementosDTO(int id, String nombre, String apellidoP, String apellidoM,
			String imss, String direccion, String telefono, String foto, String rate,
			String nombreContacto, String direccionContacto, String telefonoContacto){
		this.id = id;
		this.nombre = nombre;
		this.apellidoP = apellidoP;
		this.apellidoM = apellidoM;
		this.imss = imss;
		this.direccion = direccion;
		this.telefono = telefono;
		this.foto = foto;
		this.rate = rate;
		this.nombreContacto = nombreContacto;
		this.direccionContacto = direccionContacto;
		this.telefonoContacto = telefonoContacto;
	}
	
	/*Constructor mas completo*/
	public ElementosDTO(int id, String clasificacion, String tipo, String estatus, String alta, String dotacion,
			String nombre, String apellidoP, String apellidoM, String imss, String direccion, String telefono,
			String nombreContacto, String direccionContacto, String telefonoContacto){
		this.id = id;
		this.clasificacion = clasificacion;
		this.tipo = tipo;
		this.estatus = estatus;
		this.alta = alta;
		this.dotacion = dotacion;

		this.nombre = nombre;
		this.apellidoP = apellidoP;
		this.apellidoM = apellidoM;
		this.imss = imss;
		this.direccion = direccion;
		this.telefono = telefono;
		this.foto = foto;

		this.nombreContacto = nombreContacto;
		this.direccionContacto = direccionContacto;
		this.telefonoContacto = telefonoContacto;
	}
	
	/*Constructor para la tabla*/
	public ElementosDTO(int id, String nombre, String rate){
		this.id = id;
		this.nombre = nombre;
		this.rate = rate;
	}
	
	/*constructor para datos basicos al mover el elemento*/
	public ElementosDTO(int id, String nombre, String tipo, String estatus){
		this.id = id;
		this.nombre = nombre;
		this.tipo = tipo;
		this.estatus = estatus;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getClasificacion() {
		return clasificacion;
	}

	public void setClasificacion(String clasificacion) {
		this.clasificacion = clasificacion;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getEstatus() {
		return estatus;
	}

	public void setEstatus(String estatus) {
		this.estatus = estatus;
	}

	public String getAlta() {
		return alta;
	}

	public void setAlta(String alta) {
		this.alta = alta;
	}

	public String getDotacion() {
		return dotacion;
	}

	public void setDotacion(String dotacion) {
		this.dotacion = dotacion;
	}

	/*parte para la informacion del elemento*/
	
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellidoP() {
		return apellidoP;
	}

	public void setApellidoP(String apellidoP) {
		this.apellidoP = apellidoP;
	}

	public String getApellidoM() {
		return apellidoM;
	}

	public void setApellidoM(String apellidoM) {
		this.apellidoM = apellidoM;
	}

	public String getImss() {
		return imss;
	}

	public void setImss(String imss) {
		this.imss = imss;
	}
	
	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getFoto() {
		return foto;
	}

	public void setFoto(String foto) {
		this.foto = foto;
	}

	public String getNombreContacto() {
		return nombreContacto;
	}

	public void setNombreContacto(String nombreContacto) {
		this.nombreContacto = nombreContacto;
	}

	public String getDireccionContacto() {
		return direccionContacto;
	}

	public void setDireccionContacto(String direccionContacto) {
		this.direccionContacto = direccionContacto;
	}

	public String getTelefonoContacto() {
		return telefonoContacto;
	}

	public void setTelefonoContacto(String telefonoContacto) {
		this.telefonoContacto = telefonoContacto;
	}

	public String getRate() {
		return rate;
	}

	public void setRate(String rate) {
		this.rate = rate;
	}

	public String getTurn() {
		return turn;
	}

	public void setTurn(String turn) {
		this.turn = turn;
	}
}
