/**
 * 
 */
package com.app.cios.web.controllers;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.app.cios.beans.ReporteDTO;
import com.app.cios.beans.ResponseDTO;
import com.app.cios.beans.SesUsuarioCiosDTO;
import com.app.cios.utilerias.Registros;
import com.app.cios.web.services.ReportesQueries;

/**
 * 
 * @author JR Alvarado <jr.alvaradogarcia@gmail.com>
 *
 */
@Controller
public class ReportesController {
	
	ReportesQueries reportQueries;
	@RequestMapping(value = "/reportes", method = RequestMethod.GET)
	public String mainPage(ModelMap model,HttpServletRequest request) {

		ModelAndView aux= com.app.cios.utilerias.LoginUtil.isValidLogin(request);
		if(aux!=null){
			return "redirect:/";
		}
		HttpSession session = request.getSession();

		SesUsuarioCiosDTO u = (SesUsuarioCiosDTO) session.getAttribute("sesUsuario");

//		model.addAttribute("titlePage", "Main");
		model.addAttribute("title","Reportes");
		model.addAttribute("user", u.getNombreCompleto());
		model.addAttribute("addNew", "/reportes/addReporte");
		
		return "reportes/reportes";
	}


	@RequestMapping(value="reportes/addReporte", method = RequestMethod.GET)
	public String add(ModelMap model,HttpServletRequest request) {

		ModelAndView aux= com.app.cios.utilerias.LoginUtil.isValidLogin(request);
		if(aux!=null){
			return "redirect:/";
		}
		
		HttpSession session = request.getSession();

		SesUsuarioCiosDTO u = (SesUsuarioCiosDTO) session.getAttribute("sesUsuario");

//		model.addAttribute("titlePage", "Main");
		model.addAttribute("title", "Nuevo Mensaje");
		model.addAttribute("user", u.getNombreCompleto());
		
		return "reportes/nuevoReporte";
	}
	
	@RequestMapping(value = "reportes/reportesData", method = RequestMethod.POST)
	public @ResponseBody ResponseDTO gestionData(HttpServletRequest request) {

		ReportesQueries mQueries = new ReportesQueries();
		
		Registros registros = mQueries.getRegistrosReports();
		
		List<ReporteDTO> data = new ArrayList<>();

		while (registros.next()) {
			data.add(new ReporteDTO(Integer.parseInt(registros.getString("ID_REPORTE")),
					registros.getString("SUPERVISOR"),
					registros.getString("CLIENTE"),
					registros.getString("TIPO"),
					registros.getString("COMENTARIOS"),
					registros.getString("FECHA").substring(0, 10)));
		}
		return new ResponseDTO("reportesData", true, data);
	}

	@RequestMapping(value="/sendReport", method = RequestMethod.POST)
	@ResponseBody
	public ResponseDTO sendReport(@RequestBody ReporteDTO report) throws ParseException {
		reportQueries = new ReportesQueries();
		return reportQueries.sendReport(report);
	}
	
	@RequestMapping(value="/deleteReport", method = RequestMethod.POST)
	@ResponseBody
	public ResponseDTO deleteReport(@RequestBody ReporteDTO report) throws ParseException {
		reportQueries = new ReportesQueries();
		return reportQueries.deleteReport(report);
	}
}

