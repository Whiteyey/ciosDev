package com.app.cios.web.services;

import com.app.cios.beans.AssistanceDTO;
import com.app.cios.beans.ElementosDTO;
import com.app.cios.beans.ResponseDTO;
import com.app.cios.utilerias.AccesoDB;
import com.app.cios.utilerias.Registros;
import com.app.cios.utilerias.consulta.QueryBean;

public class ElementosQueries {
	private String supervisorCode = "60200";
	
	
	public ResponseDTO addElement(ElementosDTO json) {
		//se obtienen los parametros de elemento
		int id_elemento = json.getId();
		String clasificacion = json.getClasificacion();
		String tipo = json.getTipo();
		String estatus = json.getEstatus();
		String alta = json.getDotacion();
		String dotacion = json.getDotacion();
		String turn = json.getTurn();
		
		//se obtienen los parametros de informacion personal
		String nombreCompleto = json.getNombre() + " " 
							+ json.getApellidoP() + " "
							+ json.getApellidoM();
		String nombre = json.getNombre();
		String apellidop = json.getApellidoP();
		String apellidom = json.getApellidoM();
		String imss = json.getImss();
		String photo = json.getFoto();
		String direccion = json.getDireccion();
		String telefono = json.getTelefono();
		String nombreContacto = json.getNombreContacto();
		String direccionContacto = json.getDireccionContacto();
		String telefonoContacto = json.getTelefonoContacto();
		
		System.out.println("alta"+alta);
		//se crea el query y la conexion
		QueryBean masterQuery = new QueryBean();
		AccesoDB con = new AccesoDB();
		boolean bandera = false;

		con.conexionDB();
		
		try {
			masterQuery.appendQueryString(
					"INSERT INTO tbl_elementos "
							+ "(ID_ELEMENTO, CLASIFICACION, ESTATUS, "
							+ "FECHA_ALTA, FECHA_DOTACION, TIPO, TURNO) "
							+ "VALUES (?, ?, ?, ?, ?, ?, ?)");
			masterQuery.appendCondition(id_elemento);
			masterQuery.appendCondition(clasificacion);
			masterQuery.appendCondition(estatus);
			masterQuery.appendCondition(alta);
			masterQuery.appendCondition(dotacion);
			masterQuery.appendCondition(tipo);
			masterQuery.appendCondition(turn);

			bandera = con.ejecutaUpdateDB(masterQuery) == 1 ? true : false;
			
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseDTO("Error al crear elemento",bandera);

		} 
		
		try {
			masterQuery.clearConditions();
			masterQuery.resetAll();
			bandera = false;
			
			masterQuery.appendQueryString(
					"INSERT INTO tbl_personal_data "
							+ "(ID_ELEMENTO, NOMBRE, APELLIDO_P, APELLIDO_M, NOMBRE_COMPLETO, "
							+ "IMSS, DIRECCION, TELEFONO, FOTO, "
							+ "NOMBRE_C, TELEFONO_C, DIRECCION_C) "
							+ "VALUES (?, ?, ?, ?, ?, "
							+ "?, ?, ?, ?, "
							+ "?, ?, ?)");
			masterQuery.appendCondition(id_elemento);
			masterQuery.appendCondition(nombre);
			masterQuery.appendCondition(apellidop);
			masterQuery.appendCondition(apellidom);
			masterQuery.appendCondition(nombreCompleto);
			
			masterQuery.appendCondition(imss);
			masterQuery.appendCondition(direccion);
			masterQuery.appendCondition(telefono);
			masterQuery.appendCondition(photo+"foto");

			masterQuery.appendCondition(nombreContacto);
			masterQuery.appendCondition(telefonoContacto);
			masterQuery.appendCondition(direccionContacto);


			bandera = con.ejecutaUpdateDB(masterQuery) == 1 ? true : false;
			
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseDTO("Error al crear elemento",bandera);

		}finally {
			if (con.hayConexionAbierta()) {
				con.terminaTransaccion(bandera);
				con.cierraConexionDB();
			}
		}
		return new ResponseDTO("Elemento creado",bandera);
	}

	public Registros getElementByClientId(String id){
		//se crea el query y la conexion
		QueryBean masterQuery = new QueryBean();

		masterQuery.appendQueryString(
				"SELECT ID_ELEMENTO, NOMBRE_COMPLETO from tbl_personal_data "
				+ "where ID_ELEMENTO in (select ID_ELEMENTO "
				+ "from tbl_rel_elemento_cliente "
				+ "where ID_CLIENTE = ?) "
				+ "order by NOMBRE_COMPLETO");
		masterQuery.appendCondition(id);
		
		Registros registro = null;
		
		try {
			registro = AccesoDB.consultarDB(masterQuery);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error :: " + e.getMessage());

		}
		
		return registro;
	}

	public Registros getElementById(String id){
		//se crea el query y la conexion
		QueryBean masterQuery = new QueryBean();

		masterQuery.appendQueryString(
				"SELECT pd.ID_ELEMENTO, pd.NOMBRE_COMPLETO, el.TURNO "
				+ "from tbl_personal_data pd, tbl_elementos el "
				+ "where pd.ID_ELEMENTO = ? "
				+ "and pd.ID_ELEMENTO = el.ID_ELEMENTO");
		masterQuery.appendCondition(id);
		
		Registros registro = null;
		
		try {
			registro = AccesoDB.consultarDB(masterQuery);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error :: " + e.getMessage());

		}
		
		return registro;
	}
	
	public Registros getRegistrosElements(String id){
		//se crea el query y la conexion
		QueryBean masterQuery = new QueryBean();

		masterQuery.appendQueryString(
				"SELECT el.ID_ELEMENTO, pd.NOMBRE_COMPLETO, "
				+ "el.TIPO, el.ESTATUS FROM tbl_personal_data pd, "
				+ "tbl_elementos el where el.ID_ELEMENTO = ? "
				+ "and pd.ID_ELEMENTO = ?");
		masterQuery.appendCondition(id);
		masterQuery.appendCondition(id);
		
		Registros registro = null;
		
		try {
			registro = AccesoDB.consultarDB(masterQuery);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error :: " + e.getMessage());

		}
		
		return registro;
	}
	
	public Registros getRegistrosElementsGuards(){
		//se crea el query y la conexion
		QueryBean masterQuery = new QueryBean();

		masterQuery.appendQueryString(
				"SELECT pd.ID_ELEMENTO, pd.NOMBRE_COMPLETO, el.TIPO "
				+ "FROM tbl_personal_data pd, tbl_elementos el "
				+ "where pd.ID_ELEMENTO = el.ID_ELEMENTO "
				+ "and pd.ID_ELEMENTO in (select ID_ELEMENTO "
				+ "from soic_db.tbl_elementos where TIPO = ?)");
		
		masterQuery.appendCondition("Guardia");
		
		Registros registro = null;
		
		try {
			registro = AccesoDB.consultarDB(masterQuery);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error :: " + e.getMessage());

		}
		
		return registro;
	}

	public Registros getRegistrosElementsScorts(){
		//se crea el query y la conexion
		QueryBean masterQuery = new QueryBean();

		masterQuery.appendQueryString(
				"SELECT pd.ID_ELEMENTO, pd.NOMBRE_COMPLETO, el.TIPO "
				+ "FROM tbl_personal_data pd, tbl_elementos el "
				+ "where pd.ID_ELEMENTO = el.ID_ELEMENTO "
				+ "and pd.ID_ELEMENTO in (select ID_ELEMENTO "
				+ "from soic_db.tbl_elementos where TIPO = ?)");
		
		masterQuery.appendCondition("Escolta");
		
		Registros registro = null;
		
		try {
			registro = AccesoDB.consultarDB(masterQuery);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error :: " + e.getMessage());

		}
		
		return registro;
	}

	public Registros getRegistrosElementsDrivers(){
		//se crea el query y la conexion
		QueryBean masterQuery = new QueryBean();

		masterQuery.appendQueryString(
				"SELECT pd.ID_ELEMENTO, pd.NOMBRE_COMPLETO, el.TIPO "
				+ "FROM tbl_personal_data pd, tbl_elementos el "
				+ "where pd.ID_ELEMENTO = el.ID_ELEMENTO "
				+ "and pd.ID_ELEMENTO in (select ID_ELEMENTO "
				+ "from soic_db.tbl_elementos where TIPO = ?)");
		
		masterQuery.appendCondition("Conductor");
		
		Registros registro = null;
		
		try {
			registro = AccesoDB.consultarDB(masterQuery);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error :: " + e.getMessage());

		}
		
		return registro;
	}
	
	public Registros getRegistrosCompleteElements(String id){
		//se crea el query y la conexion
		QueryBean masterQuery = new QueryBean();

		masterQuery.appendQueryString(
				"SELECT el.ID_ELEMENTO, el.ESTATUS, el.TIPO, "
				+ "el.CLASIFICACION, el.FECHA_ALTA, el.FECHA_DOTACION, "
				+ "pd.NOMBRE, pd.APELLIDO_P, pd.APELLIDO_M, "
				+ "pd.DIRECCION, pd.TELEFONO, pd.IMSS, "
				+ "pd.NOMBRE_C, pd.DIRECCION_C, pd.TELEFONO_C "
				+ "FROM tbl_personal_data pd, tbl_elementos el "
				+ "where el.ID_ELEMENTO = ? and pd.ID_ELEMENTO = ?;");
		masterQuery.appendCondition(id);
		masterQuery.appendCondition(id);
		
		Registros registro = null;
		
		try {
			registro = AccesoDB.consultarDB(masterQuery);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error :: " + e.getMessage());

		}
		
		return registro;
	}
	
	public Registros getRegistrosSupervisores(){	
		//se crea el query y la conexion
		QueryBean masterQuery = new QueryBean();

		masterQuery.appendQueryString(
				"SELECT * FROM tbl_personal_data where ID_ELEMENTO in "
				+ "(SELECT ID_ELEMENTO FROM tbl_elementos where CLASIFICACION = ?)");
		
		masterQuery.appendCondition(supervisorCode);
		Registros registro = null;
		
		try {
			registro = AccesoDB.consultarDB(masterQuery);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error :: " + e.getMessage());

		}
		
		return registro;
	}
	
	public Registros getElementRate(int id){
		//se crea el query y la conexion
		QueryBean masterQuery = new QueryBean();

		masterQuery.appendQueryString(
				"SELECT * FROM tbl_rate "
				+ "where ID_ELEMENTO = ?");
		masterQuery.appendCondition(id);
		
		Registros registro = null;
		
		try {
			registro = AccesoDB.consultarDB(masterQuery);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error :: " + e.getMessage());

		}
		
		return registro;
	}
	
	public ResponseDTO deleteElement(ElementosDTO json) {
		//se obtienen los parametros
		int id = json.getId();
		
		//se crea el query y la conexion
		QueryBean masterQuery = new QueryBean();
		AccesoDB con = new AccesoDB();
		boolean bandera = false;
		
		try {
			con.conexionDB();
			masterQuery.appendQueryString("DELETE FROM tbl_elementos WHERE ID_ELEMENTO = ?");
			masterQuery.appendCondition(id);

			bandera = con.ejecutaUpdateDB(masterQuery) == 1 ? true : false;
			
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseDTO("Error al borrar elemento",bandera);

		}

		masterQuery.clearConditions();
		masterQuery.resetAll();
		bandera = false;
		
		try {
			masterQuery.appendQueryString("DELETE FROM tbl_personal_data WHERE ID_ELEMENTO = ?");
			masterQuery.appendCondition(id);

			bandera = con.ejecutaUpdateDB(masterQuery) == 1 ? true : false;
			
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseDTO("Error al borrar elemento",bandera);

		}
		
		masterQuery.clearConditions();
		masterQuery.resetAll();
		bandera = false;
		
		try {
			masterQuery.appendQueryString("INSERT INTO tbl_rate "
					+ "(ID_ELEMENTO, ID_CLIENTE, RATE) VALUES (?, '0', '0')");
			masterQuery.appendCondition(id);

			bandera = con.ejecutaUpdateDB(masterQuery) == 1 ? true : false;
			
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseDTO("Error al insertar elemento",bandera);

		}
		
		masterQuery.clearConditions();
		masterQuery.resetAll();
		bandera = false;
		
		try {
			masterQuery.appendQueryString("DELETE FROM tbl_rate WHERE ID_ELEMENTO = ?");
			masterQuery.appendCondition(id);

			bandera = con.ejecutaUpdateDB(masterQuery) == 1 ? true : false;
			
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseDTO("Error al borrar elemento",bandera);

		} finally {
			if (con.hayConexionAbierta()) {
				con.terminaTransaccion(bandera);
				con.cierraConexionDB();
			}
		}
		return new ResponseDTO("Elemento borrado",bandera);
	}
	
	public ResponseDTO addNewAssistanceControl(AssistanceDTO json) {
		//se obtienen los parametros de elemento
		int id_elemento = json.getIdElement();
		int id_cliente = json.getIdCliente();
		String turn = json.getTurn();
		String date = json.getDate();
		
		//se crea el query y la conexion
		QueryBean masterQuery = new QueryBean();
		AccesoDB con = new AccesoDB();
		boolean bandera = false;

		con.conexionDB();
		
		try {
			masterQuery.appendQueryString(
					"INSERT INTO tbl_asistencia "
					+ "(ID_ELEMENTO, ID_CLIENTE, FECHA, TURNO) "
					+ "VALUES (?, ?, ?, ?)");
			masterQuery.appendCondition(id_elemento);
			masterQuery.appendCondition(id_cliente);
			masterQuery.appendCondition(date);
			masterQuery.appendCondition(turn);

			bandera = con.ejecutaUpdateDB(masterQuery) == 1 ? true : false;
			
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseDTO("Error al crear reporte",bandera);

		} finally {
			if (con.hayConexionAbierta()) {
				con.terminaTransaccion(bandera);
				con.cierraConexionDB();
			}
		}
		return new ResponseDTO("Reporte creado",bandera);
	}
	

	public ResponseDTO updateElement(ElementosDTO element){
		//se obtienen los parametros de elemento
		int id_elemento = element.getId();
		String clasificacion = element.getClasificacion();
		String tipo = element.getTipo();
		String turn = element.getTurn();
		String estatus = element.getEstatus();
		String alta = element.getAlta();
		String dotacion = element.getDotacion();

		/*parte para informacion*/
		String nombre = element.getNombre();
		String apellidoP = element.getApellidoP();
		String apellidoM = element.getApellidoM();
		String imss = element.getImss();
		String direccion = element.getDireccion();
		String telefono = element.getTelefono();
		String nombreContacto = element.getNombreContacto();
		String direccionContacto = element.getDireccionContacto();
		String telefonoContacto = element.getTelefonoContacto();
		
		//se crea el query y la conexion
		QueryBean masterQuery = new QueryBean();
		AccesoDB con = new AccesoDB();
		boolean bandera = false;

		con.conexionDB();
		
		try {
			masterQuery.appendQueryString(
					"UPDATE tbl_elementos SET ESTATUS = ?, TIPO = ?, TURNO = ? "
					+ "CLASIFICACION = ?, FECHA_DOTACION = ? "
					+ "WHERE ID_ELEMENTO = ?");

			masterQuery.appendCondition(estatus);
			masterQuery.appendCondition(tipo);
			masterQuery.appendCondition(turn);
			masterQuery.appendCondition(clasificacion);
			masterQuery.appendCondition(dotacion);
			masterQuery.appendCondition(id_elemento);

			bandera = con.ejecutaUpdateDB(masterQuery) == 1 ? true : false;
			
		} catch (Exception e) {
			e.printStackTrace();

		} try {
			masterQuery.clearConditions();
			masterQuery.resetAll();
			bandera = false;
			
			masterQuery.appendQueryString(
					"UPDATE tbl_personal_data SET NOMBRE = ?, APELLIDO_P = ?, APELLIDO_M = ?, "
					+ "DIRECCION = ?, TELEFONO = ?, IMSS = ?, "
					+ "NOMBRE_C = ?, DIRECCION_C = ?, TELEFONO_C = ? "
					+ "WHERE ID_ELEMENTO = ?");
			
			masterQuery.appendCondition(nombre);
			masterQuery.appendCondition(apellidoP);
			masterQuery.appendCondition(apellidoM);
			masterQuery.appendCondition(direccion);
			masterQuery.appendCondition(telefono);
			masterQuery.appendCondition(imss);
			masterQuery.appendCondition(nombreContacto);
			masterQuery.appendCondition(direccionContacto);
			masterQuery.appendCondition(telefonoContacto);
			masterQuery.appendCondition(id_elemento);
			
			bandera = con.ejecutaUpdateDB(masterQuery) == 1 ? true : false;
			
		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			if (con.hayConexionAbierta()) {
				con.terminaTransaccion(bandera);
				con.cierraConexionDB();
			}
		}
		return new ResponseDTO("Elemento editado",bandera);
	}
}
