package com.app.cios.utilerias;

import java.util.List;
import java.util.ArrayList;

import java.util.HashMap;

//import net.sf.json.JSONArray;
//import net.sf.json.JSONObject;

/**
 * La clase permite obtener la informaci�n de una lista de listas que representa una
 * tabla, a atrav�s del nombre que se le asocie a cada una de las posiciones de la lista
 *
 * Por ejemplo. Para almacenar el resultado de una consulta, dentro de Listas de Listas
 * y aun as� poder recuperar la informaci�n a trav�s del nombre de la columna.
 *
 * @author Gilberto Aparicio
 * 
 */

public class Registros implements java.io.Serializable {

/*
  Ser�a bueno que la clase registros tuviera un columna setmetadata o algo
  as� para que se pudiera extraer la informaci�n en forma ordenada.
  
  getTitulo
  getContenido
  getTotales
 setGrupo: indica el campo que funcionar� como grupo, agregandose un tabla nueva cada vez que este cambie. 
 
 */
	public Registros() {
	}

	public Registros(List colNames) {
		setNombreColumnas(colNames);
	}

	/**
	 * Obtiene el nombre de las columnas del resultado.
	 * @return 
	 */
	public List getNombreColumnas() {
		return this.colnames;
	}

	/**
	 * Estable el nombre de las columnas
	 * @param colnames Lista con el nombre de las columnas de la informaci�n
	 */
	public void setNombreColumnas(List colnames) {
		this.colnames = colnames;
		for (int i = 0; i < this.colnames.size(); i++) {
			//this.colnames.set(i, this.colnames.get(i).toString().toUpperCase());
			this.colnames.set(i, this.colnames.get(i).toString());
		} //for(int i=0;i<this.colnames.size();i++)
	}

	/**
	 * Estable el nombre de las columnas
	 * @param colnames Lista con el nombre de las columnas de la informaci�n
	 */
	public void renombrarColumnas(HashMap nombreColumnas) {
		for (int i = 0; i < this.colnames.size(); i++) {
			String columnaActual = (String) this.colnames.get(i);
			String nuevoNombre   = (String) nombreColumnas.get(columnaActual);
			this.colnames.set(i, nuevoNombre.toString());
		} 
	}
		
	/**
	 * Establece la informaci�n.
	 * @param data Es una listas de listas que representan una 
	 * 		tabla de informaci�n
	 *
	 */
	public void setData(List data) {
		this.data = (data.isEmpty()) ? null : data;
	}

	/**
	 * Obtiene toda la informaci�n de los registros y la regresa en formato JSON
	 * @return Cadena JSON
	 */
//	public String getJSONData() {
//		return toJSONArray().toString();
//	}

	/**
	 * Obtiene toda la informaci�n de los registros y la regresa en formato JSON
	 * @return Cadena JSON
	 */
//	public JSONArray toJSONArray() {
//		JSONArray jsonArr = new JSONArray();
//		while (this.next()) {
//			JSONObject jsonObj = new JSONObject();
//			for (int i = 0; i < this.colnames.size(); i++) {
//				jsonObj.put(colnames.get(i), this.getObject(i + 1));
//			}
//			jsonArr.add(jsonObj);
//		}
//		return jsonArr;
//	}
	
	/**
	 * Obtiene la informaci�n.
	 *
	 */
	public List getData() {
		return this.data;
	}

	/**
	 * Obtiene la informaci�n.
	 *
	 */
	public List getData(int indice) {
		return (List)this.data.get(indice);
	}

	/**
	 * Agrega un renglon a la informaci�n.
	 * @param datarow Es una listas que representan un 
	 * 		renglon de una tabla de informaci�n
	 *
	 */
	public void addDataRow(List datarow) {
		if (this.data != null) {
			this.data.add(datarow);
		} else {
			this.data = new ArrayList();
			this.data.add(datarow);
		}
	}

	/**
	 * Obtiene el campo especificado como Cadena
	 *
	 */
	public String getString(String nombreCampo) {
		int indice = -1;
		for(int i=0;i<this.colnames.size();i++){
			String campo = (String) this.colnames.get(i);
			if( campo.equalsIgnoreCase(nombreCampo)){
				indice = i;
				break;
			}
		}
		if (indice == -1) {
			throw new RuntimeException("El campo " + nombreCampo + " no existe");
		}
		List renglon = (List)this.data.get(this.numRegistro);
		return (renglon == null) ? null : renglon.get(indice).toString();
	}
	
	/**
	 *
	 * Obtiene el campo especificado en <tt>nombreCampo</tt> y lo guarda en <tt>valor[0]</tt>. 
	 *
	 * @param nombreCampo <tt>String</tt> con el nombre del campos cuyo valor ser� extraido.
	 * @param valor <tt>String</tt> array donde se guardar� el valor del campo consultado.
	 *
	 * @return <tt>true</tt> si la extracci�n del valor del campo fue exitosa y <tt>false</tt> en caso
	 * 		  contrario.
	 *
	 */
	public boolean getValue(String nombreCampo, Object[] valorCampo) {
		
		int indice = -1;
		for(int i=0;i<this.colnames.size();i++){
			String campo = (String) this.colnames.get(i);
			if( campo.equalsIgnoreCase(nombreCampo)){
				indice = i;
				break;
			}
		}
		if( indice == -1){
			valorCampo[0] = null;
			return false;
		}
		
		List renglon 	= (List) this.data.get(this.numRegistro);
		valorCampo[0] 	= (renglon == null) ? null : renglon.get(indice);
		
		return true;
		
	}

	/**
	 * Obtiene el campo especificado como Cadena
	 * @param posicion Posicion del campo (Primer campo es 1)
	 * @return Cadena con el valor del campo
	 */
	public String getString(int posicion) {
		int indice = posicion - 1;
		List renglon = (List)this.data.get(this.numRegistro);
		return (renglon == null) ? null : renglon.get(indice).toString();

	}

	/**
	 * Obtiene el valor del campo especificado, en el registro en turno, como Objeto
	 *
	 */
	public Object getObject(String nombreCampo) {
		int indice = -1;
		for(int i=0;i<this.colnames.size();i++){
			String campo = (String) this.colnames.get(i);
			if( campo.equalsIgnoreCase(nombreCampo)){
				indice = i;
				break;
			}
		}
		if (indice == -1) {
			throw new RuntimeException("El campo " + nombreCampo + " no existe");
		}

		List renglon = (List)this.data.get(this.numRegistro);

		return renglon.get(indice);
	}

	/**
	 * Obtiene el valor del campo especificado, en el registro en turno, como Objeto
	 * @param posicion Posicion del campo (Primer campo es 1)
	 * @return Cadena con el valor del campo
	 */
	public Object getObject(int posicion) {
		int indice = posicion - 1;
		List renglon = (List)this.data.get(this.numRegistro);

		return renglon.get(indice);
	}

	/**
	 * Establece un nuevo valor del campo especificado, en el registro en turno
	 * @param nombreCampo nombre de la columna a establecer
	 * @param value valor del objeto a establecer
	 */
	public void setObject(String nombreCampo, Object value) {
		int indice = -1;
		for(int i=0;i<this.colnames.size();i++){
			String campo = (String) this.colnames.get(i);
			if( campo.equalsIgnoreCase(nombreCampo)){
				indice = i;
				break;
			}
		}
		if (indice == -1) {
			throw new RuntimeException("El campo " + nombreCampo + " no existe");
		}

		List renglon = (List)this.data.get(this.numRegistro);

		renglon.set(indice, value);
	}

	/**
	 * Establece un nuevo valor del campo especificado, en el registro en turno
	 * @param posicion Posicion del campo (Primer campo es 1)
	 * @return Cadena con el valor del campo
	 */
	public void setObject(int posicion, Object value) {
		int indice = posicion - 1;
		List renglon = (List)this.data.get(this.numRegistro);

		renglon.set(indice, value);
	}


	/**
	 * Determina si hay m�s registros dentro del conjunto de datos contenidos
	 * @return true si existe m�s renglones o false de lo contrario
	 */
	public boolean next() {
		boolean haySiguiente = false;

		if (this.data != null && this.data.size() > 0) {
			this.numRegistro++;
			if (this.numRegistro < this.data.size()) {
				haySiguiente = true;
			} else { //End Of Data
				haySiguiente = false;
				this.numRegistro = -1;
			}
		}
		return haySiguiente;
	}

	/**
	 * Resetea el indice de registros para otra vez comenzar a leer desde el primero
	 */
	public void rewind() {
		numRegistro = -1;
	}

	/**
	 * Regresa el numero de registros contenidos
	 * @return Numero de registros
	 */
	public int getNumeroRegistros() {
		return (data == null) ? 0 : data.size();
	}

	/**
	 * Listado de metadatos de las columnas del registro
	 */
	private List colnames;

	/**
	 * Lista de datos de las columnas del registro
	 */
	private List data;

	/**
	 * Numero de Registro
	 */
	int numRegistro = -1;


	/**
	 * Establece el numero de registro en turno
	 * @param numRegistro
	 */
	public void setNumRegistro(int numRegistro) {
		this.numRegistro = numRegistro;
	}

	/**
	 * Obtiene el numero de registro en turno
	 * @return indice del registro
	 */
	public int getNumRegistro() {
		return this.numRegistro;
	}

	public void remove(int numeroRegistro) {
		this.data.remove(numeroRegistro);
	}

	public void remove() {
		this.data.remove(this.numRegistro);
	}

}
