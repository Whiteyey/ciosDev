package com.app.cios.utilerias.correo;

import java.util.HashMap;
import java.util.List;

import com.app.cios.utilerias.ServiceLocator;

import com.app.cios.utilerias.archivo.ArchivoBean;



import org.apache.commons.logging.Log;

/**
 *
 * Objecto con las propiedades de un mensaje de correo.
 * @author jshernandez
 * @since 09/04/2014 08:11:04 p.m.
 *
 */
public class MensajeCorreoBean {

	// VARIABLES AUXILIARES
	
	private static final Log log = ServiceLocator.getInstance().getLog(MensajeCorreoBean.class);
	
	/**
	 * Login del usuario que envia en el correo.
	 */
	private String loginUsuario;
	
	/**
	 * Nombre del Usuario.
	 */
	private String nombreUsuario;
	
	/**
	 * Id del Correo
	 */
	private Long  mailId;
	
	// VARIABLES PROPIAS DE LA FORMA.
	
	/**
	 * Lista con el detalle del archivo que adjunto el usuario.
	 */
	private List<ArchivoBean> 	archivos;
		
	/**
	 * Direccion de Correo del Remitente.
	 */
	private String remitente;
	
	/**
	 * Direcciones de correo de los destinatarios; separadas por ",".
	 */
	private String destinatarios;
	
	/**
	 * Direcciones de correo de los destinatarios de la copia de carbon; separadas por ",".
	 */
	private String ccDestinatarios;
	
	/**
	 * Direcciones de correo de los destinatarios de la copia oculta; separadas por ",".
	 */
	private String bccDestinatarios;
	
	/**
	 * Titulo del mensaje del correo.
	 */
	private String asunto;
	
	/**
	 * Lista con el cuerpo del mensaje del correo.
	 */
	private List 	cuerpoCorreo;

	// SETTERS / GETTERS DE VARIABLES AUXILIARES

	public String getLoginUsuario() {
		return loginUsuario;
	}

	public void setLoginUsuario(String loginUsuario) {
		this.loginUsuario = loginUsuario;
	}

	public String getNombreUsuario() {
		return nombreUsuario;
	}

	public void setNombreUsuario(String nombreUsuario) {
		this.nombreUsuario = nombreUsuario;
	}

	public Long getMailId() {
		return mailId;
	}

	public void setMailId(Long mailId) {
		this.mailId = mailId;
	}
	
	// SETTERS / GETTERS DE VARIABLES PROPIAS DE LA FORMA
	
	public List getArchivos() {
		return archivos;
	}
	
	public void setArchivos(List archivos) {
		this.archivos = archivos;
	}

	public String getRemitente() {
		return remitente;
	}

	public void setRemitente(String remitente) {
		this.remitente = remitente;
	}
	
	public String getDestinatarios() {
		return destinatarios;
	}

	public void setDestinatarios(String destinatarios) {
		this.destinatarios = destinatarios;
	}

	public String getCcDestinatarios() {
		return ccDestinatarios;
	}

	public void setCcDestinatarios(String ccDestinatarios) {
		this.ccDestinatarios = ccDestinatarios;
	}

	public String getBccDestinatarios() {
		return bccDestinatarios;
	}

	public void setBccDestinatarios(String bccDestinatarios) {
		this.bccDestinatarios = bccDestinatarios;
	}

	public String getAsunto() {
		return asunto;
	}

	public void setAsunto(String asunto) {
		this.asunto = asunto;
	}

	public List getCuerpoCorreo() {
		return cuerpoCorreo;
	}

	public void setCuerpoCorreo(List cuerpoCorreo) {
		this.cuerpoCorreo = cuerpoCorreo;
	}
 
	// METODOS ADICIONALES DE SETTERS / GETTERS DE VARIABLES PROPIAS DE LA FORMA
	
	public String fetchCuerpoCorreo(int indice) {
		
		String contenido = null;
		if( 			this.cuerpoCorreo 			== null 	    	){
			return null;
		} else if( 	this.cuerpoCorreo.size() 	== 0 			 	){
			return null;
		} else if(  indice	<  0 										){
			return null;
		} else if(  indice  >= this.cuerpoCorreo.size() 		){
			return null;	
		}	
		
		HashMap elemento = (HashMap) this.cuerpoCorreo.get(indice);
		if( elemento != null ){
			contenido = (String) elemento.get("contenido");
		}
		
		return contenido;
		
	}
	
	/*
	public String appendArchivos(int indice) {
		return (String) this.cuerpoCorreo.get(indice);
	}
	*/
	
	// M�TODOS AUXILIARES.
	
	public void dump(){
		
		log.error("MensajeCorreoBean.loginUsuario     = <" + loginUsuario     + ">");
	   log.error("MensajeCorreoBean.nombreUsuario    = <" + nombreUsuario    + ">");
	   log.error("MensajeCorreoBean.mailId    		 = <" + mailId    		 + ">");
	   log.error("MensajeCorreoBean.archivos         = <" + archivos         + ">");
	   if( archivos != null ){
			for(int i=0;i<archivos.size();i++){
				log.error("MensajeCorreoBean.archivos["+i+"]:");
				( (ArchivoBean) archivos.get(i)).dump();
			}
		}
		log.error("MensajeCorreoBean.remitente        = <" + remitente        + ">");
		log.error("MensajeCorreoBean.destinatarios    = <" + destinatarios    + ">");
		log.error("MensajeCorreoBean.ccDestinatarios  = <" + ccDestinatarios  + ">");
		log.error("MensajeCorreoBean.bccDestinatarios = <" + bccDestinatarios + ">");
		log.error("MensajeCorreoBean.asunto           = <" + asunto           + ">");
		log.error("MensajeCorreoBean.cuerpoCorreo     = <" + cuerpoCorreo     + ">");		

	}

}
