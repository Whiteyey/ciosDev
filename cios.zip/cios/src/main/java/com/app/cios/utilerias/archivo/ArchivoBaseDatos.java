package com.app.cios.utilerias.archivo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

import java.math.BigDecimal;

import java.sql.PreparedStatement;

import java.sql.ResultSet;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;

import java.util.Calendar;

import com.app.cios.utilerias.AccesoDB;
import com.app.cios.utilerias.AppException;
import com.app.cios.utilerias.Comunes;
import com.app.cios.utilerias.Registros;
import com.app.cios.utilerias.ServiceLocator;
import com.app.cios.utilerias.Validaciones;
import com.app.cios.utilerias.archivo.ArchivoBean;

import java.util.LinkedHashMap;

import java.util.Map;

import org.apache.commons.logging.Log;

/**
 * Clase que se encarga de crear archivos de extraer e insertar archivos a la base de datos,
 * a partir de un objeto de datos, el cual debe implementar la interface <tt>IArchivoBaseDatos</tt>.
 *
 * @author jshernandez
 * @date 22/04/2014 03:31:13 p.m.
 *
 */
public class ArchivoBaseDatos {

	//Variable para enviar mensajes al log.
	private static final Log log = ServiceLocator.getInstance().getLog(ArchivoBaseDatos.class);
	
	// Atributos
	
	/**
	 * Objeto de datos que se utilizar� para extraer/insertar el archivo requerido.
	 *
	 * @param iArchivoBaseDatos Objeto de datos, de tipo <tt>IArchivoBaseDatos</tt>.
	 *
	 */
	private IArchivoBaseDatos iArchivoBaseDatos;

	// Setters / Getters
	
	public IArchivoBaseDatos getIArchivoBaseDatos() {
		return this.iArchivoBaseDatos;
	}

	public void setIArchivoBaseDatos(IArchivoBaseDatos iArchivoBaseDatos) {
		this.iArchivoBaseDatos = iArchivoBaseDatos;
	}

	// M�todos auxiliares
	
	private String getExtensionArchivo(String nombreArchivo){
		
	 	String extension = "";
	 	 	 	
	 	// Determinar extension del archivo
		int ultimoPunto = nombreArchivo != null ? nombreArchivo.lastIndexOf('.') : -1;
		if( ultimoPunto != -1 ){
			extension = nombreArchivo.substring(ultimoPunto).toLowerCase();
		}
		
		// Verificar que la extension sea v�lida
		if(        extension.lastIndexOf("/")  != -1 ){
			extension = "";
		} else if( extension.lastIndexOf("\\") != -1 ){
			extension = "";
		}
		
		return extension;
		
	}
	
	// M�todos con la funcionalidad principal
	
	/**
	 * Realiza la extracci�n de la Base de Datos de un archivo. Si no encuentra el archivo
	 * en la base de datos regresa <tt>null</tt> en el primer elemento del parametro: <tt>archivo</tt>
	 * (y en <tt>msg[0]</tt> regresa la cadena = "NO_ENCONTRADO".<br>
	 * De igual manera si no se encuentra el archivo o si no se especificaron campos adicionales
	 * a la columna donde se almacena el archivo, el primer elemento del par�metro: <tt>registros</tt>
	 * vendr� como <tt>null</tt>.
	 * Si algunos de los campos adicionales indicados en el archivoStatement tiene alguno de los 
	 * siguientes parametros: tituloArchivo, id y/o tipo, estos ser�n asignados al atributo correspondiente
	 * del objeto archivoBean.
	 *
	 *	@param archivo <tt>ArchivoBean[]</tt> con las propiedades del archivo extraido en elemento 0.
	 *	@param registros <tt>Registros[]</tt> con el resultado de la consulta de todos los parametros
	 * adcionales al campo archivo en el elemento 0.   
	 * @param msg <tt>String[]</tt> con algun mensaje, por ejemplo cuando falla 
	 * la operaci�n de extracci�n.
	 *
	 * @return <tt>true</tt> si la operaci�n es exitosa y <tt>false</tt> en caso contrario.
	 *
	 * @author jshernandez
	 * @since 22/04/2014 03:58:37 p.m.
	 *
	 */ 
	 public boolean extrae(ArchivoBean[] archivo, Registros[] registros, String[] msg){
	 	 
	 	boolean				exito							= true;
		
		AccesoDB 			con 							= null;
		boolean				usarConexionLocal			= true;
		PreparedStatement ps 							= null;
		ResultSet		   rs 							= null;
		StringBuffer		query 						= new StringBuffer();
		
		OutputStream 		outputStream 				= null;
		InputStream 		inputStream 				= null;
		
		String 				nombreArchivo				= null;
		
		ArchivoStatement 	archivoStatement			= null;
		Integer				tipoStatement	  			= null;
		
		try {

			// Definir coleccion de tipos de statement validos
			List<Integer> tiposStatementPermitidos = new ArrayList(); // Aprovechamos el autoboxing...
			tiposStatementPermitidos.add(ArchivoStatement.UNDEFINED);
			tiposStatementPermitidos.add(ArchivoStatement.SELECT);
			
			// Obtener atributos de la extraccion
			archivoStatement = this.iArchivoBaseDatos.getStatementExtraeArchivo();
			tipoStatement	  = new Integer(archivoStatement.getTipoStatement());
			
			// Validar que efectivamente se hayan especificado los atributos obligatorios.
			if( archivoStatement == null ){
				
				archivo[0] 		= null;
				registros[0] 	= null;
				msg[0] 			= "ArchivoBaseDatos.extrae: El objeto de datos ArchivoStatement es requerido.";
				exito				= false;
				
				return			exito;
				
			} else if( Validaciones.esVacio( archivoStatement.getTable() ) ){
				
				archivo[0] 		= null;
				registros[0] 	= null;
				msg[0] 			= "ArchivoBaseDatos.extrae: El atributo archivoStatement.table es requerido.";
				exito				= false;
				
				return			exito;
				
			} else if( Validaciones.esVacio( archivoStatement.getParameters() ) ){
				
				archivo[0] 		= null;
				registros[0] 	= null;
				msg[0] 			= "ArchivoBaseDatos.extrae: El atributo archivoStatement.parameters es requerido.";
				exito				= false;
				
				return			exito;
											
			} else if( Validaciones.esVacio( this.iArchivoBaseDatos.getRutaDirectorioTemporal() ) ){
				
				archivo[0] 		= null;
				registros[0] 	= null;
				msg[0] 			= "ArchivoBaseDatos.extrae: El atributo iArchivoBaseDatos.rutaDirectorioTemporal es requerido.";
				exito				= false;
				
				return			exito;
				
			} else if( Validaciones.esVacio( archivoStatement.getColumnArchivo() ) ){
				
				archivo[0] 		= null;
				registros[0] 	= null;
				msg[0] 			= "ArchivoBaseDatos.extrae: El atributo archivoStatement.columnArchivo es requerido.";
				exito				= false;
				
				return			exito;
				
			} else if( Validaciones.esVacio( archivoStatement.getColumnExtension() )  && Validaciones.esVacio( archivoStatement.getExtension() ) ){
				
				archivo[0] 		= null;
				registros[0] 	= null;
				msg[0] 			= "ArchivoBaseDatos.extrae: Se requiere que especifique uno de estos dos atributos: archivoStatement.columnExtension y archivoStatement.extension.";
				exito				= false;
				
				return			exito;
				
			} else if( !Validaciones.esVacio( archivoStatement.getColumnExtension() )  && !Validaciones.esVacio( archivoStatement.getExtension() ) ){
				
				archivo[0] 		= null;
				registros[0] 	= null;
				msg[0] 			= "ArchivoBaseDatos.extrae: Solo puede especificar uno de estos dos atributos: archivoStatement.columnExtension y archivoStatement.extension.";
				exito				= false;
				
				return			exito;
				
			} else if( !tiposStatementPermitidos.contains(tipoStatement) ){
				
				archivo[0] 		= null;
				msg[0] 			= "ArchivoBaseDatos.extrae: El atributo archivoStatement.tipoStatement no es v�lido.";
				exito				= false;
				
				return			exito;
				
			}
			
			// Preparar conexion a la Base de Datos
			con = this.iArchivoBaseDatos.getAccesoDB();
			if( con == null ){
				usarConexionLocal = true;
				// Conectarse a la Base  de Datos
				con = new AccesoDB();
				con.conexionDB();
			} else {
				usarConexionLocal = false;
			}
			
			// Atributos requeridos
			String 			columnArchivo 				= archivoStatement.getColumnArchivo();
			String 			columnExtension 			= archivoStatement.getColumnExtension();
			String   		table							= archivoStatement.getTable();
			LinkedHashMap	fields						= archivoStatement.getFields();
			Iterator			parametersIterator		= null;
			HashMap			nullParametersTypes		= archivoStatement.getNullParametersTypes();
			Iterator			fieldsIterator				= Validaciones.esVacio( fields )?null:fields.entrySet().iterator();
			
			// Determinar si para calcular la extension del archivo se utilizar� un campo de la base de datos
			boolean 			usarColumnExtension		= !Validaciones.esVacio( columnExtension )?true:false;
			
			// Determinar el alias que se utilizar� para obtener la extensi�n del archivo
			String 			aliasColumnExtension		= null;
			if( usarColumnExtension && fieldsIterator != null ){
				while( fieldsIterator.hasNext() ){
					Map.Entry 	entry = (Map.Entry) fieldsIterator.next();
					String 		field = (String) entry.getKey();
					String 		alias = (String) entry.getValue();
					if( columnExtension.equalsIgnoreCase(field) ){
						aliasColumnExtension = alias;
						break;
					}
				}
				// Reponer iterator utilizado
				fieldsIterator				= fields.entrySet().iterator();
			}
			
			// Determinar si se agregara la columna de la cual se extraera la extension, al query de consulta.
			boolean agregarColumnaExtension = false;
			if( usarColumnExtension && Validaciones.esVacio( aliasColumnExtension ) ){
				agregarColumnaExtension = true;
				aliasColumnExtension		= columnExtension;
			}
			
			// Construir lista de alias de los campos, para ser usado por el objeto registros por ejemplo.
			List fieldAlias = new ArrayList();
			if( agregarColumnaExtension ){
				fieldAlias.add(aliasColumnExtension);
			}
			if( fieldsIterator != null ){
				while( fieldsIterator.hasNext() ){
					Map.Entry 	entry = (Map.Entry) fieldsIterator.next();
					String 		field = (String) entry.getKey();
					String 		alias = (String) entry.getValue();
				
					if( columnArchivo.equalsIgnoreCase( field ) ){
						continue;
					}
					fieldAlias.add( alias );
				}
				// Reponer iterator utilizado
				fieldsIterator				= fields.entrySet().iterator();
			}
						
			// Construir query con el que se realizar� la extracci�n del archivo
			query.setLength(0);
			query.append(" SELECT");
			query.append(" "); query.append( columnArchivo );
			// Agregar columna que se utilizar� para obtener la extension
			if( agregarColumnaExtension ){
				query.append(" ,"); query.append( columnExtension ); query.append( " AS \"" ); query.append( aliasColumnExtension ); query.append( "\"" );
			}
			// Agregar campos adicionales que haya especificado el usuario
			while( fieldsIterator != null && fieldsIterator.hasNext() ){
				Map.Entry 	entry = (Map.Entry) fieldsIterator.next();
				String 		field = (String) entry.getKey();
				String 		alias = (String) entry.getValue();
				if( columnArchivo.equalsIgnoreCase( field ) ){
					continue;
				}
				query.append(" ,"); query.append( field ); query.append( " AS \"" ); query.append( alias ); query.append( "\"" );
			}
			query.append(" FROM");
			query.append(" "); query.append( table );
			query.append(" WHERE");
			parametersIterator = archivoStatement.getParameters().entrySet().iterator();
			for( int paramterCount = 0; parametersIterator != null &&  parametersIterator.hasNext(); paramterCount++ ){
				Map.Entry 	entry 		= (Map.Entry) parametersIterator.next();
				String 		parameter 	= (String) entry.getKey();
				if( paramterCount > 0 ){
					query.append(" AND ");
				} else {
					query.append(" ");
				}
				query.append( parameter ); 
				query.append( " = ?" ); 
			}
			
			// Agregar Condiciones
			ps = con.queryPrecompilado(query.toString());
			parametersIterator = archivoStatement.getParameters().entrySet().iterator();
			for(int idx = 1; parametersIterator.hasNext(); idx++ ){
				
				Map.Entry 	entry 		= (Map.Entry) parametersIterator.next();
				
				String 		parameter 	= (String) entry.getKey();
				Object 		value 		= entry.getValue();
				
				if (			value ==        null 					) {
					int sqlTypes = ((Integer) nullParametersTypes.get(parameter)).intValue();
					ps.setNull(idx, 			sqlTypes );
				} else if (	value instanceof String 				) {
					ps.setString(idx, 		( (String) value 	)					);
				} else if ( value instanceof Integer				) {
					ps.setInt(idx, 			( (Integer) value).intValue() 	);
				} else if ( value instanceof Long					) {
					ps.setLong(idx, 			( (Long) value).longValue()  		);
				} else if ( value instanceof Double					) {
					ps.setDouble(idx, 		( (Double) value).doubleValue()  );
				} else if ( value instanceof BigDecimal			) {
					ps.setBigDecimal(idx, 	(BigDecimal) value 					);
				} else if ( value instanceof java.util.Calendar	) {
					ps.setTimestamp(idx, 	new java.sql.Timestamp(((java.util.Calendar)value).getTime().getTime()), 	Calendar.getInstance() );
				} else if ( value instanceof java.util.Date		) {
					ps.setTimestamp(idx, 	new java.sql.Timestamp(((java.util.Date)value).getTime()), 						Calendar.getInstance() );
				} 
				
			}
			
			// Realizar consulta
			rs = ps.executeQuery();
			if( rs.next() ){

				// Determinar la extension del archivo
				String extension = null;
				if( usarColumnExtension ){
					String tituloArchivo		 	= (rs.getString(aliasColumnExtension) == null)?"":rs.getString(aliasColumnExtension);
					extension 						= getExtensionArchivo(tituloArchivo);
				} else {
					extension 						= archivoStatement.getExtension();
				}
			
				// Generar Ruta Absoluta al Archivo
				StringBuffer rutaAbsolutaArchivo	= new StringBuffer();
				rutaAbsolutaArchivo.append(this.iArchivoBaseDatos.getRutaDirectorioTemporal());
				if( !Validaciones.esVacio(this.iArchivoBaseDatos.getLoginUsuario() ) ){
					rutaAbsolutaArchivo.append( this.iArchivoBaseDatos.getLoginUsuario() );
					rutaAbsolutaArchivo.append( "." );
				}
				// Generar Nombre Aleatorio del Archivo
				rutaAbsolutaArchivo.append( Comunes.cadenaAleatoria(16) );
				// Agregar extension
				rutaAbsolutaArchivo.append( extension );
								
				// Crear outputstream con la ruta absoluta del archivo
				outputStream					= new FileOutputStream( rutaAbsolutaArchivo.toString() );

				// Guardar archivo en disco
				inputStream 			= rs.getBinaryStream(columnArchivo);
				byte[]   buffer      = new byte [ 4 * 1024 ]; // 4 KB 
				int      bytesRead   = 0;
				while(  ( bytesRead  = inputStream.read( buffer ) )  != -1 ){
            	outputStream.write( buffer, 0, bytesRead );
            	outputStream.flush();
            }
            
            // Crear objeto ArchivoBean
            ArchivoBean archivoBean = new ArchivoBean();
            // Agregar ruta absoluta del archivo extraido
            archivoBean.setRutaAbsoluta( rutaAbsolutaArchivo.toString() );
            // Agregar atributos adicionales a archivoBean: tituloArchivo, id y tipo.
            for(int i=0;i<fieldAlias.size();i++){
            	
					String alias 		= (String) fieldAlias.get(i);
					String fieldValue = (rs.getString(alias) == null)?"":rs.getString(alias);
					
					if( 		  "tituloArchivo".equals(alias) ){
						archivoBean.setTituloArchivo(fieldValue);
					// Debug info: se deshabilita el env�o de ids temporalmente
					//} else if( "id".equals(alias) ){
					//	archivoBean.setId(new Long(fieldValue));
					} else if( "tipo".equals(alias) ){
						archivoBean.setTipo(fieldValue);
					}
					
				}
				
            // Construir objeto registros con los valores de los campos adicionales
				Registros registro = new Registros();
				// Agregar Definicion de las columnas
				registro.setNombreColumnas(fieldAlias);
				// Agregar detalle de las columnas
				List columnas = new ArrayList();
				for(int i=0;i<fieldAlias.size();i++){
					String alias 		= (String) fieldAlias.get(i);
					String fieldValue = (rs.getString(alias) == null)?"":rs.getString(alias);
					columnas.add(fieldValue);					
				}
				// Agregar contenido del renglon a los renglones
				List renglones = new ArrayList();
				renglones.add(columnas);
				// Agregar contenido de toda la consulta
				registro.setData(renglones);
				
				// Agregar Archivo Bean a la respuesta
            archivo[0] 		= archivoBean;
				// Agregar al array de registros el objeto registro
            registros[0] 	= registro;
            // No hay ning�n mensaje que enviar, para el caso exitoso
            msg[0] 			= null;
  
			} else {
				
				archivo[0] 		= null;
				registros[0] 	= null;
				msg[0] 			= "NO_ENCONTRADO";
				
			}
			
		} catch(Exception e){
			
			exito = false;
			
			log.error("extrae(Exception)");
			log.error("extrae.archivo   	 		= <" + archivo               + ">");
			log.error("extrae.registros  			= <" + registros             + ">");
			log.error("extrae.msg        			= <" + msg                   + ">");
			log.error("iArchivoBaseDatos  			= <" + this.iArchivoBaseDatos + ">");
			log.error("extrae.archivoStatement  = <" + archivoStatement      + ">");
			log.error("extrae.query             = <" + query.toString()      + ">");
			if( archivoStatement != null ){
				archivoStatement.dump();
			}
			e.printStackTrace();
			
			archivo[0] 		= null;
			registros[0]	= null;
			msg[0] 			= e.getMessage();
			
		} finally {
			
			if( inputStream	!= null ){ try { inputStream.close();  } catch(Exception e){}  }
			if( outputStream	!= null ){ try { outputStream.close(); } catch(Exception e){}  }

			if( rs 				!= null ){ try { rs.close();				} catch(Exception e){} 	}
		 	if( ps 				!= null ){ try { ps.close();				} catch(Exception e){} 	}
		 	
		 	if( usarConexionLocal && con != null && con.hayConexionAbierta() ) {
				con.cierraConexionDB();
			}
						
		}
			
		return exito;
		
	}
	
   /**
	 * Realiza la insercion/actualizacion de un archivo en la Base de Datos. Si el archivo existe en la base
	 * de datos lo actualiza y si no existe, lo inserta; pero si el usuario especifica el <tt>tipoStatement</tt> en la
	 * la clase de datos, solo se realizar� esta, pudiendo fallar la operaci�n si el archivo a insertar ya existe.
	 *
	 *	@param archivo <tt>ArchivoBean[]</tt> con las propiedades del archivo insertado en elemento 0. El archivo
	 * que ser� insertado deber� ser agregado como par�metro en la instancia de <tt>ArchivoStatement</tt>.
	 * @param msg <tt>String[]</tt> con algun mensaje, por ejemplo cuando falla la operaci�n de inserci�n, 
	 * o si hay alg�n error en la instancia de la clase: <tt>IArchivoBaseDatos</tt>.
	 *
	 * @return <tt>true</tt> si la operaci�n es exitosa y <tt>false</tt> en caso contrario.
	 *
	 * @author jshernandez
	 * @since 22/04/2014 03:58:40 p.m.
	 *
	 */ 
	 public boolean guarda(ArchivoBean[] archivo, String[] msg){

		boolean 				exito 					= true;

		AccesoDB 			con 						= null;
		boolean				usarConexionLocal		= true;
		StringBuffer		sqlStatement			= new StringBuffer();
		PreparedStatement ps 						= null;
		ResultSet 			rs 						= null;
		
		ArchivoStatement 	archivoStatement 				= null;
		Integer				tipoStatement	  				= null;
		File 				 	archivoGuardar					= null;
		FileInputStream 	archivoGuardarInputstream 	= null;
		
		try {
			
			// Definir coleccion de tipos de statement validos
			List<Integer> tiposStatementPermitidos = new ArrayList(); // Aprovechamos el autoboxing...
			tiposStatementPermitidos.add(ArchivoStatement.UNDEFINED);
			tiposStatementPermitidos.add(ArchivoStatement.UPDATE);
			tiposStatementPermitidos.add(ArchivoStatement.INSERT);

			// Obtener atributos de la extraccion
			archivoStatement = this.iArchivoBaseDatos.getStatementGuardaArchivo();
			tipoStatement	  = new Integer(archivoStatement.getTipoStatement());
			
			// Validar que efectivamente se hayan especificado los atributos obligatorios.
			if( archivoStatement == null ){
				
				archivo[0] 		= null;
				msg[0] 			= "ArchivoBaseDatos.guarda: El objeto de datos ArchivoStatement es requerido.";
				exito				= false;
				
				return			exito;
				
			} else if( Validaciones.esVacio( archivoStatement.getTable() ) ){
				
				archivo[0] 		= null;
				msg[0] 			= "ArchivoBaseDatos.guarda: El atributo archivoStatement.table es requerido.";
				exito				= false;
				
				return			exito;
				
			} else if( Validaciones.esVacio( archivoStatement.getColumnArchivo() ) ){
				
				archivo[0] 		= null;
				msg[0] 			= "ArchivoBaseDatos.guarda: El atributo archivoStatement.columnArchivo es requerido.";
				exito				= false;
				
				return			exito;
				
			} else if( Validaciones.esVacio( archivoStatement.getParameters() ) ){
				
				archivo[0] 		= null;
				msg[0] 			= "ArchivoBaseDatos.guarda: El atributo archivoStatement.parameters es requerido.";
				exito				= false;
				
				return			exito;
			
			} else if( Validaciones.esVacio( archivoStatement.getPrimaryKeys() ) ){
			      
			   archivo[0]     = null;
			   msg[0]         = "ArchivoBaseDatos.guarda: El atributo archivoStatement.parameters no contiene llaves primarias.";
			   exito          = false;
			      
			   return         exito;
			      
			} else if( !tiposStatementPermitidos.contains(tipoStatement) ){
				
				archivo[0] 		= null;
				msg[0] 			= "ArchivoBaseDatos.guarda: El atributo archivoStatement.tipoStatement no es v�lido.";
				exito				= false;
				
				return			exito;
				
			}
			
			// Atributos requeridos
			HashMap			nullParametersTypes		= archivoStatement.getNullParametersTypes();
			LinkedHashMap	primaryKeys					= archivoStatement.getPrimaryKeys();
			String 			columnArchivo 				= archivoStatement.getColumnArchivo();
			LinkedHashMap	fields						= archivoStatement.getFields();
			
			// Verificar que el achivo proporcionado en el atributo parametro sea v�lido
			ArchivoBean		archivoBean					= null;
			// Obtener archivoBean
			Iterator			parametersIterator		= archivoStatement.getParameters().entrySet().iterator();
			for(int idx = 1; parametersIterator.hasNext(); idx++ ){
				
				Map.Entry 	entry 		= (Map.Entry) parametersIterator.next();
				
				String 		parameter 	= (String) entry.getKey();
				Object 		value 		= entry.getValue();
				
				if( columnArchivo.equalsIgnoreCase(parameter) ){
					archivoBean = ( ArchivoBean ) value;
					break;
				}
				
			}
			// Validar archivoBean
			if( archivoBean == null ){
				
				archivo[0] 		= null;
				msg[0] 			= "ArchivoBaseDatos.guarda: En la lista archivoStatement.parameters se requiere que uno de sus componentes sea de tipo ArchivoBean.";;
				exito				= false;
				
				return			exito;
				
			} else if( !Validaciones.esArchivoValido(archivoBean) ){
				
				archivo[0] 		= null;
				msg[0] 			= "ArchivoBaseDatos.guarda: El archivoBean indicado en la lista archivoStatement.parameters no es v�lido.";
				exito				= false;
				
				return			exito;
				
			}
			
			// Preparar conexion a la Base de Datos
			con = this.iArchivoBaseDatos.getAccesoDB();
			if( con == null ){
				usarConexionLocal = true;
				// Conectarse a la Base  de Datos
				con = new AccesoDB();
				con.conexionDB();
			} else {
				usarConexionLocal = false;
			}
			
			// Determinar el n�mero de registros a actualizar
			Long 			numeroRegistros 		= 0L;
			String 		table 					= archivoStatement.getTable();
		   Iterator    primaryKeysIterator  = archivoStatement.getPrimaryKeys().entrySet().iterator();
			if( tipoStatement == ArchivoStatement.UNDEFINED || tipoStatement == ArchivoStatement.UPDATE  ){
				
				sqlStatement.setLength(0);
				sqlStatement.append(" SELECT");
				sqlStatement.append("    COUNT(1) AS NUMERO_REGISTROS ");
				sqlStatement.append(" FROM");
				sqlStatement.append("    "); sqlStatement.append( table );
				sqlStatement.append(" WHERE");
				for( int primaryKeyCount = 0; primaryKeysIterator.hasNext(); primaryKeyCount++ ){
					Map.Entry 	entry 					= (Map.Entry) primaryKeysIterator.next();
					String 		primaryKeyparameter 	= (String) entry.getKey();
					if( primaryKeyCount > 0 ){
						sqlStatement.append("    AND ");
					} else {
						sqlStatement.append("    ");
					}
					sqlStatement.append( primaryKeyparameter ); 
					sqlStatement.append( " = ?" ); 
				}
				
				// Agregar Condiciones
				primaryKeysIterator  = archivoStatement.getPrimaryKeys().entrySet().iterator();
				ps = con.queryPrecompilado( sqlStatement.toString() );
				for(int idx = 1; primaryKeysIterator.hasNext(); idx++ ){
				
					Map.Entry 	entry 					= (Map.Entry) primaryKeysIterator.next();
					
					String 		primaryKeyParameter 	= (String) entry.getKey();
					Object 		value 					= entry.getValue();
					
					if (			value ==        null 					) {
						int sqlTypes = ((Integer) nullParametersTypes.get(primaryKeyParameter)).intValue();
						ps.setNull(idx, 			sqlTypes );
					} else if (	value instanceof String 				) {
						ps.setString(idx, 		( (String) value 	)					);
					} else if ( value instanceof Integer				) {
						ps.setInt(idx, 			( (Integer) value).intValue() 	);
					} else if ( value instanceof Long					) {
						ps.setLong(idx, 			( (Long) value).longValue()  		);
					} else if ( value instanceof Double					) {
						ps.setDouble(idx, 		( (Double) value).doubleValue()  );
					} else if ( value instanceof BigDecimal			) {
						ps.setBigDecimal(idx, 	(BigDecimal) value 					);
					} else if ( value instanceof java.util.Calendar	) {
						ps.setTimestamp(idx, 	new java.sql.Timestamp(((java.util.Calendar)value).getTime().getTime()), 	Calendar.getInstance() );
					} else if ( value instanceof java.util.Date		) {
						ps.setTimestamp(idx, 	new java.sql.Timestamp(((java.util.Date)value).getTime()), 						Calendar.getInstance() );
					} 
				
				}
				
				rs = ps.executeQuery();
				rs.next();
				numeroRegistros = rs.getLong("NUMERO_REGISTROS");
				
				rs.close();
				ps.close();
				

			}
			// Validar que el n�mero de registros referenciados por la llave primaria, no sea m�s de uno.
			if( numeroRegistros > 1L ){
				
				archivo[0] 		= null;
				msg[0] 			= "ArchivoBaseDatos.guarda: No se permite actualizar m�s de un registro, favor de revisar la llave primaria.";
				exito				= false;
					
				return			exito;
				
			// En caso de ser update validar que el registro a actualizar exista.
			} else if( tipoStatement == ArchivoStatement.UPDATE && numeroRegistros == 0L ){
				
				archivo[0] 		= null;
				msg[0] 			= "ArchivoBaseDatos.guarda: La llave primaria hace referencia a un registro inexistente, por lo que el archivo no podr� ser actualizado.";
				exito				= false;
					
				return			exito;
				
			}
			
			// Nota: Se omite validaci�n para insert cuando ya existen registros, el proposito de esta validaci�n
			// es revisar que la llave primaria solo haga referencia a un solo registro
				
			// Determinar el tipo de operaci�n a realizar, si ya existe, el archivo se actualiza y si no existe, el archivo se inserta.
			if(        tipoStatement == ArchivoStatement.UNDEFINED && numeroRegistros == 0L ){
				tipoStatement = ArchivoStatement.INSERT;
			} else if( tipoStatement == ArchivoStatement.UNDEFINED && numeroRegistros == 1L ){
				tipoStatement = ArchivoStatement.UPDATE;
			}

			// Preparar statement para guardar el registro.
			sqlStatement.setLength(0);
			if(        tipoStatement == ArchivoStatement.INSERT ){
				
				// Construir statement
				sqlStatement.append(" INSERT INTO");
				sqlStatement.append("   ");sqlStatement.append(table);
				sqlStatement.append("   (");
				parametersIterator		= archivoStatement.getParameters().entrySet().iterator();
				for( int paramterCount = 0; parametersIterator.hasNext(); paramterCount++ ){
					Map.Entry 	entry 		= (Map.Entry) parametersIterator.next();
					String 		parameter 	= (String) entry.getKey();
					if( paramterCount > 0 ){
						sqlStatement.append("   ,");
					} else {
						sqlStatement.append("    ");
					}
					sqlStatement.append( parameter ); 
				}
				sqlStatement.append("   )");
				sqlStatement.append(" VALUES");
				sqlStatement.append("   (");
				parametersIterator	  = archivoStatement.getParameters().entrySet().iterator();
				for( int paramterCount = 0; parametersIterator.hasNext(); paramterCount++ ){
					Map.Entry 	entry 		= (Map.Entry) parametersIterator.next();
					if( paramterCount > 0 ){
						sqlStatement.append("   ,");
					} else {
						sqlStatement.append("    ");
					}
					sqlStatement.append( "?" ); 
				}
				sqlStatement.append("   )");
				
				// Agregar valores de los parametros
				ps = con.queryPrecompilado(sqlStatement.toString());
				parametersIterator	  = archivoStatement.getParameters().entrySet().iterator();
				for(int idx = 1; parametersIterator.hasNext(); idx++ ){
					
					Map.Entry 	entry 		= (Map.Entry) parametersIterator.next();
					
					String 		parameter 	= (String) entry.getKey();
					Object 		value 		= entry.getValue();
					
					if (			value ==        null 					) {
						int sqlTypes = ((Integer) nullParametersTypes.get(parameter)).intValue();
						ps.setNull(idx, 			sqlTypes );
					} else if (	value instanceof String 				) {
						ps.setString(idx, 		( (String) value 	)					);
					} else if ( value instanceof Integer				) {
						ps.setInt(idx, 			( (Integer) value).intValue() 	);
					} else if ( value instanceof Long					) {
						ps.setLong(idx, 			( (Long) value).longValue()  		);
					} else if ( value instanceof Double					) {
						ps.setDouble(idx, 		( (Double) value).doubleValue()  );
					} else if ( value instanceof BigDecimal			) {
						ps.setBigDecimal(idx, 	(BigDecimal) value 					);
					} else if ( value instanceof java.util.Calendar	) {
						ps.setTimestamp(idx, 	new java.sql.Timestamp(((java.util.Calendar)value).getTime().getTime()), 	Calendar.getInstance() );
					} else if ( value instanceof java.util.Date		) {
						ps.setTimestamp(idx, 	new java.sql.Timestamp(((java.util.Date)value).getTime()), 						Calendar.getInstance() );
					} else if ( value instanceof com.app.cios.utilerias.archivo.ArchivoBean ) {
						archivoGuardar 				= new File( (( ArchivoBean ) value).getRutaAbsoluta());
						archivoGuardarInputstream 	= new FileInputStream(archivoGuardar);
						ps.setBinaryStream(idx, archivoGuardarInputstream, (int) archivoGuardar.length() );
					}

				}
				ps.executeUpdate();
			
			} else if( tipoStatement == ArchivoStatement.UPDATE ){
				
				// Construir statement
				sqlStatement.append(" UPDATE");
				sqlStatement.append("   ");sqlStatement.append(table);
				sqlStatement.append(" SET");
				parametersIterator		= archivoStatement.getParameters().entrySet().iterator();
				for( int paramterCount = 0; parametersIterator.hasNext(); paramterCount++ ){
					Map.Entry 	entry 		= (Map.Entry) parametersIterator.next();
					String 		parameter 	= (String) entry.getKey();
					// Si el parametro es parte de la llave primaria, este no se agregar�
					if( primaryKeys.containsKey(parameter) ){
						--paramterCount; // Se quita del conteo de parametros agregados
						continue;
					}
					if( paramterCount > 0 ){
						sqlStatement.append("   ,");
					} else {
						sqlStatement.append("    ");
					}
					sqlStatement.append( parameter ); 
					sqlStatement.append( " = ?" ); 
				}
				sqlStatement.append(" WHERE");
				primaryKeysIterator = archivoStatement.getPrimaryKeys().entrySet().iterator();
				for( int primaryKeyCount = 0; primaryKeysIterator.hasNext(); primaryKeyCount++ ){
					Map.Entry 	entry 					= (Map.Entry) primaryKeysIterator.next();
					String 		primaryKeyparameter 	= (String) entry.getKey();
					if( primaryKeyCount > 0 ){
						sqlStatement.append("    AND ");
					} else {
						sqlStatement.append("    ");
					}
					sqlStatement.append( primaryKeyparameter ); 
					sqlStatement.append( " = ?" ); 
				}
				
				// Agregar valores de los parametros
				ps = con.queryPrecompilado(sqlStatement.toString());
				parametersIterator		= archivoStatement.getParameters().entrySet().iterator();
				int idx = 1;
				for( int paramterCount = 0; parametersIterator.hasNext(); paramterCount++, idx++ ){
					
					Map.Entry 	entry 		= (Map.Entry) parametersIterator.next();
					String 		parameter 	= (String) entry.getKey();
					Object 		value 		= entry.getValue();
					
					// Si el parametro es parte de la llave primaria, este no se agregar�
					if( primaryKeys.containsKey(parameter) ){
						--idx;
						--paramterCount; // Se quita del conteo de parametros agregados
						continue;
					}
					
					if (			value ==        null 					) {
						int sqlTypes = ((Integer) nullParametersTypes.get(parameter)).intValue();
						ps.setNull(idx, 			sqlTypes );
					} else if (	value instanceof String 				) {
						ps.setString(idx, 		( (String) value 	)					);
					} else if ( value instanceof Integer				) {
						ps.setInt(idx, 			( (Integer) value).intValue() 	);
					} else if ( value instanceof Long					) {
						ps.setLong(idx, 			( (Long) value).longValue()  		);
					} else if ( value instanceof Double					) {
						ps.setDouble(idx, 		( (Double) value).doubleValue()  );
					} else if ( value instanceof BigDecimal			) {
						ps.setBigDecimal(idx, 	(BigDecimal) value 					);
					} else if ( value instanceof java.util.Calendar	) {
						ps.setTimestamp(idx, 	new java.sql.Timestamp(((java.util.Calendar)value).getTime().getTime()), 	Calendar.getInstance() );
					} else if ( value instanceof java.util.Date		) {
						ps.setTimestamp(idx, 	new java.sql.Timestamp(((java.util.Date)value).getTime()), 						Calendar.getInstance() );
					} else if ( value instanceof com.app.cios.utilerias.archivo.ArchivoBean ) {
						archivoGuardar 				= new File( (( ArchivoBean ) value).getRutaAbsoluta());
						archivoGuardarInputstream 	= new FileInputStream(archivoGuardar);
						ps.setBinaryStream(idx, archivoGuardarInputstream, (int) archivoGuardar.length() );
					}
					
				}
				
				primaryKeysIterator = archivoStatement.getPrimaryKeys().entrySet().iterator();
				for( int primaryKeyCount = 0; primaryKeysIterator.hasNext(); primaryKeyCount++, idx++ ){
					
					Map.Entry 	entry 					= (Map.Entry) primaryKeysIterator.next();
					String 		primaryKeyparameter 	= (String) entry.getKey();
					Object 		value 					= entry.getValue();
					
					if (			value ==        null 					) {
						int sqlTypes = ((Integer) nullParametersTypes.get(primaryKeyparameter)).intValue();
						ps.setNull(idx, 			sqlTypes );
					} else if (	value instanceof String 				) {
						ps.setString(idx, 		( (String) value 	)					);
					} else if ( value instanceof Integer				) {
						ps.setInt(idx, 			( (Integer) value).intValue() 	);
					} else if ( value instanceof Long					) {
						ps.setLong(idx, 			( (Long) value).longValue()  		);
					} else if ( value instanceof Double					) {
						ps.setDouble(idx, 		( (Double) value).doubleValue()  );
					} else if ( value instanceof BigDecimal			) {
						ps.setBigDecimal(idx, 	(BigDecimal) value 					);
					} else if ( value instanceof java.util.Calendar	) {
						ps.setTimestamp(idx, 	new java.sql.Timestamp(((java.util.Calendar)value).getTime().getTime()), 	Calendar.getInstance() );
					} else if ( value instanceof java.util.Date		) {
						ps.setTimestamp(idx, 	new java.sql.Timestamp(((java.util.Date)value).getTime()), 						Calendar.getInstance() );
					} else if ( value instanceof com.app.cios.utilerias.archivo.ArchivoBean ) {
						archivoGuardar 				= new File( (( ArchivoBean ) value).getRutaAbsoluta());
						archivoGuardarInputstream 	= new FileInputStream(archivoGuardar);
						ps.setBinaryStream(idx, archivoGuardarInputstream, (int) archivoGuardar.length() );
					}
					
					
				}
				ps.executeUpdate();

			}
			
			// Extraer propiedades adicionales
			archivoBean = new ArchivoBean();
			parametersIterator	  = archivoStatement.getParameters().entrySet().iterator();
			for( int paramterCount = 0; parametersIterator.hasNext(); paramterCount++ ){
					
				Map.Entry 	entry 		= (Map.Entry) parametersIterator.next();
				String 		parameter 	= (String) entry.getKey();
			   Object   	value       = entry.getValue();
					
				if( fields.containsKey(parameter) ){
					
					String 	alias 		= (String) fields.get(parameter);
				   String   stringValue	= null;
					
					if(value != null){
					   stringValue = value.toString();
					}
					
					if( 		  "tituloArchivo".equals(alias) ){
						archivoBean.setTituloArchivo(stringValue);
					// Debug info: por el momento no se pueden regresar ids
					//} else if( "id".equals(alias) ){
					//	archivoBean.setId(new Long(value));
					} else if( "tipo".equals(alias) ){
						archivoBean.setTipo(stringValue);
					}
						
				} else if( value instanceof com.app.cios.utilerias.archivo.ArchivoBean ){
						
					archivoBean.setRutaAbsoluta(
						(( ArchivoBean ) value).getRutaAbsoluta()
					);
						
				}

			}
				
			// Agregar resultado de la operaci�n
			archivo[0]	= archivoBean;
			msg[0] 		= null;
						
		} catch(Exception e){
			
			exito = false;
			
			log.error("guarda(Exception)");
			log.error("guarda.archivoGuardar    = <" + archivoGuardar        + ">");
			log.error("guarda.msg               = <" + msg                   + ">");
			log.error("iArchivoBaseDatos  		= <" + this.iArchivoBaseDatos + ">");
			log.error("guarda.archivoStatement  = <" + archivoStatement + ">");
			if( archivoStatement != null ){
				archivoStatement.dump();
			}
			e.printStackTrace();

			archivo[0]	= null;
			msg[0] 		= e.getMessage();
			
		} finally {
			
			if( archivoGuardarInputstream != null ) { try { archivoGuardarInputstream.close(); 	} catch( Exception e ){} }
			
			if( rs                 			!= null ) { try { rs.close();                 			} catch( Exception e ){} }
			if( ps                 			!= null ) { try { ps.close();                 			} catch( Exception e ){} }
			
			if( usarConexionLocal && con != null && con.hayConexionAbierta() ) {
				con.terminaTransaccion(exito);
				con.cierraConexionDB();
			}
						
		}

		return exito;
		
	}

	
	// Opcionalmente se podr�a agregar funcionalidad para elminar archivos.
	/*
	public boolean eliminar(ArchivoBean[] archivoBean, String[] msg){ }
	*/
	 
	// M�todos Auxiliares
	 
}
