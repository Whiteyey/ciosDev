/**
 * 
 */
package com.app.cios.constantes;

/**
 * @author Jhonatan Pacheco <jhonatanpachecohernandez@gmail.com>
 *
 */
public class TipoUsuarios {
	
	public static final int ADMINSTRADOR = 1; 
	public static final int ADMINSTRADOR_RH = 2;

}
