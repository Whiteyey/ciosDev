/**
 * 
 */
package com.app.cios.modulos.seguridad;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.app.cios.beans.SesUsuarioCiosDTO;

/**
 * @author Jhonatan Pacheco <jhonatanpachecohernandez@gmail.com>
 *
 */
@Controller
@RequestMapping(value ="/seguridad")
public class SeguridadController {
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String indexPage(ModelMap model,HttpServletRequest request) {
		ModelAndView aux= com.app.cios.utilerias.LoginUtil.isValidLogin(request);
		if(aux!=null){
			return "redirect:/";
		}
		HttpSession session = request.getSession();

		SesUsuarioCiosDTO u = (SesUsuarioCiosDTO) session.getAttribute("sesUsuario");
		model.addAttribute("title","Seguridad");
		model.addAttribute("titlePage", "Main");
		model.addAttribute("user", u.getNombreCompleto());
		return "seguridad/secure";

	}

	
}
