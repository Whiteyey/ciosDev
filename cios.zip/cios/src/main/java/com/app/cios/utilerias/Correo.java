package com.app.cios.utilerias;

import java.util.Properties;

import javax.mail.BodyPart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.Message;

public class Correo {

	/**
	 * M�todo para enviar correo en codigo HTML 
	 * @param from Remitente
	 * @param to Destinatario
	 * @param subject Titulo del mensaje
	 * @param contenidoMensaje Cadena de texto correspondiente al c�digo HTML
	 */
	public static void enviarTextoHTML(String from, String to, String subject, 
												  String contenidoMensaje) {
		enviarTextoHTML(from, to, subject, contenidoMensaje, "", "");
	}


	/**
	 * M�todo para enviar correo en codigo HTML 
	 * @param from Remitente
	 * @param to Destinatario
	 * @param subject Titulo del mensaje
	 * @param contenidoMensaje Cadena de texto correspondiente al c�digo HTML
	 * @param cc Destinatario Copia	(Carbon Copy)
	 * @param bcc Destinatario Copia Oculta (Blind Carbon Copy)
	 */
	public static void enviarTextoHTML(String from, String to, String subject, 
												  String contenidoMensaje, String cc, 
												  String bcc) throws AppException {
		System.out.println("enviarHTML(E)");

		AccesoDB con = new AccesoDB();
		try {
			Properties props = System.getProperties();
			// Setup mail server
			props.put("mail.smtp.host", 
						 ParametrosGlobalesApp.getInstance().getParametro("SMTP_HOST"));
			// Get session
			Session session = Session.getInstance(props, null);

			//Session session = Session.getDefaultInstance(AdminDoctosProperties.getSmtpProperties());
			// Define message
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(from));
			if (to != null && !to.equals("")) {
				message.addRecipients(Message.RecipientType.TO, to);
			}
			if (cc != null && !cc.equals("")) {
				message.addRecipients(Message.RecipientType.CC, cc);
			}
			if (bcc != null && !bcc.equals("")) {
				message.addRecipients(Message.RecipientType.BCC, bcc);
			}
			message.setSubject(subject, "UTF-8");

			// Create a Multipart
			MimeMultipart multipart = new MimeMultipart("related");

			// Contenido
			BodyPart messageBodyPart = new MimeBodyPart();
		   /*messageBodyPart.setText(contenidoMensaje);
		   messageBodyPart.setHeader("Content-Type","text/plain; charset=\"utf-8\"");
		   messageBodyPart.setHeader("Content-Transfer-Encoding", "quoted-printable");*/
		   messageBodyPart.setContent(contenidoMensaje, "text/html; charset=\"UTF-8\""); 
			/*messageBodyPart.setContent(contenidoMensaje, 
												"UTF-8");*/ // contenidoMensaje = "<H1>Hello</H1><img src=\"cid:imagen_adjunta_id\">";
			multipart.addBodyPart(messageBodyPart);

			// Poner todo junto
			message.setContent(multipart);

			Transport.send(message);
		} catch (Exception ex) {
			throw new AppException("Error al enviar correo", ex);
		} finally {
			System.out.println("enviarHTML(S)");
			if (con.hayConexionAbierta()) {
				con.cierraConexionDB();
			}
		}
	}

}
