/**
 * 
 */
package com.app.cios.beans;

/**
 * @author Jhonatan Pacheco <jhonatanpachecohernandez@gmail.com>
 *
 */
public class LoginDataDTO {
	
	private String user;
	private int tipo;
	/**
	 * @param user
	 * @param tipo
	 */
	public LoginDataDTO(String user, int tipo) {
		super();
		this.user = user;
		this.tipo = tipo;
	}
	/**
	 * @return the user
	 */
	public String getUser() {
		return user;
	}
	/**
	 * @param user the user to set
	 */
	public void setUser(String user) {
		this.user = user;
	}
	/**
	 * @return the tipo
	 */
	public int getTipo() {
		return tipo;
	}
	/**
	 * @param tipo the tipo to set
	 */
	public void setTipo(int tipo) {
		this.tipo = tipo;
	}
	
	

}
