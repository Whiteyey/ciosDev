/**
 * 
 */
package com.app.cios.web.controllers;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.app.cios.beans.ElementosDTO;
import com.app.cios.beans.ResponseDTO;
import com.app.cios.beans.ResquestDTO;
import com.app.cios.beans.SesUsuarioCiosDTO;
import com.app.cios.utilerias.Registros;
import com.app.cios.web.services.ElementosQueries;

/**
 * 
 * @author Jhonatan Pacheco <jhonatanpachecohernandez@gmail.com>
 *
 */
@Controller
public class ElementosController {

	ElementosQueries elementosQueries;
	
	@RequestMapping(value = "/elementos", method = RequestMethod.GET)
	public String mainPage(ModelMap model,HttpServletRequest request) {
		
		ModelAndView aux= com.app.cios.utilerias.LoginUtil.isValidLogin(request);
		if(aux!=null){
			return "redirect:/";
		}
		
		HttpSession session = request.getSession();
		SesUsuarioCiosDTO u = (SesUsuarioCiosDTO) session.getAttribute("sesUsuario");
		
		model.addAttribute("message", "Pantalla de elementos");
		model.addAttribute("title", "Elementos");
		model.addAttribute("user", u.getNombreCompleto());
		model.addAttribute("addNew", "/elementos/add");
		return "elementos/elementos";

	}

	@RequestMapping(value="elementos/addNewElement", method = RequestMethod.GET)
	public ModelAndView add(HttpServletRequest request){
		ModelAndView  model = new ModelAndView ();
		ModelAndView aux= com.app.cios.utilerias.LoginUtil.isValidLogin(request);

		if(aux!=null){
			return aux;
		}
		
		HttpSession session = request.getSession();

		SesUsuarioCiosDTO u = (SesUsuarioCiosDTO) session.getAttribute("sesUsuario");

		model.addObject("title", "Nuevo Elemento");
		model.addObject("user", u.getNombreCompleto());
		model.setViewName("elementos/nuevoElementoExt");
		return model;
	}


	@RequestMapping(value="elementos/asignar", method = RequestMethod.GET)
	public ModelAndView assign(HttpServletRequest request){
		ModelAndView  model = new ModelAndView ();
		ModelAndView aux= com.app.cios.utilerias.LoginUtil.isValidLogin(request);

		if(aux!=null){
			return aux;
		}
		
		HttpSession session = request.getSession();
		SesUsuarioCiosDTO u = (SesUsuarioCiosDTO) session.getAttribute("sesUsuario");

		/*parte para buscar al elemento*/
		ElementosQueries mQueries = new ElementosQueries();
		Registros registros = mQueries.getRegistrosElements(
				request.getQueryString().substring(3, request.getQueryString().length()));
		ElementosDTO data = null;

		while (registros.next()) {
			data = new ElementosDTO(Integer.parseInt(registros.getString("ID_ELEMENTO")),
					registros.getString("NOMBRE_COMPLETO"), registros.getString("TIPO"),
					registros.getString("ESTATUS"));
		}
		
		/*asigna los datos recuperados*/
		model.addObject("name", data.getNombre());
		model.addObject("key", data.getId());
		model.addObject("type", data.getTipo());
		model.addObject("status", data.getEstatus());

		model.addObject("title", "Asignar elemento");
		model.addObject("user", u.getNombreCompleto());
		model.setViewName("elementos/asignarElemento");
		return model;
	}
	
	@RequestMapping(value="/addElement", method = RequestMethod.POST)
	@ResponseBody
	public ResponseDTO addElement(@RequestBody ElementosDTO element) throws ParseException {
		elementosQueries = new ElementosQueries();
		return elementosQueries.addElement(element);
	}
	
	@RequestMapping(value="/updateElement", method = RequestMethod.POST)
	@ResponseBody
	public ResponseDTO updateElement(@RequestBody ElementosDTO element) throws ParseException {
		elementosQueries = new ElementosQueries();
		return elementosQueries.updateElement(element);
	}
	
	@RequestMapping(value = "/elementos/elementosDataGuards", method = RequestMethod.POST)
	public @ResponseBody ResponseDTO gestionData(HttpServletRequest request) {

		ElementosQueries mQueries = new ElementosQueries();
		
		Registros registros = mQueries.getRegistrosElementsGuards();
		
		List<ElementosDTO> data = new ArrayList<>();

		while (registros.next()) {

			Registros registrosRate = mQueries.getElementRate(Integer.parseInt(registros.getString("ID_ELEMENTO")));
			int rate = 0;
			String rate_s = "-";
			while (registrosRate.next()) {
				rate += Integer.parseInt(registrosRate.getString("RATE"));
			}
			if(registrosRate.getNumeroRegistros() > 0){
				rate_s = "" + (rate/registrosRate.getNumeroRegistros());
			}
			data.add(new ElementosDTO(Integer.parseInt(registros.getString("ID_ELEMENTO")),
					registros.getString("NOMBRE_COMPLETO"), registros.getString("TIPO"), rate_s
					));
		}
		return new ResponseDTO("elementosDataGuards", true, data);
	}

	@RequestMapping(value = "/elementos/elementosDataScorts", method = RequestMethod.POST)
	public @ResponseBody ResponseDTO gestionDataScorts(HttpServletRequest request) {

		ElementosQueries mQueries = new ElementosQueries();
		
		Registros registros = mQueries.getRegistrosElementsScorts();
		
		List<ElementosDTO> data = new ArrayList<>();

		while (registros.next()) {

			Registros registrosRate = mQueries.getElementRate(Integer.parseInt(registros.getString("ID_ELEMENTO")));
			int rate = 0;
			String rate_s = "-";
			while (registrosRate.next()) {
				rate += Integer.parseInt(registrosRate.getString("RATE"));
			}
			if(registrosRate.getNumeroRegistros() > 0){
				rate_s = "" + (rate/registrosRate.getNumeroRegistros());
			}
			data.add(new ElementosDTO(Integer.parseInt(registros.getString("ID_ELEMENTO")),
					registros.getString("NOMBRE_COMPLETO"), registros.getString("TIPO"), rate_s
					));
		}
		return new ResponseDTO("elementosData", true, data);
	}

	@RequestMapping(value = "/elementos/elementosDataDrivers", method = RequestMethod.POST)
	public @ResponseBody ResponseDTO gestionDataDrivers(HttpServletRequest request) {

		ElementosQueries mQueries = new ElementosQueries();
		
		Registros registros = mQueries.getRegistrosElementsDrivers();
		
		List<ElementosDTO> data = new ArrayList<>();

		while (registros.next()) {

			Registros registrosRate = mQueries.getElementRate(Integer.parseInt(registros.getString("ID_ELEMENTO")));
			int rate = 0;
			String rate_s = "-";
			while (registrosRate.next()) {
				rate += Integer.parseInt(registrosRate.getString("RATE"));
			}
			if(registrosRate.getNumeroRegistros() > 0){
				rate_s = "" + (rate/registrosRate.getNumeroRegistros());
			}
			data.add(new ElementosDTO(Integer.parseInt(registros.getString("ID_ELEMENTO")),
					registros.getString("NOMBRE_COMPLETO"), registros.getString("TIPO"), rate_s
					));
		}
		return new ResponseDTO("elementosData", true, data);
	}
	
	@RequestMapping(value = "/getElementsByClient", method = RequestMethod.POST)
	public @ResponseBody ResponseDTO getElementsByClient(@RequestBody ResquestDTO data, 
			HttpServletRequest request) throws Exception{
		
		ElementosQueries mQueries = new ElementosQueries();
		Registros registros = mQueries.getElementByClientId(data.getUserId());
		List<ElementosDTO> dataList = new ArrayList<>();

		while (registros.next()) {
			dataList.add(new ElementosDTO(Integer.parseInt(registros.getString("ID_ELEMENTO")),
					registros.getString("NOMBRE_COMPLETO"), ""));
		}
		
			return new ResponseDTO("ElementsByClient", true, dataList);
			
	}
	
	@RequestMapping(value = "/getElementById", method = RequestMethod.POST)
	public @ResponseBody ResponseDTO getElementById(@RequestBody ResquestDTO data, 
			HttpServletRequest request) throws Exception{
		
		ElementosQueries mQueries = new ElementosQueries();
		Registros registros = mQueries.getElementById(data.getUserId());
		List<ElementosDTO> dataList = new ArrayList<>();

		while (registros.next()) {
			dataList.add(new ElementosDTO(Integer.parseInt(registros.getString("ID_ELEMENTO")),
					registros.getString("NOMBRE_COMPLETO"), registros.getString("TURNO")));
		}
		
			return new ResponseDTO("ElementsByClient", true, dataList);
			
	}
	
	@RequestMapping(value="editarElemento", method = RequestMethod.GET)
	public ModelAndView editElement(HttpServletRequest request){
		ModelAndView  model = new ModelAndView ();
		ModelAndView aux= com.app.cios.utilerias.LoginUtil.isValidLogin(request);

		if(aux!=null){
			return aux;
		}
		
		HttpSession session = request.getSession();

		SesUsuarioCiosDTO u = (SesUsuarioCiosDTO) session.getAttribute("sesUsuario");

		/*parte para buscar al elemento*/
		ElementosQueries mQueries = new ElementosQueries();
		Registros registros = mQueries.getRegistrosCompleteElements(
				request.getQueryString().substring(3, request.getQueryString().length()));
		ElementosDTO data = null;

		while (registros.next()) {
			data = new ElementosDTO(Integer.parseInt(registros.getString("ID_ELEMENTO")),
					registros.getString("CLASIFICACION"), registros.getString("TIPO"),
					registros.getString("ESTATUS"), registros.getString("FECHA_ALTA"), registros.getString("FECHA_DOTACION"),
					registros.getString("NOMBRE"), registros.getString("APELLIDO_P"), registros.getString("APELLIDO_M"),
					registros.getString("IMSS"), registros.getString("DIRECCION"), registros.getString("TELEFONO"),
					registros.getString("NOMBRE_C"), registros.getString("DIRECCION_C"), registros.getString("TELEFONO_C"));
		}
		
		/*asigna los datos recuperados*/
		model.addObject("key", data.getId());
		model.addObject("classify", data.getClasificacion());
		model.addObject("status", data.getEstatus());
		model.addObject("alta", data.getAlta());
		model.addObject("dotacion", data.getDotacion());
		model.addObject("type", data.getTipo());

		model.addObject("name", data.getNombre());
		model.addObject("lastNameF", data.getApellidoP());
		model.addObject("lastNameM", data.getApellidoM());
		model.addObject("direction", data.getDireccion());
		model.addObject("phone", data.getTelefono());
		model.addObject("imss", data.getImss());

		model.addObject("nameC", data.getNombreContacto());
		model.addObject("directionC", data.getDireccionContacto());
		model.addObject("phoneC", data.getTelefonoContacto());
		
		model.addObject("title", "Editar elemento");
		model.addObject("user", u.getNombreCompleto());
		model.setViewName("elementos/editarElemento");
		return model;
	}

}

