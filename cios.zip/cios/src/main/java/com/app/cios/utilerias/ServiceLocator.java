package com.app.cios.utilerias;

import java.util.Collections;
import java.util.HashMap;

import java.util.Map;

import java.util.Properties;

import javax.naming.Context;

import javax.naming.InitialContext;

import javax.naming.NamingException;

import javax.sql.DataSource;

import org.apache.log4j.BasicConfigurator;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.PropertyConfigurator;

public class ServiceLocator {
	private Context initialContext;
	private Map<String, DataSource> cache;

	private static ServiceLocator serviceLocatorRef = null;

	/**
	 * Contructor privado de ServiceLocator.
	 */
	private ServiceLocator() {
		try {
			this.initialContext = new InitialContext();
			this.cache = 
							Collections.synchronizedMap(new HashMap<String, DataSource>());
			this.initLog4J();
		} catch (NamingException ex) {
			throw new AppException("Error al inicializar ServiceLocator", ex);
		}
	}


	/**
	 * Obtiene la instancia del ServiceLocator
	 */
	public static ServiceLocator getInstance() {
		if (serviceLocatorRef == null) {
			serviceLocatorRef = new ServiceLocator();
		}
		return ServiceLocator.serviceLocatorRef;
	}

	/**
	 * Obtiene el Datasource especificado
	 * @param dataSourceName nombre del Datasource
	 * @return DataSource
	 */
	public DataSource getDataSource(String dataSourceName) {

		DataSource datasource = null;

		try {
			if (this.cache.containsKey(dataSourceName)) {
				datasource = this.cache.get(dataSourceName);
			} else {
				datasource = (DataSource)initialContext.lookup(dataSourceName);
				this.cache.put(dataSourceName, datasource);
			}
			return datasource;
		} catch (NamingException ex) {
			throw new AppException("Error al obtener el DataSource", ex);
		}
	}


	/**
	 * Interfaz a Commons Logging. 
	 * Se emplea el Log de Commonns en lugar de usar directamente las clases del Log4J.
	 * Ya que commons logging puede ajustarse a diferentes esquemas de Log, ya sea
	 * Log4J, el est�ndar de JDK 1.4, o en caso de no estar disponible 
	 * ninguno de estos dos, utiliza un mecanismo simple.
	 * 
	 * Usar este m�todo para obtener la instancia de Log de una clase en particular
	 * 
	 * @param clase Intancia de Class. 
	 *              Debe ser la clase de la cual se desea escribir mensajes en el log
	 * @return intancia de Log (Commons Logging)
	 */
	public Log getLog(Class clase) {
		return LogFactory.getLog(clase);
	}

	public Log getLog(String clase) {
		return LogFactory.getLog(clase);
	}


	/**
	 * Realiza la carga del archivo de configuraci�n de log4j.
	 * El archivo de configuracion debe encontrarse dentro del
	 * classpath de la aplicacion para que sea encontrado.
	 *
	 */
	private void initLog4J() {
		try {
			Properties propLog4J = Comunes.loadParams("log4j");
			PropertyConfigurator.configure(propLog4J);
		} catch (Throwable t) {
			System.out.println("*** El archivo de configuracion log4j.properties no se encontro. Inicializando log4j con BasicConfigurator");
			BasicConfigurator.configure();
		}
	}

	/**
	 * Obtiene el InitialContext predeterminado de la aplicaci�n
	 * @return Contexto predeterminado de la aplicaci�n
	 */
	public Context getInitialContext() {
		return initialContext;
	}
}
