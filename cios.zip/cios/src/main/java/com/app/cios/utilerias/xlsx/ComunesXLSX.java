package com.app.cios.utilerias.xlsx;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.app.cios.utilerias.CreaArchivo;
import com.app.cios.utilerias.zip.ComunesZIP;
 
public class ComunesXLSX {
 	
	public static final String    XML_ENCODING = "UTF-8";
	
	private Writer 					xml;
   private int 						indiceRenglon;
   private boolean 					datosHojaInicializados;
   private HashMap 					estilos;
   private String 					directorioTemporal;
   private String[]					longitudesColumna;
   private StringBuffer				columnasCombinadas;
	private String                loginUsuario;
	private ArrayList          	listaHojas = new ArrayList();
   											/* 
   												En esta version, columnasCombinadas no esta pensada para manejar una cantidad 
   												gigantezca de registros, por lo que si as� se decidiera, habria que guardar
   												los datos de esta en un archivo temporal y luego copiar la informacion a la
   												hoja principal.
   											*/
   private int							cuentaColumnasCombinadas;
   private CreaArchivo				archivo;
   private String 					hoja;
   private int     					cuentaHojas;
 
	public ComunesXLSX( String directorioTemporal, HashMap estilos ){
		
		this.estilos						= estilos;	
		this.directorioTemporal			= directorioTemporal;
		 
		this.archivo 						= new CreaArchivo();
		this.cuentaHojas					= 0;
 
		this.datosHojaInicializados 	= false;
		this.columnasCombinadas			= new StringBuffer(256);
		this.cuentaColumnasCombinadas	= 0;
		 
	}
 
	public void setLongitudesColumna(String[] longitudesColumna){
		this.longitudesColumna = longitudesColumna;
	}
	
	public void flush()
		throws IOException {
		xml.flush();	
	}
	
	public Writer creaHoja() 
		throws Exception {
		
		cuentaHojas++;
		if( cuentaHojas > 10 ){
			throw new Exception("La versi�n actual no tiene soporte para agregar m�s de dos hoja.");
		}
		datosHojaInicializados = false;
		cuentaColumnasCombinadas = 0;
		hoja = "sheet_" + archivo.nombreArchivo()+".xml";
		xml  = new OutputStreamWriter(new FileOutputStream(directorioTemporal+hoja), XML_ENCODING );
		listaHojas.add(hoja);
		 
      xml.write(
      	"<?xml version=\"1.0\" encoding=\""+XML_ENCODING+"\"?>" +
         "<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">" 
      );
      
      return xml;
      
   }

   private void escribeLongitudesColumnas()
		throws IOException {
   	
   	if( longitudesColumna == null || longitudesColumna.length == 0 ) return;
   	
   	xml.write("<cols>");
   	for(int i=0,columna=1;i<longitudesColumna.length;i++,columna++){
   		xml.write("<col min=\"");xml.write(String.valueOf(columna));xml.write("\" max=\"");xml.write(String.valueOf(columna));xml.write("\" width=\"");
   		xml.write(longitudesColumna[i]);
   		xml.write("\" bestFit=\"1\" customWidth=\"1\"/>");
   	}
		xml.write("</cols>");
		
   }
 
   public void finalizaHoja() 
   	throws IOException {
   	if(!datosHojaInicializados){ 
   		escribeLongitudesColumnas();
   		xml.write("<sheetData>\n"); 
   		datosHojaInicializados = true;
   	}
      xml.write("</sheetData>");
      finalizaCombinacionColumnas();
      xml.write("</worksheet>");
		xml.flush();
		xml.close();
   }

   public String finalizaDocumento(String plantilla) 
   	throws Exception {
   	
   	List 		lista				= new ArrayList();
		
		for(int x=0; x<listaHojas.size();x++){
			HashMap 	updatedFile 	= new HashMap();
			updatedFile.put("NAME", "xl/worksheets/sheet"+String.valueOf(x+1)+".xml");
			updatedFile.put("PATH", directorioTemporal+listaHojas.get(x));
			lista.add(updatedFile);
		}
		
		String archivoXLSX = archivo.nombreArchivo()+".xlsx";
		ComunesZIP.updateFiles(plantilla, lista, directorioTemporal + ( this.loginUsuario != null?this.loginUsuario+".":"" ) + archivoXLSX );
		
		return archivoXLSX;
		
   }
   
   public void agregaRenglon(int rownum) 
   	throws IOException {
   	if(!datosHojaInicializados){
   		escribeLongitudesColumnas();
   		xml.write("<sheetData>\n"); 
   		datosHojaInicializados = true;
   	}
      xml.write("<row r=\""+(rownum+1)+"\">\n");
      this.indiceRenglon = rownum;
   }
 
   public void finalizaRenglon() 
   	throws IOException {
      xml.write("</row>\n");
   }

   public void agregaCelda(int indiceColumna, String valor, String estilo, int colspan ) 
   	throws Exception {
   		
      String   ref 				= getClaveReferencia(indiceRenglon, indiceColumna);
      String 	indiceEstilo	= (String) estilos.get(estilo);
      
      xml.write("<c r=\"");xml.write(ref);xml.write("\" t=\"inlineStr\"");
      if(indiceEstilo != null){ 
       	xml.write(" s=\"");xml.write(indiceEstilo);xml.write("\"");
      }
      xml.write(">");
      xml.write("<is><t>");escapaCaracteresEspeciales(valor);xml.write("</t></is>");
      xml.write("</c>");
      
      if(colspan>1){
      	combinaColumnas(indiceRenglon, indiceColumna, colspan);
      	// Agregar nodos fantasma
      	for(int i=1;i<colspan;i++){
      		ref = getClaveReferencia(indiceRenglon, indiceColumna+i);
      		xml.write("<c r=\"");xml.write(ref);xml.write("\" t=\"inlineStr\"");
      		if(indiceEstilo != null){ 
					xml.write(" s=\"");xml.write(indiceEstilo);xml.write("\"");
				}
      		xml.write(">");
      		xml.write("<is><t>");xml.write("");xml.write("</t></is>");
      		xml.write("</c>");
      	}
      }
      
   }
	
	public void agregaCelda(int indiceColumna, String valor, String estilo ) 
   	throws Exception {
      agregaCelda( indiceColumna,  valor, estilo, 1 );
   }

   public String getClaveReferencia(int indiceRenglon, int indiceColumna)
   	throws Exception {
   		
   	StringBuffer  	buffer 	= new StringBuffer();
   	int 				valorA  	= (int) 'A';
   	if( indiceColumna > 25 ){ // Solo rango A - Z
   		throw new Exception("No se como determinar la clave de la siguiente columna");
   	}

   	buffer.append((char) ( valorA + indiceColumna ));
   	buffer.append(String.valueOf(indiceRenglon+1));
   	return buffer.toString();
   	
   }
   
   private void combinaColumnas(int indiceRenglon, int indiceColumna, int colspan)
   	throws Exception {
   	
   	colspan = colspan - 1;

   	String inicio	= getClaveReferencia(indiceRenglon, indiceColumna);
   	String fin	   = getClaveReferencia(indiceRenglon, indiceColumna+colspan);
 
		columnasCombinadas.append("<mergeCell ref=\"");
		columnasCombinadas.append(inicio);columnasCombinadas.append(":");columnasCombinadas.append(fin);
		columnasCombinadas.append("\"/>");
		cuentaColumnasCombinadas++;
 
   }
   
   private void finalizaCombinacionColumnas()
		throws IOException {
   	if( cuentaColumnasCombinadas > 0 ){
   		xml.write("<mergeCells count=\"");xml.write(String.valueOf(cuentaColumnasCombinadas));xml.write("\">");
   			xml.write(columnasCombinadas.toString());
   		xml.write("</mergeCells>");
   	}
   }
   
   public void agregaCelda(int indiceColumna, String valor) 
     	throws Exception {
         agregaCelda(indiceColumna, valor, "", 1 );
   }
 
	
	public void escapaCaracteresEspeciales(String cadena)
		throws IOException {
 
		if( cadena == null || cadena.length() == 0){
			return;
		}
		
		for(int i=0;i<cadena.length();i++){
			char c = cadena.charAt(i);
			if(c == '<'){
				xml.write("&lt;");
			}else if(c == '>'){
				xml.write("&gt;");
			}else if(c == '"'){
				xml.write("&quot;");
			}else if(c == '&'){
				xml.write("&amp;");
			}else{
				xml.write(c);
			}
		}
 
	}
	
	public void setLoginUsuario(String strLogin){
		this.loginUsuario = strLogin;
	};
 
}