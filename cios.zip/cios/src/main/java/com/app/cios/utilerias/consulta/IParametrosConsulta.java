package com.app.cios.utilerias.consulta;

import java.util.List;

/**
 * Interface que se utiliza para facilitar la consulta a la base de datos, solicitando
 * al usuario, unicamente que defina los parametros de los queries.
 * 
 * @author jshernandez
 * @date 19/03/2014 04:42:39 p.m.
 */
public interface IParametrosConsulta {

	/**
	 * Este m�todo debe regresar un <tt>QueryBean</tt> con el que se obtienen los 
	 * identificadores unicos de los registros a mostrar en la consulta.
	 * Se deber� regresar <tt>null</tt> cuando el query no requiera de hacer uso de los
	 * indentificadores �nicos, como sucede en una consulta simple.
	 *
	 * @return <tt>QueryBean</tt> con el query armado en base a los parametros recibidos.
	 */
	QueryBean getQueryLlavesPrimarias();
	
	/**
	 * Este m�todo regresa un <tt>QueryBean</tt> con el que se obtienen los 
	 * datos a mostrar en la consulta basandose en los identificadores unicos 
	 * especificados en las lista de ids.
	 *
	 * @param ids Lista de los identificadoes unicos. El tama�o de la lista 
	 * 	recibida ser� de acuerdo a la configuraci�n de registros x p�gina,
	 *    Si la consulta se parametriza como simple en la clase <tt>Consulta</tt>, 
	 *    no se consultar�n llaves primarias, por lo que este parametro ser� enviado
	 *    con valor <tt>null</tt>.
	 *
	 * @return <tt>QueryBean</tt> con el query armado en base a los parametros recibidos.
	 */
	QueryBean getQueryContenido(List ids);
	
	/**
	 * Este m�todo debe regresa un query con el que se obtienen totales de la
	 * consulta. Se deber� regresar <tt>null</tt> cuando no se requiera mostrar totales.
	 *
	 * @return <tt>QueryBean</tt> con el query armado en base a los parametros recibidos.
	 */
	QueryBean getQueryTotales();
	
	/**
	 * Si regresa diferente de <tt>null</tt>, se concatenar� al identificador de los datos de la consulta guardados
	 * en sesi�n. Es conveniente regresar un valor cuando en una misma pantalla se emplea
	 * mas de una clase que implementa esta interfaz, de lo contrario habra colisi�n con los 
	 * valores guardados en los ID; como identificador lo comun, es usar el nombre de la clase:
	 * <tt>this.getClass().getName()</tt>
	 *
	 * @return String con el nombre asociado a la consulta.
	 */
	String getNameConsulta();
	
}
