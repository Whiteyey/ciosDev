package com.app.cios.ws.web;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.app.cios.beans.LoginDataDTO;
import com.app.cios.beans.ResponseDTO;
import com.app.cios.beans.SesUsuarioCiosDTO;
import com.app.cios.modulos.UsuariosDAO;
import com.app.cios.utilerias.AccesoDB;
import com.app.cios.utilerias.Registros;
import com.app.cios.utilerias.ServiceLocator;
import com.app.cios.utilerias.consulta.QueryBean;

@RestController
public class AuthWS {
	   Log log = ServiceLocator.getInstance().getLog(AuthWS.class);
	   
	   
    @RequestMapping(value = "/userAuthWs/", method = RequestMethod.POST)
	public @ResponseBody com.app.cios.beans.ResponseDTO userAuthWS(@RequestBody com.app.cios.beans.ResquestDTO data,
			HttpServletRequest request) throws Exception{
    	
    	
    	HttpSession httpSession = request.getSession(false);
		if (httpSession != null) {
			httpSession.invalidate();// invalida la session
		}
		httpSession = request.getSession(true); // Siempre que llegue a esta
												// pagina se genera una nueva
												// sesión
    	
    	
    	Registros reg = null;
    	
    	QueryBean qry = new QueryBean();
    	
    	qry.appendQueryString("SELECT user_name as USER, id_tipo_usuario AS TIPO, LOGIN FROM tbl_acceso where LOGIN = ? and password = md5(?)");
    	qry.appendCondition(data.getLogin());
    	qry.appendCondition(data.getPassword());
    	reg = AccesoDB.consultarDB(qry);
    	
    	boolean valido = false;
    	HashMap loginData = new HashMap<>();
    	LoginDataDTO login = null;
    	while(reg.next()){
    		valido = true;
    		loginData.put("clave", new String(reg.getString("user_name")));
    		loginData.put("login", new String(reg.getString("LOGIN")));
    		loginData.put("user-type", reg.getString("id_tipo_usuario"));
    		
    	}
    	UsuariosDAO user  = new UsuariosDAO();
    	Object sesUsuario = user.get(loginData);
    	loginData.put("sesUsuario", sesUsuario);
    	
    	httpSession.setAttribute("sesUsuario", (SesUsuarioCiosDTO)sesUsuario);
    	httpSession.setAttribute("sesLogin", loginData.get("login"));
		return new ResponseDTO("Login ", valido,loginData);
		
	}
    
   
    
    @RequestMapping(value = "/altaUsuarioWS/", method = RequestMethod.POST)
	public @ResponseBody com.app.cios.beans.ResponseDTO altaUsuarioWS(@RequestBody com.app.cios.beans.ResquestDTO data) throws Exception{
    	
    	AccesoDB con = new AccesoDB();
    	boolean todo_ok = false;
    	QueryBean qry = new QueryBean();
    	 
    	try {
    		con.conexionDB();
    		qry.appendQueryString("insert into tbl_empleados "
        			+ " (clave,apellido_paterno,apellido_materno,nombre,nombre_completo,clasificacion,id_estatus,fecha_alta,nss) "
        			+ " values(?,?,?,?,?,?,?,NOW(),?)");
    		qry.appendCondition(data.getClave());
    		qry.appendCondition(data.getApellidoPaterno());
    		qry.appendCondition(data.getApellidoMaterno());
    		qry.appendCondition(data.getNombre());
    		qry.appendCondition(data.getNombreCompleto());
    		qry.appendCondition(data.getClasificacion());
    		qry.appendCondition(data.getIdEstatus());
    		qry.appendCondition(data.getNss());
    		todo_ok = con.ejecutaUpdateDB(qry)!=0?true:false;
		} catch (Exception e) {
			log.error("Error al insertar un nuevo empleado");
		}finally {
			if(con.hayConexionAbierta()){
				con.terminaTransaccion(todo_ok);
				con.cierraConexionDB();
			}
		}
    	
    	return new ResponseDTO("altaUsuarioWS",todo_ok);
    	
    	
    	
    	
    	
    	
    	
    	
		
		
	}
	
}

