
package com.app.cios.web.controllers;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.app.cios.beans.SesUsuarioCiosDTO;

/**
 * 
 * @author Jhonatan Pacheco <jhonatanpachecohernandez@gmail.com>
 *
 */
@Controller
public class MainController {

	 @RequestMapping(value = "/logOutWS/", method = RequestMethod.GET)
	    public String userLogOutWS(ModelMap model,	HttpServletRequest request) {
	    	request.getSession().invalidate();

	    	ModelAndView aux= com.app.cios.utilerias.LoginUtil.isValidLogin(request);
			if(aux!=null){
				return "redirect:/";
			}
	    	return "/";
	    }
	/**
	 * Controlador para mostrar la pagina de login
	 * @author Jhonatan Pacheco <jhonatanpachecohernandez@gmail.com>
	 * 
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String indexPage(ModelMap model) {
		
		model.addAttribute("message", "Spring 3 MVC Hello World");
		return "auth/login";

	}
	/**
	 * @author Jhonatan Pacheco <jhonatanpachecohernandez@gmail.com>
	 * @param model
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/main", method = RequestMethod.GET)
	public String mainPage(ModelMap model,HttpServletRequest request) {

		ModelAndView aux= com.app.cios.utilerias.LoginUtil.isValidLogin(request);
		if(aux!=null){
//			model.addAttribute("title","DashBoard");
//			model.addAttribute("user", "Yey");
//			
//			return "main/index";
			return "redirect:/";
		}
		HttpSession session = request.getSession();

		SesUsuarioCiosDTO u = (SesUsuarioCiosDTO) session.getAttribute("sesUsuario");

		model.addAttribute("titlePage", "Main");
		model.addAttribute("title","DashBoard");
		model.addAttribute("user", u.getNombreCompleto());
		
		return "main/index";

	}
}
