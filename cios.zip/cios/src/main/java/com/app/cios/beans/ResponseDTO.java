/**
 * 
 */
package com.app.cios.beans;

import java.util.HashMap;
import java.util.List;

/**
 * @author Jhonatan Pacheco <jhonatanpachecohernandez@gmail.com>
 *
 */
public class ResponseDTO {

	private String mensaje;
	private boolean estatus;
	private List<?> data;
	private HashMap<String, ?> dataHash;
	
	/**
	 * Constructor basico de basicos
	 * */
	public ResponseDTO() {
		super();
	}
	
	/**
	 * Constructor basico para las respuestas que solo requieren true or false
	 * @author Jhonatan Pacheco <jhonatanpachecohernandez@gmail.com>
	 * @param mensaje <tt>String</tt> con el mesaje de respuesta
	 * @param estatus <tt>boolean</tt> estatus del la respuesta
	 */
	public ResponseDTO(String mensaje, boolean estatus) {
		super();
		this.mensaje = mensaje;
		this.estatus = estatus;
	}


	/**
	 * Constructor para cuando la respuesta requiere mas una lista de un determinado objeto
	 * @author Jhonatan Pacheco <jhonatanpachecohernandez@gmail.com>
	 * @param mensaje <tt>String</tt> con el mesaje de respuesta
	 * @param estatus <tt>boolean</tt> estatus del la respuesta
	 * @param data <tt>List</tt> lista de objetos del mismo tipo
	 */
	public ResponseDTO(String mensaje, boolean estatus, List<?> data) {
		super();
		this.mensaje = mensaje;
		this.estatus = estatus;
		this.data = data;
	}


	/**
	 * Constructor avanzado para cuando la respuesta requiere una serie de objetos 
	 * @author Jhonatan Pacheco <jhonatanpachecohernandez@gmail.com>
	 * @param mensaje <tt>String</tt> con el mesaje de respuesta
	 * @param estatus <tt>boolean</tt> estatus del la respuesta
	 * @param dataHash
	 */
	public ResponseDTO(String mensaje, boolean estatus, HashMap<String, ?> dataHash) {
		super();
		this.mensaje = mensaje;
		this.estatus = estatus;
		this.dataHash = dataHash;
	}


	/**
	 * @return the mensaje
	 */
	public String getMensaje() {
		return mensaje;
	}


	/**
	 * @param mensaje the mensaje to set
	 */
	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}


	/**
	 * @return the estatus
	 */
	public boolean isEstatus() {
		return estatus;
	}


	/**
	 * @param estatus the estatus to set
	 */
	public void setEstatus(boolean estatus) {
		this.estatus = estatus;
	}


	/**
	 * @return the data
	 */
	public List<?> getData() {
		return data;
	}


	/**
	 * @param data the data to set
	 */
	public void setData(List<?> data) {
		this.data = data;
	}


	/**
	 * @return the dataHash
	 */
	public HashMap<String, ?> getDataHash() {
		return dataHash;
	}


	/**
	 * @param dataHash the dataHash to set
	 */
	public void setDataHash(HashMap<String, ?> dataHash) {
		this.dataHash = dataHash;
	}
	

}
