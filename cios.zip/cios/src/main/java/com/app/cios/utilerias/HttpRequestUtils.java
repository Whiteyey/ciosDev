package com.app.cios.utilerias;

import java.io.File;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.HashMap;
import java.util.List;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.app.cios.utilerias.ServiceLocator;
import com.app.cios.utilerias.AppException;

import com.app.cios.utilerias.archivo.ArchivoBean;

import org.apache.commons.fileupload.FileUploadBase.SizeLimitExceededException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.logging.Log;


/**
 * Utilerias para el manejo de parametros que se env�an en el request ( <tt>HttServletRequest</tt> ).
 *
 * @author gperez
 *
 * @author jshernandez ( modific� )
 * @since  30/04/2014 11:18:31 a.m.
 *
 */
public class HttpRequestUtils {

	// Variable para enviar mensajes al log.	
	private static final Log log = ServiceLocator.getInstance().getLog(HttpRequestUtils.class);
	
	public HttpRequestUtils() { }
	
	// ATRIBUTOS
	
	private String  	directorioTemporal;
	private String 	loginUsuario;
	private long 		maxFileSize = 83886080L; // 80MB
	private String 	directorioRaiz;

	// SETTERS / GETTERS
	
	public void setDirectorioTemporal(String directorioTemporal) {
		this.directorioTemporal = directorioTemporal;
	}

	public String getDirectorioTemporal() {
		return directorioTemporal;
	}

	public void setLoginUsuario(String loginUsuario) {
		this.loginUsuario = loginUsuario;
	}

	public String getLoginUsuario() {
		return loginUsuario;
	}

	public void setMaxFileSize(long setMaxFileSize) {
		this.maxFileSize = setMaxFileSize;
	}

	public long getMaxFileSize() {
		return maxFileSize;
	}

	public void setDirectorioRaiz(String directorioRaiz) {
		this.directorioRaiz = directorioRaiz;
	}

	public String getDirectorioRaiz() {
		return directorioRaiz;
	}
	
	// LEER PARAMETROS

	/**
	 * Determina si la petici�n se envi� con codificaci�n "multipart/form-data".
	 *
	 * @param request Objeto <tt>HttpServletRequest</tt> con la petici�n a validar.
	 *
	 * @return <tt>true</tt> si la codificaci�n es "multipart/form-data" y <tt>false</tt> en caso contrario.
	 *
	 * @author jshernandez
	 * @since 08/05/2014 06:27:52 p.m.
	 *
	 */
	 public static boolean isMultipartPost( HttpServletRequest request){

		 if (
			 request.getContentType() != null 
			 	&& 
			 request.getContentType().toLowerCase().indexOf("multipart/form-data") > -1 
		 ){
		 	return true;
		 }
						
		 return false;
		
	 }
	
	/**
	 * Lee los par�metros del <tt>HttpServletRequest</tt> cuando han sido enviados en modo <tt>multipart/form-data</tt>,
	 * como es el caso cuando se suben archivos. Todos los archivos recibidos se devolver�n como objetos de tipo
	 * <tt>ArchivoBean</tt>, con el atributo <tt>tituloArchivo</tt> inicializado con el nombre del archivo original 
	 * y con el atributo <tt>rutaAbsoluta</tt> inicializado con la ruta f�sica absoluta del archivo(por conflictos
	 * con algunos sistemas se archivos el nombre asignado al archivo ser� en base a una cadena aleatoria).<br>
	 * Ejemplo de Uso:<br>
	 * <pre>
	 * <code>
	 *    HttpRequestUtils requestUtils = new HttpRequestUtils();
	 *    requestUtils.setDirectorioRaiz(appDirectorioPublicacion); // Ruta f�sica del web context root
	 *    requestUtils.setDirectorioTemporal("00tmp/07proyecto/");
	 *    requestUtils.setLoginUsuario(loginUsuario);
	 *    requestUtils.setMaxFileSize(41943040); // 40 MB, No es obligatorio especificar esta propiedad ya que es un l�mite global m�ximo y
	 *                                           // por default son 80MB; para validar el tama�o de un archivo, usar la clase Validaciones.
	 *    HashMap parameters = requestUtils.getMultipartPostParameters(request);
	 *    // Leer parametro "Normal"
	 *    String      claveProyecto = (parameters.get("claveProyecto") == null)?""           :(String)      parameters.get("claveProyecto");
	 *    ArchivoBean archivo       = (parameters.get("archivo")       == null)?""           :(ArchivoBean) parameters.get("archivo");
	 *    // En caso de que un parametro este repetido, todos los valores de este se guardar�n en un <tt>String[]</tt>
	 *    String[]		claves		  = (parameters.get("claves")        == null)?new String[0]:(String[])    parameters.get("claves");
	 * </code>
	 * </pre>
	 *
	 * @throws AppException
	 *
	 * @param request <tt>HttpServletRequest</tt> con los parametros a extraer.
	 *
	 * @return <tt>HashMap</tt> con cada uno de los par�metros enviados.
	 *
	 */
	public HashMap getMultipartPostParameters(HttpServletRequest request)
		throws AppException {
			
		HashMap parameters = new HashMap();
		
		try {
							
			// Obtener ruta del directorio temporal
			String rutaDirectorioTemporal = getRutaDirectorioTemporal();
			
			// Create a factory for disk-based file items
			DiskFileItemFactory 	factory 			= new DiskFileItemFactory(DiskFileItemFactory.DEFAULT_SIZE_THRESHOLD, new File( rutaDirectorioTemporal ) );
			
			// Create a new file upload handler
			ServletFileUpload 	upload 			= new ServletFileUpload(factory);
			List<FileItem> 		fileItemList	= null;
			try {
			
				// Definir el tama�o m�ximo que pueden tener los archivos
				upload.setSizeMax(this.maxFileSize);
				// Parsear request
				fileItemList = upload.parseRequest(request);
				
			} catch(Throwable t) {

				log.error("getParameters(Exception): Cargar en memoria o disco el contenido del archivo");
				t.printStackTrace();
				
				if( t instanceof SizeLimitExceededException  ) {
					throw new AppException("Fall� la lectura de par�metros desde el HttpServletRequest. Al menos uno de los archivos excede el l�mite m�ximo permitido, que es de " + ( this.maxFileSize / 1048576 ) + " MB.");
				} else {
					throw new AppException("Fall� la lectura de par�metros desde el HttpServletRequest. " + t.getMessage() ); 
				}
					
			}
			            			
         // Variables Auxiliares
         StringBuffer rutaAbsolutaArchivo	= new StringBuffer(128);
         
			// Inicializar Bean
			for(FileItem fileItem: fileItemList){
				
				 // Es un campo de la forma
				 if(        fileItem.isFormField()  ){

					 String nombreCampo = fileItem.getFieldName();
					 String valorCampo  = fileItem.getString();
					
					 // Agregar par�metro	
					 if( parameters.containsKey(nombreCampo) ){
					 	 
					 	 Object value = parameters.get(nombreCampo);
					 	 if( value instanceof List ){
					 	 	 List valorCampoLista = (List) parameters.get(nombreCampo);
					 	 	 valorCampoLista.add(valorCampo);
					 	 } else {
					 	 	 List<String> valorCampoLista = new ArrayList<String>();
					 	 	 valorCampoLista.add(( String) parameters.get(nombreCampo));
					 	 	 valorCampoLista.add(valorCampo);
					 	 	 parameters.put(nombreCampo,valorCampoLista);
					 	 }
					 	 
					 } else {
					 	 
					 	 parameters.put(nombreCampo,valorCampo);
					 	 
					 }
					 
				 // Se trata de un archivo
				 } else if( !fileItem.isFormField() ){

				 	 String 	nombreCampo 				= fileItem.getFieldName();
					 String 	nombreOriginalArchivo	= fileItem.getName();
					 
					 // Verificar que no se haya enviado un archivo vac�o
					 if( Validaciones.esVacio(nombreOriginalArchivo) && fileItem.getSize() == 0 ){
				 	 	  // A�adir archivo a la lista de par�metros
				 	 	  parameters.put(nombreCampo,null);
				 	 	  continue;
				 	 }
				 	 
					 String 	extensionArchivo			= getExtensionArchivo(nombreOriginalArchivo);
					 rutaAbsolutaArchivo.setLength(0);
					 
					 // Guardar Archivo en Disco
					 try {
				 
					   // Generar Ruta Absoluta del Archivo
						rutaAbsolutaArchivo.append( rutaDirectorioTemporal );
						if( !Validaciones.esVacio( this.loginUsuario ) ){
							rutaAbsolutaArchivo.append( this.loginUsuario );
							rutaAbsolutaArchivo.append( "." );
						}
						// Generar Nombre aleatorio del Archivo, que pueda ser guardado en el sistema de archivos
						rutaAbsolutaArchivo.append( Comunes.cadenaAleatoria(16) );
						// Agregar extension
						rutaAbsolutaArchivo.append( extensionArchivo );

						// Guardar Archivo en Disco
						File uploadedFile	= new File( rutaAbsolutaArchivo.toString() );
						fileItem.write(uploadedFile);
						
					 } catch(Throwable e) {
						
						log.error("CargaPlantilla.subirArchivo(Exception): Guardar Archivo en Disco");
						e.printStackTrace();
						throw new AppException("Fall� la lectura de par�metros desde el HttpServletRequest. " + e.getMessage() ); 
						
					 }

					 // Agregar archivo adjunto a la lista
					 ArchivoBean archivo  = new ArchivoBean();
					 archivo.setTituloArchivo(nombreOriginalArchivo);
					 archivo.setRutaAbsoluta(rutaAbsolutaArchivo.toString());

					 // A�adir archivo a la lista de par�metros
					 parameters.put(nombreCampo,archivo);

				 }
				 
			}
			
			// Convertir las listas en String[]
         Iterator iterator = parameters.entrySet().iterator();
         while( iterator.hasNext() ){

         	Map.Entry       entry           = (Map.Entry) iterator.next();
         	String          parameter       = (String) entry.getKey();
         	Object          value           = entry.getValue();
         	if( value instanceof List ){
         		List<String>  valueList 	  = (List<String>) value;
         		String[] 	 stringArray 	  = valueList.toArray(new String[valueList.size()]);
         		parameters.put(parameter,stringArray);
         	}
         
         }

                                        
		} catch(AppException a) {
			
			log.error("getMultipartPostParameters(Exception)");
			log.error("getMultipartPostParameters.request = <" + request+ ">");
			a.printStackTrace();
			
			throw a;
			
		} catch(Exception e) {
			
			log.error("getMultipartPostParameters(Exception)");
			log.error("getMultipartPostParameters.request = <" + request+ ">");
			e.printStackTrace();
			
			throw new AppException("Fall� la lectura de par�metros desde el HttpServletRequest. " + e.getMessage() );
			
		}
		
		return parameters;
		
	}
	
	/**
	 * Lee los par�metros del <tt>HttpServletRequest</tt> cuando no hayan sido enviados en modo <tt>multipart/form-data</tt>,
	 * como es el caso cuando no se requiere subir archivos. Si el par�metro no existe, se regresar� <tt>null</tt>.
	 * Ejemplo de Uso:<br>
	 * <pre>
	 * <code>
	 *    HttpRequestUtils requestUtils = new HttpRequestUtils();
	 *    HashMap parameters = requestUtils.getParameters(request);
	 *    // Leer parametro "Normal"
	 *    String      claveProyecto = (parameters.get("claveProyecto") == null)?""           :(String)      parameters.get("claveProyecto");
	 *    // En caso de que un parametro este repetido, todos los valores de este se guardar�n en un <tt>String[]</tt>
	 *    String[]		claves		  = (parameters.get("claves")        == null)?new String[0]:(String[])    parameters.get("claves");
	 * </code>
	 * </pre>
	 *
	 * @throws AppException
	 *
	 * @param request <tt>HttpServletRequest</tt> con los parametros a extraer.
	 *
	 * @return <tt>HashMap</tt> con cada uno de los par�metros enviados.
	 *
	 */
	public HashMap getParameters(HttpServletRequest request)
		throws AppException {
			
		HashMap parameters = new HashMap();
		
		try {
			
			Enumeration paramNames = request.getParameterNames();
			while(paramNames.hasMoreElements()) {
				
				String 	paramName 	= (String)paramNames.nextElement();
				String[] paramValues = request.getParameterValues(paramName);
				if (paramValues.length == 1) { 
					parameters.put(paramName,paramValues[0]);
				} else {
					parameters.put(paramName,paramValues); 
				} 
				
			 }
       			
		} catch(Exception e) {
			
			log.error("getParameters(Exception)");
			log.error("getParameters.request = <" + request+ ">");
			e.printStackTrace();
			
			throw new AppException("Fall� la lectura de par�metros desde el HttpServletRequest. " + e.getMessage() );
			
		}
		
		return parameters;
		
	}
   
	// IMPRIMIR TODOS LOS PARAMETROS EN EL REQUEST
	
	/**
	 * Imprime en consola todos los parametros del request, siempre y cuando NO HAYAN SIDO ENVIADOS en 
	 * modo: <tt>multipart/form-data</tt>.
	 *
	 * @param HttpServletRequest con los parametros a extraer.
	 *
	 */
	public static void doPrintRequestParameters(HttpServletRequest request){
		
      Enumeration paramNames = request.getParameterNames();
      while(paramNames.hasMoreElements()) {
      	
         String 	paramName 	= (String)paramNames.nextElement();
         String[] paramValues = request.getParameterValues(paramName);
         if (paramValues.length == 1) { 
           String paramValue = paramValues[0];   
           log.info("doPrintRequestParameters." + paramName + " = <"+paramValue+">");
         } else {
           for(int i=0; i<paramValues.length; i++) {
           	  log.info("doPrintRequestParameters." + paramName + "["+i+"] = <"+ paramValues[i] + ">");
           } 
         } 
         
       }
       
   }
   
  	// METODOS AUXILIARES
	
	public String getRutaDirectorioTemporal(){
		return this.directorioRaiz + this.directorioTemporal;
	}
	
	private String getExtensionArchivo(String nombreArchivo){
		
		String extension = "";
				
		// Determinar extension del archivo
		int ultimoPunto = nombreArchivo != null ? nombreArchivo.lastIndexOf('.') : -1;
		if( ultimoPunto != -1 ){
			extension = nombreArchivo.substring(ultimoPunto).toLowerCase();
		}
		
		// Verificar que la extension sea v�lida
		if(        extension.lastIndexOf("/")  != -1 ){
			extension = "";
		} else if( extension.lastIndexOf("\\") != -1 ){
			extension = "";
		}
		
		return extension;
		
	}
	
}
