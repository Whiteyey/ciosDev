package com.app.cios.web.services;

import com.app.cios.beans.MensajeDTO;
import com.app.cios.beans.ReporteDTO;
import com.app.cios.beans.ResponseDTO;
import com.app.cios.utilerias.AccesoDB;
import com.app.cios.utilerias.Registros;
import com.app.cios.utilerias.consulta.QueryBean;

public class ReportesQueries {
	
	public ResponseDTO sendReport(ReporteDTO json) {
		//se obtienen los parametros
		String supervisor = json.getSupervisor();
		String client = json.getClient();
		String type = json.getType();
		String comments = json.getComments();
		String date = json.getDate();
		
		//se crea el query y la conexion
		QueryBean masterQuery = new QueryBean();
		AccesoDB con = new AccesoDB();
		boolean bandera = false;
		
		try {
			con.conexionDB();
			masterQuery.appendQueryString(
					"INSERT INTO tbl_reportes "
							+ "(SUPERVISOR, CLIENTE, TIPO, COMENTARIOS, FECHA) "
							+ "VALUES (?, ?, ?, ?, ?)");
			masterQuery.appendCondition(supervisor);
			masterQuery.appendCondition(client);
			masterQuery.appendCondition(type);
			masterQuery.appendCondition(comments);
			masterQuery.appendCondition(date);

			bandera = con.ejecutaUpdateDB(masterQuery) == 1 ? true : false;
			
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseDTO("Error al crear reporte",bandera);

		} finally {
			if (con.hayConexionAbierta()) {
				con.terminaTransaccion(bandera);
				con.cierraConexionDB();
			}
		}
		return new ResponseDTO("Reporte enviado",bandera);
	}
	
	public Registros getRegistrosReports(){
		//se crea el query y la conexion
		QueryBean masterQuery = new QueryBean();

		masterQuery.appendQueryString(
				"SELECT ID_REPORTE, SUPERVISOR, CLIENTE, "
				+ "TIPO, COMENTARIOS, FECHA FROM tbl_reportes");
		Registros registro = null;
		
		try {
			registro = AccesoDB.consultarDB(masterQuery);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error :: " + e.getMessage());

		}
		
		return registro;
	}

	
	public ResponseDTO deleteReport(ReporteDTO json) {
		//se obtienen los parametros
		int id = json.getId();
		
		//se crea el query y la conexion
		QueryBean masterQuery = new QueryBean();
		AccesoDB con = new AccesoDB();
		boolean bandera = false;
		
		try {
			con.conexionDB();
			masterQuery.appendQueryString(
					"DELETE FROM tbl_reportes WHERE ID_REPORTE = ?");
			masterQuery.appendCondition(id);

			bandera = con.ejecutaUpdateDB(masterQuery) == 1 ? true : false;
			
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseDTO("Error al borrar reporte",bandera);

		} finally {
			if (con.hayConexionAbierta()) {
				con.terminaTransaccion(bandera);
				con.cierraConexionDB();
			}
		}
		return new ResponseDTO("Reporte borrado",bandera);
	}
}
