package com.app.cios.web.services;

import com.app.cios.beans.AssistanceDTO;
import com.app.cios.beans.ClientesDTO;
import com.app.cios.beans.ResponseDTO;
import com.app.cios.utilerias.AccesoDB;
import com.app.cios.utilerias.Registros;
import com.app.cios.utilerias.consulta.QueryBean;

public class ClientesQueries {
	
	public ResponseDTO addClient(ClientesDTO json) {
		//se obtienen los parametros
		String name = json.getNombre();
		String phone = json.getTelefono();
		String email = json.getCorreoElectronico();
		String giro = json.getGiro();
		String director = json.getDirector();
		String direction = json.getDireccion();
		String rfc = json.getRfc();
		String ra = json.getRa();
		
		String img1 = json.getLogoA();
		String img2 = json.getLogoB();
		String img3 = json.getLogoC();
		
		//se crea el query y la conexion
		QueryBean masterQuery = new QueryBean();
		AccesoDB con = new AccesoDB();
		boolean bandera = false;
		
		try {
			con.conexionDB();
			masterQuery.appendQueryString(
					"INSERT INTO tbl_clientes "
							+ "(NOMBRE, TELEFONO, CORREO_ELECTRONICO, GIRO, "
							+ "DIRECTOR, DIRECCION, RFC, RAZON, "
							+ "LOGO_A, LOGO_B, LOGO_C) "
							+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			masterQuery.appendCondition(name);
			masterQuery.appendCondition(phone);
			masterQuery.appendCondition(email);
			masterQuery.appendCondition(giro);
			masterQuery.appendCondition(director);
			masterQuery.appendCondition(direction);
			masterQuery.appendCondition(rfc);
			masterQuery.appendCondition(ra);

			masterQuery.appendCondition(img1);
			masterQuery.appendCondition(img2);
			masterQuery.appendCondition(img3);

			bandera = con.ejecutaUpdateDB(masterQuery) == 1 ? true : false;
			
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseDTO("Error al crear cliente",bandera);

		} finally {
			if (con.hayConexionAbierta()) {
				con.terminaTransaccion(bandera);
				con.cierraConexionDB();
			}
		}
		return new ResponseDTO("Cliente creado",bandera);
	}	

	public Registros getClients() {
		//se crea el query y la conexion
		QueryBean masterQuery = new QueryBean();

		masterQuery.appendQueryString(
				"SELECT ID_CLIENTE, NOMBRE, TELEFONO, CORREO_ELECTRONICO, "
				+ "GIRO, DIRECTOR, DIRECCION, RFC, RAZON, "
				+ "LOGO_A, LOGO_B, LOGO_C FROM tbl_clientes");
		Registros registro = null;
		
		try {
			registro = AccesoDB.consultarDB(masterQuery);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error :: " + e.getMessage());

		}
		
		return registro;
	}

	/*obtiene la relacion de los clientes con sus elementos*/
	public Registros getRelClients() {
		//se crea el query y la conexion
		QueryBean masterQuery = new QueryBean();

		masterQuery.appendQueryString(
				"SELECT ID_CLIENTE, ID_ELEMENTO"
				+ " FROM tbl_rel_elemento_cliente");
		Registros registro = null;
		
		try {
			registro = AccesoDB.consultarDB(masterQuery);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error :: " + e.getMessage());

		}
		
		return registro;
	}
	
	public ResponseDTO updateRelElement(ClientesDTO json) {
		//se obtienen los parametros
		int idClient = json.getIdCliente();
		int idElement = json.getIdElement();
		String turn = json.getGiro();
		
		//se crea el query y la conexion
		QueryBean masterQuery = new QueryBean();
		AccesoDB con = new AccesoDB();
		boolean bandera = false;
		
		try {
			con.conexionDB();
			masterQuery.appendQueryString("INSERT INTO tbl_rel_elemento_cliente "
					+ "(ID_CLIENTE, ID_ELEMENTO, TURNO) VALUES (?, ?, ?) "
					+ "ON DUPLICATE KEY UPDATE "
					+ "ID_CLIENTE=?, ID_ELEMENTO=?, TURNO = ?");
			masterQuery.appendCondition(idClient);
			masterQuery.appendCondition(idElement);
			masterQuery.appendCondition(turn);
			masterQuery.appendCondition(idClient);
			masterQuery.appendCondition(idElement);
			masterQuery.appendCondition(turn);

			bandera = con.ejecutaUpdateDB(masterQuery) == 1 ? true : false;
			bandera=true;
			
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseDTO("Error al asignar elemento",bandera);

		}finally {
			if (con.hayConexionAbierta()) {
				con.terminaTransaccion(bandera);
				con.cierraConexionDB();
			}
		}
		return new ResponseDTO("Elemento asignado",bandera);
	}
	

	/*obtiene la lista de asistencia de un cliente*/
	public Registros getAssistanceList(int idClient) {
		//se crea el query y la conexion
		QueryBean masterQuery = new QueryBean();

		masterQuery.appendQueryString(
				"SELECT pd.NOMBRE_COMPLETO, asl.ID_ELEMENTO, asl.FECHA, asl.TURNO "
				+ "from tbl_personal_data pd, tbl_asistencia asl "
				+ "WHERE asl.ID_CLIENTE = ?");
		masterQuery.appendCondition(idClient);
		
		Registros registro = null;
		
		try {
			registro = AccesoDB.consultarDB(masterQuery);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error :: " + e.getMessage());

		}
		
		return registro;
	}
}
