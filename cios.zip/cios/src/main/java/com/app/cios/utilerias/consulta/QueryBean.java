package com.app.cios.utilerias.consulta;

import java.util.ArrayList;
import java.util.List;

public class QueryBean {

	private StringBuffer queryStringBuffer;
	private List	conditions;

	public QueryBean() {
		queryStringBuffer = new StringBuffer(64);
		conditions        = new ArrayList();
	}
	
	public String getQueryString() {
		return queryStringBuffer.toString();
	}

	public void setQueryString(String queryString) {
		queryStringBuffer.setLength(0);
		queryStringBuffer.append(queryString);
	}

	public void appendQueryString(String queryString) {
		queryStringBuffer.append(queryString);
	}
	
	public List getConditions() {
		return this.conditions;
	}

	public void setConditions(List conditions) {
		this.conditions = conditions;
	}
	
	public void appendCondition(Object condition) {
		this.conditions.add(condition);
	}
	
	public void appendCondition(int condition) {
		this.conditions.add(new Integer(condition));
	}
	
	public void appendCondition(long condition) {
		this.conditions.add(new Long(condition));
	}

	public void clearConditions(){
	   this.conditions.clear();
	}
	
	public void resetAll(){
		this.clearConditions();
		this.queryStringBuffer.setLength(0);
	}
}
