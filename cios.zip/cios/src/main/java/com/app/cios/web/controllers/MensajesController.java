/**
 * 
 */
package com.app.cios.web.controllers;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.app.cios.beans.MensajeDTO;
import com.app.cios.beans.ResponseDTO;
import com.app.cios.beans.SesUsuarioCiosDTO;
import com.app.cios.utilerias.Registros;
import com.app.cios.web.services.MensajesQueries;

/**
 * 
 * @author JR Alvarado <jr.alvaradogarcia@gmail.com>
 *
 */
@Controller
public class MensajesController {
	
	MensajesQueries mensajesQueries;
	
	@RequestMapping(value = "/mensajes", method = RequestMethod.GET)
	public String mainPage(ModelMap model,HttpServletRequest request) {

		ModelAndView aux= com.app.cios.utilerias.LoginUtil.isValidLogin(request);
		if(aux!=null){
			return "redirect:/";
		}
		HttpSession session = request.getSession();

		SesUsuarioCiosDTO u = (SesUsuarioCiosDTO) session.getAttribute("sesUsuario");

//		model.addAttribute("titlePage", "Main");
		model.addAttribute("title","Mensajes");
		model.addAttribute("user", u.getNombreCompleto());
		model.addAttribute("addNew", "/mensajes/addNewMessage");
		
		return "mensajes/mensajes";
	}

	@RequestMapping(value="mensajes/addNewMessage", method = RequestMethod.GET)
	public String add(ModelMap model,HttpServletRequest request) {

		ModelAndView aux= com.app.cios.utilerias.LoginUtil.isValidLogin(request);
		if(aux!=null){
			return "redirect:/";
		}
		
		HttpSession session = request.getSession();

		SesUsuarioCiosDTO u = (SesUsuarioCiosDTO) session.getAttribute("sesUsuario");

//		model.addAttribute("titlePage", "Main");
		model.addAttribute("title", "Nuevo Mensaje");
		model.addAttribute("user", u.getNombreCompleto());
		
		return "mensajes/nuevoMensaje";
	}

	@RequestMapping(value="/sendMessage", method = RequestMethod.POST)
	@ResponseBody
	public ResponseDTO sendMessage(@RequestBody MensajeDTO message) throws ParseException {
		mensajesQueries = new MensajesQueries();
		return mensajesQueries.sendMessage(message);
	}
	
	@RequestMapping(value="/deleteMessage", method = RequestMethod.POST)
	@ResponseBody
	public ResponseDTO deleteMessage(@RequestBody MensajeDTO message) throws ParseException {
		mensajesQueries = new MensajesQueries();
		return mensajesQueries.deleteMessage(message);
	}
	
	@RequestMapping(value = "mensajes/mensajesData", method = RequestMethod.POST)
	public @ResponseBody ResponseDTO gestionData(HttpServletRequest request) {

		MensajesQueries mQueries = new MensajesQueries();
		
		Registros registros = mQueries.getRegistrosMessages();
		
		List<MensajeDTO> data = new ArrayList<>();

		while (registros.next()) {
			data.add(new MensajeDTO(Integer.parseInt(registros.getString("ID_MENSAJE")),
					registros.getString("TITULO"),
					registros.getString("FECHA").substring(0, 10),
					registros.getString("FECHA").substring(11, 19),
					registros.getString("MENSAJE"),
					registros.getString("DESTINATARIOS")));
		}
		return new ResponseDTO("mensajesData", true, data);
	}
}

