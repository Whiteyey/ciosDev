package com.app.cios.utilerias.consulta;

import java.sql.ResultSet;

import java.util.HashMap;

import javax.servlet.http.HttpSession;

import com.app.cios.utilerias.AccesoDB;
import com.app.cios.utilerias.AppException;
import com.app.cios.utilerias.Registros;

import java.util.List;

import org.apache.commons.logging.Log;
import com.app.cios.utilerias.ServiceLocator;

/** 
 *
 * Clase que se utiliza en conjunto con las clases que implementan la interfaz <tt>IParametrosConsulta</tt>,
 * para agilizar las consultas a la Base de Datos. Se utiliza tanto en consultas que requieren paginacion
 * como aquellas que no lo necesitan.
 *
 * @author jshernandez
 * @date 19/03/2014 06:06:20 p.m.
 *
 */
public class Consulta {
		
	public static final int CONSULTA_SIMPLE   		= 101;
	public static final int CONSULTA_CON_PAGINACION = 102;
	
	//Variable para enviar mensajes al log.
	private final static Log log = ServiceLocator.getInstance().getLog(Consulta.class);
	
	public Consulta(IParametrosConsulta parametrosConsulta){
		
		this.parametrosConsulta = parametrosConsulta;
		
		String nameConsulta = parametrosConsulta.getNameConsulta();
		if( nameConsulta != null && !nameConsulta.matches("^\\s*$") ){
			this.paginadorLlaves 	= this.paginadorLlaves 	+ "_" + nameConsulta;
			this.paginadorTotales	= this.paginadorTotales + "_" + nameConsulta;
		}
	
		this.consultaNueva 		= false;
		this.tipoConsulta  		= Consulta.CONSULTA_SIMPLE;
		
		this.startInitialized 	= false;
		this.limitInitialized 	= false;
		
		this.sessionInitialized				= false;
		this.session							= null;
		this.sessionHashMapInitialized 	= false;
		this.sessionHashMap					= null;
		
	}
		
	/**
	 * Indica si el atributo start fue inicializado.
	 */
	private boolean startInitialized = false;
	
	/**
	 * Indica si el atributo limit fue inicializado.
	 */
	private boolean limitInitialized = false;
	
	/**
	 * Define el indice del primer registro que traer� la consulta de contenidos.
	 */
	private int start = 0;
	
	/**
	 * Define el n�mero de total registros que traer� la consulta de contenidos 
	 * ( registros por p�gina ).
	 */
	private int limit = 0;
	
	/**
	 *  Indica si se realizar� una consulta nueva, lo que implica que se vuelvan a generar 
	 *  las llaves primarias. Si la consulta es simple ( no usa llaves primarias ), el valor
	 *  de este campo es ignorado.
	 */
	private boolean consultaNueva = false;
	
	/**
	 * Indica el modo de consulta a realizar: Consulta.CONSULTA_SIMPLE y Consulta.CONSULTA_CON_PAGINACION,
	 * Requerido para mejorar la legibilidad de la consulta.
	 */
	private int tipoConsulta = Consulta.CONSULTA_SIMPLE;
	
	/**
	 * Objeto con los queries para realizar la consulta.
	 */
	private IParametrosConsulta parametrosConsulta;
	
	/**
	 * Establece el m�ximo n�mero de registros que regresar� la consulta
	 * De manera predeterminada se establece en 1000
	 */
	private int maximoNumeroRegistros 	= 1000;
		
	/**
	 * Variable interna para identificar de manera unica la ejecuci�n de un query y poder
	 * rastrear donde inicia y donde termina.
	 * Util para cuando hay varios queries de paginador ejecutandose
	 * simultaneamente.
	 */
	private final String idQuery    		= String.valueOf((new java.util.Date()).getTime());
	
	/**
	 * Nombre con el que se guardar� en sesi�n la "lista" de llaves primarias o identificadores
	 * unicos de los registros de la consulta.
	 */
	private String paginadorLlaves     	= "_cqhregextjs_ids";
	
	/**
	 * Nombre con el que se guardar� en sesi�n los totales de la consulta.
	 */
	private String paginadorTotales 		= "_cqhregextjs_totales";
	
	/**
	 * Nombre con el que se guardar� en sesi�n el numero total de registros de la consulta.
	 */
	private String paginadorNumero 		= "_cqhregextjs_numero";
	
	/**
	 * Nombre del objeto en sesion del usuario y que se usar� para guardar el resultado de la consulta.
	 * Esta variable en un futuro podr�a extenderse, para usar un HashMap y as� facilitar la consulta
	 * con procesos batch o simplemente no especificarse.
	 */
	private HttpSession session 				= null;

	/**
	 * Variable de uso interno que se pone en true cuando se ha inicializado el objeto que guarda
	 * los datos de la consulta, por ejemplo, cuando el usuario invoca el m�todo: <tt>setSession</tt>.
	 */
	private boolean	  sessionInitialized = false;
	
	/**
	 * Variable usada, cuando el atributo session no ha sido inicializado.
	 */
	private HashMap	  sessionHashMap		= null;
		
	/**
	 * Variable de uso interno que se pone en true cuando se ha inicializado el objeto que guarda
	 * los datos de la consulta, por ejemplo, cuando el usuario invoca el m�todo: <tt>setSessionHashMap</tt>.
	 */
	private boolean	  sessionHashMapInitialized = false;
	
	
	/**
	 * Devuelve el indice del primer registro que trae la consulta de contenido.
	 */
	public int getStart() {
		return start;
	}

	/**
	 * Define el indice del primer registro que trae la consulta de contenido.
	 */
	public void setStart( int start ) {
		this.startInitialized 	= true;
		this.start 					= start;
	}

	/**
	 * Devuelve el numero total de registros que trae la consulta de contenidos.
	 */
	public int  getLimit() {
		return limit;
	}

	/**
	 * Define el numero total de registros que trae la consulta de contenidos.
	 */
	public void setLimit( int limit) {
		this.limitInitialized 	= true;
		this.limit 					= limit;
	}

	/**
	 * Indica si se realizara una consulta nueva, lo que implica la generaci�n de nuevas llaves primarias.
	 * Si la interfaz <tt>IParametrosConsulta</tt>, no tiene definido el query de llaves primarias el
	 * valor de este atributo es ignorado.
	 */
	public void setConsultaNueva( boolean consultaNueva ){
		this.consultaNueva = consultaNueva;
	}
	
	/**
	 * Retorna el "estado" de la consulta que se est� realizando.
	 */
	public boolean isConsultaNueva(){
		return this.consultaNueva;
	}
	

	/** 
	 * Retorna el tipo de consulta que se est� realizando, por default se asume una consulta simple ( Consulta.CONSULTA_SIMPLE ).
	 */
	public int getTipoConsulta() {
		return tipoConsulta;
	}

	/** 
	 * Sirve para indicar el tipo de consulta a realizar, los valores posibles son: Consulta.CONSULTA_SIMPLE y 
	 * Consulta.CONSULTA_CON_PAGINACION.
	 */
	public void setTipoConsulta(int tipoConsulta) {
		this.tipoConsulta = tipoConsulta;
	}

		
	/**
	 * Obtiene el n�mero m�ximo de registros a presentar en una consulta 
	 * De manera predeterminada el valor es 1000 a menos que haya sido 
	 * ajustado mediante setMaximoNumeroRegistros(int)
	 * @return numero m�ximo de registros a regresar.
	 */
	public int getMaximoNumeroRegistros() {
		return this.maximoNumeroRegistros;
	}

	/**
	 * Establece el n�mero m�ximo de registros a presentar en una consulta 
	 * De manera predeterminada el valor es 1000 
	 * @param maximoNumeroRegistros M�ximo de registros a regresar.
	 */
	public void setMaximoNumeroRegistros(int maximoNumeroRegistros) {
		this.maximoNumeroRegistros = maximoNumeroRegistros;
	}
	
	/**
	 * Devuelve el objeto <tt>HttpSession</tt>, que se utilizar� para obtener y guardar los resultados
	 * la consulta de llaves primarias y de los totales. Si se especifica este atributo, no se podr� usar
	 * el atributo: SessionHashMap.
	 *
	 * @return Objeto <tt>HttpSession</tt> con la sesion del usuario que realiza la consulta.
	 */
	public HttpSession getSession() {
		return session;
	}

	/**
	 * Establece el objeto sesion <tt>HttpSession</tt>, que se utilizar� para obtener y guardar los resultados
	 * la consulta de llaves primarias y de los totales.
	 */
	public void setSession(HttpSession session) {
		this.sessionInitialized 			= true;
		this.session 							= session;
		this.sessionHashMapInitialized 	= false;
		this.sessionHashMap     			= null;
	}

	/**
	 * Devuelve el objeto <tt>HashMap</tt>, que se utilizar� para obtener y guardar los resultados
	 * la consulta de llaves primarias y de los totales. Si se especifica este atributo, no se podr� usar
	 * el atributo: Session.
	 *
	 * @return Objeto <tt>HttpSession</tt> con la sesion del usuario que realiza la consulta.
	 */
	public HashMap getSessionHashMap() {
		return sessionHashMap;
	}
	
	/**
	 * Establece el objeto sesion <tt>HashMap</tt>, que se utilizar� para obtener y guardar los resultados
	 * la consulta de llaves primarias y de los totales.
	 */
	public void setSessionHashMap(HashMap sessionHashMap) {
		this.sessionInitialized 			= false;
		this.session							= null;
		this.sessionHashMapInitialized 	= true;
		this.sessionHashMap     			= sessionHashMap;
	}

	/**
	 * Limpia los datos en sesion referente a la paginacion, para iniciar
	 * una nueva consulta.
	 */	
	public void cleanAtributosConsulta() {
		
		/*
		
			// Nota: este metodo queda pendiente de implementar, se requerir�a por ejemplo
			// para limpiar todas las variables de sesion correspondientes a la paginacion.
			// Esto se podr�a hacer en la inicializaci�n de alguna pantalla y as� evitar
			// "fuga" de memoria.
			
			if( this.session == null ) return;
		
			session.removeAttribute(this.paginadorLlaves);
			session.removeAttribute(this.paginadorTotales);
			
		*/
		
	}
	
	/**
	 * Guarda un atributo en session. En un futuro este metodo podr�a ser m�s gen�rico y usar otro tipo
	 * de objeto, facilitandose su uso en procesos batch.
	 *
	 * @param name <tt>String</tt> con el nombre del objeto a guardar.
	 * @param value <tt>Object</tt> con el valor del objeto a guardar.
	 */
	private void saveAttribute(String name, Object value){
		
		if( this.sessionInitialized ){
			this.session.setAttribute(name, value);
			return;
		} else if( this.sessionHashMapInitialized ){
			this.sessionHashMap.put(name, value);
		} else {
			throw new AppException("No se especific� el objeto donde se persistir�n los resultados de la consulta, para ello usar metodo: setSession o setSesssionHashMap.");	
		}
		
	}
	
	/**
	 * Regresa atributo guardado en session. En un futuro este metodo podr�a ser m�s gen�rico y usar otro tipo
	 * de objeto, facilitandose su uso en procesos batch.
	 *
	 * @param name <tt>String</tt> con el nombre del objeto guardado.
	 *
	 * @return Una clase <tt>Object</tt> con el valor del objeto guardado.
	 */
	private Object	getAttribute(String name){
		
		if( this.sessionInitialized ){
			return this.session.getAttribute(name);
		}
		
		return this.sessionHashMap.get(name);
		
	}

	/**
	 * Obtiene las llaves primarias de la informaci�n a consultar con base
	 * en los parametros (criterios) de busqueda especificados
	 *
	 * @throws AppException
	 *
	 * @return Objeto <tt>Registros</tt> con los valores de las llaves primarias � <tt>null</tt> 
	 *         si el query de llaves primarias no fue especificado.
	 */
	public Registros ejecutaQueryLlavesPrimarias() 
		throws AppException {
				
		Registros   llavesPrimarias	= null;
		AccesoDB 	con 					= new AccesoDB();
		
		log.info("Consulta.ejecutaQueryLlavesPrimarias():: pag= " + this.parametrosConsulta.getClass().getName() + " (" + this.idQuery + ")" );
		
		long tiempoInicial 	= 0L;
		long tiempoFinal 		= 0L;
		
		try {
			
			con.conexionDB();
			
			tiempoInicial 		= (new java.util.Date()).getTime();
			
			QueryBean qryGen	= this.parametrosConsulta.getQueryLlavesPrimarias();

			if( qryGen == null ){
				throw new AppException("El QueryBean regresado por el metodo getQueryLlavesPrimarias(), no puede ser nulo.");
			}

			llavesPrimarias = con.consultarDB(
				qryGen.getQueryString(), 			//QUERY DE LLAVES
				qryGen.getConditions(),				//VARIABLES BIND
				true,										//NO HACE DISTINCION DE TIPOS DE DATOS EN EL RESULTADO
				this.getMaximoNumeroRegistros()	//NUMERO MAXIMO DE REGISTROS A PRESENTAR EN LA CONSULTA
			);
						
			tiempoFinal 		= (new java.util.Date()).getTime();
			log.info("Consulta.ejecutaQueryLlavesPrimarias():: PKs. t=" + String.valueOf(tiempoFinal-tiempoInicial) + " ms. idQuery=(" + this.idQuery + ")" );
 		
		} catch (Exception e) {
			
			tiempoFinal 		= (new java.util.Date()).getTime();
			throw new AppException("Error al realizar consulta de llaves primarias", e);
			
		} finally {
			
			if (con.hayConexionAbierta()) {
				con.terminaTransaccion(true); // por las consultas que usen tablas remotas via dblink
				con.cierraConexionDB();
			}
			
			log.info("Consulta.ejecutaQueryLlavesPrimarias():: PKs. t=" + String.valueOf(tiempoFinal-tiempoInicial) + " ms. idQuery=(" + this.idQuery + ")" );

		}
		
		// Debug info: considerar que sucede con las llaves primarias cuando estas se encuentran en sesion
		
		return llavesPrimarias;
		
	}
	
	/**
	 * Obtiene los totales de la informaci�n a consultada con base
	 * en los parametros (criterios) de busqueda especificados
	 *
	 * @throws AppException
	 *
	 * @return Objeto <tt>Registros</tt> con los valores de los totales � 
	 *         <tt>null</tt> si el query de totales no fue especificado.
	 */
	public Registros ejecutaQueryTotales()
		throws AppException {
				
		Registros 	totales	= null;
		AccesoDB 	con 		= new AccesoDB();
		
		log.info("Consulta.ejecutaQueryTotales():: pag= " + this.parametrosConsulta.getClass().getName() + " (" + this.idQuery + ")" );
		
		long tiempoInicial = 0L;
		long tiempoFinal   = 0L;
		
		try {
			
			con.conexionDB();
			
			tiempoInicial 		 = (new java.util.Date()).getTime();
			
			QueryBean qryGen 	 = this.parametrosConsulta.getQueryTotales();
			
			if( qryGen == null ){
				throw new AppException("El QueryBean regresado por el metodo getQueryTotales(), no puede ser nulo.");	
			}
			
			totales = con.consultarDB(
				qryGen.getQueryString(), 			//QUERY DE TOTALES
				qryGen.getConditions(),				//VARIABLES BIND
				true										//NO HACE DISTINCION DE TIPOS DE DATOS EN EL RESULTADO
			);
			tiempoFinal = (new java.util.Date()).getTime();

		} catch (Exception e) {
			
			tiempoFinal = (new java.util.Date()).getTime();
			throw new AppException("Error al realizar consulta de totales", e);
			
		} finally {
			
			if (con.hayConexionAbierta()) {
				con.terminaTransaccion(true); //por las consultas que usen tablas remotas via dblink
				con.cierraConexionDB();
			}
			log.info("Consulta.ejecutaQueryTotales():: Totales t=" + String.valueOf(tiempoFinal-tiempoInicial) + " ms. idQuery=(" + this.idQuery + ")" );
			
		}
		
		// Debug info: considerar que sucede con los totales cuando estos se encuentran en sesion
		
		return totales;
		
	}
	
	/**
	 *
	 * Obtiene la lista de los Ids en turno para realizar la paginacion
	 * @throws AppException
	 *
	 * @param registros Objeto <tt>Regitros</tt> el cual ser� recortado.
	 * @param start �ndice a partir del cual se toman los registros
	 * @param limit N�mero de registros a obtener
	 *
	 * @return objeto <tt>Registros</tt> con los Ids en turno para ser usados por la paginacion.
	 *
	 */
	private Registros getSegmento( Registros registros, int start, int limit ) 
		throws AppException {
		
		Registros segmento = null;

		if( registros == null ){
			return segmento;
		}		
		
		//------------------- Validacion de parametros -------------------------
		try {
			if (this.start < 0 ) {
				throw new Exception("El parametro start debe ser mayor a 0");
			}
			if (this.limit < 1 ) {
				throw new Exception("El parametro limit debe ser mayor a 1");
			}
		} catch(Exception e) {
			throw new AppException("Error en los parametros recibidos", e);
		}
		//----------------------------------------------------------------------
		
		int indiceMaximo = registros.getNumeroRegistros();
		// Debug info: aqu� se podr�a agregar condici�n para cuando la consulta no tiene llaves primarias.
		if( registros.getNumeroRegistros() > start + limit ) {
			indiceMaximo = start + limit;
		}
		
		segmento = new Registros();
		for( int i = start; i<indiceMaximo; i++ ) {
			segmento.addDataRow( registros.getData(i) );
		}
		
		return segmento;
		
	}
	
	/**
	 * Obtiene la informacion a mostrar en la paginacion.
	 * IMPORTANTE!!!!: Es necesario que los alias de las columnas en la consulta
	 * no se repitan, ya que de lo contrario el objeto resultante eliminar� los
	 * campos repetidos.
	 *
	 * @throws AppException
	 * @return Objeto <tt>Registros</tt> con el contenido de la consulta.
	 */
	public Registros ejecutaQueryContenido(Registros llavesPrimarias)
		throws AppException {
		
		AccesoDB 	con  			= new AccesoDB();
		Registros 	contenido	= null;

		try {
			
			con.conexionDB();
			
			// Obtener lista de llaves primarias en caso que las haya
			Registros llavesPrimariasDelaPagina = getSegmento( llavesPrimarias, this.start, this.limit );
			List listaLlavesPrimarias				= llavesPrimariasDelaPagina == null?null:llavesPrimariasDelaPagina.getData();

			// Obtener query de consulta de contenido
			QueryBean qryGen 						= this.parametrosConsulta.getQueryContenido(listaLlavesPrimarias);
			
			if( qryGen == null ){
				throw new AppException("El QueryBean regresado por el metodo getQueryContenido(), no puede ser nulo.");
			}
			
			// Realizar consulta
			contenido = con.consultarDB(
				qryGen.getQueryString(), 	//QUERY DE CONTENIDO
				qryGen.getConditions(), 	//VARIABLES BIND
				true 								//NO HACE DISTINCION DE TIPOS DE DATOS EN EL RESULTADO
			);
			
			// En caso de que se trate de una consulta simple y se haya especificado un numero reducido de registros
			if( 
				this.tipoConsulta == Consulta.CONSULTA_SIMPLE 
					&& 
				( this.startInitialized || this.limitInitialized ) // => Se realiz� una inicializaci�n
			){
				contenido = getSegmento( contenido, this.start, this.limit );
			}
			
		} catch(Exception e) {
			
			throw new AppException("Error al extraer los registros:", e);
			
		} finally {
			
			if(con.hayConexionAbierta()) {
				con.terminaTransaccion(true); //Para consultas a tablas remotas a traves de dblink
				con.cierraConexionDB();
			}
			
		}
		
		return contenido;
		
	}
	
	/**
	 * Obtiene la informacion a mostrar.
	 * IMPORTANTE!!!!: Es necesario que los alias de las columnas en la consulta
	 * no se repitan, ya que de lo contrario el objeto resultante eliminar� los
	 * campos repetidos.
	 *
	 * @throws AppException
	 * @return Objeto <tt>ResultSet</tt> con el contenido de la consulta.
	 */
	public ResultSet getResultSetQueryContenido()
		throws AppException {
		
		// TODO: Se deja para implmentar a futuro, debe hacer exactamente lo que hace el m�todo: ejecutaQueryContenido()
		// pero en vez de un objeto Registros se deber� regresar un ResultSet.
		return null;
		
	}
	
	/**
	 * Devuelve numero total de registros de la consulta, y para ello utiliza el n�mero de llaves primarias.
	 * Este m�todo s�lo es �til despu�s de que se ejecute una nueva consulta en el m�todo consulta contenido.
	 * @throws AppException
	 */
	public Integer getNumeroTotalRegistros()
		throws AppException { 
		Integer numeroRegistros = ( Integer ) getAttribute(this.paginadorNumero);
		if( numeroRegistros == null ){
			throw new AppException("Se requiere que primero realice la consulta de contenido: contenido()");
		}
		return numeroRegistros;
	}
	
	/**
	 * Una consulta exitosa borra los totales anteriores
	 */
	public Registros contenido()
		throws AppException {
	
		/*
		
			Con respecto al contenido
			
									|
			tipoConsulta		|	CONSULTA_SIMPLE		
			---------------------------------------------------------------------						
									|	llavesPrimarias	contenido
			consultaNueva		|			X					S�
			!consultaNueva  	|			X					S�			
									|
									
									|
			tipoConsulta		|	CONSULTA_PAGINADA
			---------------------------------------------------------------------
									|	llavesPrimarias	contenido
			consultaNueva		|			S�					S�
			!consultaNueva		|			No					S�
									|
	
			Con respecto a los totales:
						|
			tipoConsulta		|	CONSULTA_SIMPLE		
			---------------------------------------------------------------------						
									|	calcular totales
			consultaNueva		|			S�
			!consultaNueva  	|			S�		
									|
									
									|
			tipoConsulta		|	CONSULTA_PAGINADA
			---------------------------------------------------------------------
									|	calcular totales
			consultaNueva		|			S�
			!consultaNueva		|			No
									|
		
		*/
		
		Registros 	contenido 		 		= null; 
	
		Registros 	llavesPrimarias 		= null;
		Integer		numeroTotalRegistros = null;
		boolean  	exito				 		= true;
		
		try {
			
			// Obtener las llaves primarias
			if( 			this.tipoConsulta == CONSULTA_SIMPLE 			){
				llavesPrimarias 	 = null; // No se usan
			} else if(  this.consultaNueva ){ 	// => CONSULTA_CON_PAGINACION
				llavesPrimarias 	 = ejecutaQueryLlavesPrimarias();
			} else {							 	// => CONSULTA_CON_PAGINACION
				llavesPrimarias 	 = ( Registros ) getAttribute(this.paginadorLlaves);
			}
			
			// Validar en el caso de una consulta con paginacion que se hayan obtenido exitosamente las llaves primarias
			if( this.tipoConsulta == Consulta.CONSULTA_CON_PAGINACION && llavesPrimarias == null ){
				throw new Exception(
					"La llaves primarias no fueron encontradas, revisar que el m�todo de la interfaz \n" +
					"getQueryLlavesPrimarias() no regrese null y que previamente se haya realizado una consulta nueva."
				);	
			}
			
			// Consultar Contenido
			contenido = ejecutaQueryContenido(llavesPrimarias);
			
			// Calcular registros totales
			if( 			this.tipoConsulta == CONSULTA_SIMPLE 						){
				numeroTotalRegistros = new Integer( contenido.getNumeroRegistros() 			);
			} else if(  this.tipoConsulta == Consulta.CONSULTA_CON_PAGINACION	){
				numeroTotalRegistros = new Integer( llavesPrimarias.getNumeroRegistros() 	);
			}
			
		} catch( Exception e ){
			
			exito = false;
			e.printStackTrace();
			throw new AppException("Ocurri� un error al realizar la consulta", e);
			
		} finally {
			

			if( 			exito && this.tipoConsulta == CONSULTA_SIMPLE        ){
				
				saveAttribute(this.paginadorLlaves, 	llavesPrimarias		); // llavesPrimarias es null por definicion
				saveAttribute(this.paginadorTotales,	null 						); // Se obliga a recalcular los totales
				saveAttribute(this.paginadorNumero,		numeroTotalRegistros );
				
			} else if(	exito && this.tipoConsulta == CONSULTA_CON_PAGINACION && this.consultaNueva ){ 
				// Para consulta con paginacion es obligatorio haber inicializado el objeto sesion => this.this.sessionInitialized == true
				
				saveAttribute(this.paginadorLlaves, 	llavesPrimarias		);
				saveAttribute(this.paginadorTotales,	null 						); // Se obliga a recalcular los totales
				saveAttribute(this.paginadorNumero,		numeroTotalRegistros );
				
			}
			
			// En caso de que haya un error, no se modifica nada de lo que actualmente est� en sesi�n
			
		}

		return contenido;
		
	}
	
	/**
	 * Devuelve un objeto <tt>Registros</tt> con el total absoluto de la consulta. De acuerdo a las reglas definidas
	 * el <tt>QueryBean</tt> del m�todo <tt>getQueryTotales()</tt> de la clase que implemente la interface <tt>IParametrosConsulta</tt>.
	 * Si se invoca este m�todo, ser� obligatorio ser� obligatorio que el m�todo <tt>getQueryTotales()</tt> regrese un valor diferente
	 * de <tt>null</tt>.
	 *
	 * @return Objecto <tt>Registros</tt> con el valor de los totales.
	 */
	public Registros totales()
		throws AppException{
			
		/*
									|
			tipoConsulta		|	CONSULTA_SIMPLE		
			---------------------------------------------------------------------						
									|	calcular totales
			consultaNueva		|			S�
			!consultaNueva  	|			S�		
									|
									
									|
			tipoConsulta		|	CONSULTA_PAGINADA
			---------------------------------------------------------------------
									|	calcular totales
			consultaNueva		|			S�
			!consultaNueva		|			No
									|
		*/
		
		Registros totales 			= null;
		boolean   guardarTotales	= false;
		try {
			
			totales = (Registros) getAttribute(this.paginadorTotales);
			if( totales == null ){
				totales = ejecutaQueryTotales();
				guardarTotales = true;
			}
			
		} catch(Exception e){
			
			guardarTotales = false;
			throw new AppException("Ocurri� un error al consultar los totales",e);
			
		} finally {
			
			if( guardarTotales ){
				saveAttribute( this.paginadorTotales, totales ); // Se obliga a recalcular los totales
			}
			
		}
		
		return totales;
		
	}
		
}
