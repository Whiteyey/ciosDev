/**
 * 
 */
package com.app.cios.web.controllers;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.app.cios.beans.AssistanceDTO;
import com.app.cios.beans.ClientesDTO;
import com.app.cios.beans.ResponseDTO;
import com.app.cios.beans.SesUsuarioCiosDTO;
import com.app.cios.utilerias.Registros;
import com.app.cios.web.services.ClientesQueries;

/**
 * 
 * @author JR Alvarado <jr.alvaradogarcia@gmail.com>
 *
 */
@Controller
public class ClientesController {
	
	ClientesQueries clientQueries;
	
	@RequestMapping(value = "/clientes", method = RequestMethod.GET)
	public String mainPage(ModelMap model,HttpServletRequest request) {

		ModelAndView aux= com.app.cios.utilerias.LoginUtil.isValidLogin(request);
		if(aux!=null){
			return "redirect:/";
		}
		HttpSession session = request.getSession();

		SesUsuarioCiosDTO u = (SesUsuarioCiosDTO) session.getAttribute("sesUsuario");

//		model.addAttribute("titlePage", "Main");
		model.addAttribute("title","Clientes");
		model.addAttribute("user", u.getNombreCompleto());
		model.addAttribute("addNew", "/clientes/addNewClient");
		model.addAttribute("details", "/clientes/details");
		
		return "clientes/clientes";
	}


	@RequestMapping(value="clientes/addNewClient", method = RequestMethod.GET)
	public ModelAndView add(HttpServletRequest request){
		ModelAndView  model = new ModelAndView ();
		ModelAndView aux= com.app.cios.utilerias.LoginUtil.isValidLogin(request);

		if(aux!=null){
			return aux;
		}
		
		HttpSession session = request.getSession();

		SesUsuarioCiosDTO u = (SesUsuarioCiosDTO) session.getAttribute("sesUsuario");
		
		model.addObject("title", "Nuevo Cliente");
		model.addObject("user", u.getNombreCompleto());
		model.setViewName("clientes/nuevoCliente");
		return model;
	}

	@RequestMapping(value="clientes/details", method = RequestMethod.GET)
	public ModelAndView details(HttpServletRequest request){
		ModelAndView  model = new ModelAndView ();
		ModelAndView aux= com.app.cios.utilerias.LoginUtil.isValidLogin(request);

		if(aux!=null){
			return aux;
		}
		
		HttpSession session = request.getSession();

		SesUsuarioCiosDTO u = (SesUsuarioCiosDTO) session.getAttribute("sesUsuario");

		model.addObject("user", u.getNombreCompleto());
		model.setViewName("clientes/detallesCliente");

		return model;
	}

	@RequestMapping(value="clientes/asistencia", method = RequestMethod.GET)
	public ModelAndView assistance(HttpServletRequest request){
		ModelAndView  model = new ModelAndView ();
		ModelAndView aux= com.app.cios.utilerias.LoginUtil.isValidLogin(request);

		if(aux!=null){
			return aux;
		}
		
		HttpSession session = request.getSession();

		SesUsuarioCiosDTO u = (SesUsuarioCiosDTO) session.getAttribute("sesUsuario");

		model.addObject("user", u.getNombreCompleto());
		model.addObject("title", "Lista de asistencia");
		model.setViewName("clientes/asistencia");

		return model;
	}
	
	@RequestMapping(value="/clientes/assistanceList", method = RequestMethod.POST)
	@ResponseBody
	public ResponseDTO getAssistanceList(HttpServletRequest request) throws ParseException {
		clientQueries = new ClientesQueries();
		Registros registros = clientQueries.getAssistanceList(5);

		List<AssistanceDTO> data = new ArrayList<>();

		while (registros.next()) {
			data.add(new AssistanceDTO(
					registros.getString("NOMBRE_COMPLETO"),
					Integer.parseInt(registros.getString("ID_ELEMENTO")),
					registros.getString("FECHA"),
					registros.getString("TURNO")));
		}
		return new ResponseDTO("assistanceList", true, data);
	}
	
	@RequestMapping(value="/addClient", method = RequestMethod.POST)
	@ResponseBody
	public ResponseDTO addClient(@RequestBody ClientesDTO client) throws ParseException {
		clientQueries = new ClientesQueries();
		return clientQueries.addClient(client);
	}

	@RequestMapping(value="/updateRelElement", method = RequestMethod.POST)
	@ResponseBody
	public ResponseDTO deleteMessage(@RequestBody ClientesDTO client) throws ParseException {
		clientQueries = new ClientesQueries();
		return clientQueries.updateRelElement(client);
	}
	
	@RequestMapping(value = "clientesData", method = RequestMethod.POST)
	public @ResponseBody ResponseDTO clientesData(HttpServletRequest request) {

		clientQueries = new ClientesQueries();
		
		Registros registros = clientQueries.getClients();
		
		List<ClientesDTO> data = new ArrayList<>();

		while (registros.next()) {
			data.add(new ClientesDTO(Integer.parseInt(registros.getString("ID_CLIENTE")),
					registros.getString("NOMBRE"),
					registros.getString("TELEFONO"),
					registros.getString("CORREO_ELECTRONICO"),
					registros.getString("GIRO"),
					registros.getString("DIRECTOR"),
					registros.getString("DIRECCION"),
					registros.getString("RFC"),
					registros.getString("RAZON"),
					registros.getString("LOGO_A"),
					registros.getString("LOGO_B"),
					registros.getString("LOGO_C")));
		}
		return new ResponseDTO("clientesData", true, data);
	}

	
	@RequestMapping(value = "clientesRelData", method = RequestMethod.POST)
	public @ResponseBody ResponseDTO clientesRelData(HttpServletRequest request) {

		clientQueries = new ClientesQueries();
		Registros registros = clientQueries.getRelClients();
		List<ClientesDTO> data = new ArrayList<>();

		while (registros.next()) {
			data.add(new ClientesDTO(Integer.parseInt(registros.getString("ID_CLIENTE")),
					Integer.parseInt(registros.getString("ID_ELEMENTO")), 
							""));
		}
		return new ResponseDTO("clientesData", true, data);
	}
}

