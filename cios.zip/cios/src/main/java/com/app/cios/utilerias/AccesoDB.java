package com.app.cios.utilerias;

import java.math.BigDecimal;

import java.sql.CallableStatement;
import java.sql.Connection;

import java.sql.PreparedStatement;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.sql.DataSource;
import com.app.cios.utilerias.consulta.QueryBean; 

public class AccesoDB {
	private DataSource ds;
	private static final String DEFAULT_DATASOURCE_NAME = 
		  ParametrosGlobalesApp.getInstance().getParametro("DEFAULT_DATASOURCE_NAME");
	private Connection con;

	public AccesoDB() {
		this.ds = 
					 ServiceLocator.getInstance().getDataSource(DEFAULT_DATASOURCE_NAME);
	}

	private AccesoDB(String dataSourceName) {
		this.ds = 
					 ServiceLocator.getInstance().getDataSource("jdbc/" + dataSourceName );
	}
	
	/**
	 * El método establece una conexi�n a la base de datos a trav�s de un
	 * datasource. 
	 */
	public void conexionDB() {
		try {
			//La siguiente condici�n es para evitar que se abra 
			//una conexion estando una ya abierta
			//lo cual genera problema de "Leaked Connections".
			if (con != null && !con.isClosed()) {
				System.out.println("AccesoDB::conexionDB()::ERROR. Ya hay una conexion Activa");
			} else {
				con = ds.getConnection();
				con.setAutoCommit(false);
				con.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);

//				PreparedStatement ps = 
//							  this.queryPrecompilado("ALTER SESSION SET NLS_TERRITORY = AMERICA");
//				try {
//					ps.executeUpdate();
//				} finally {
//					ps.close();
//				}
				con.commit();
			}
		} catch (Throwable e) {
			throw new AppException("Error al establecer una conexion de BD", e);
		}
	}

	public PreparedStatement queryPrecompilado(String qrySentencia, List lVarBind, 
															 int numMaxRegistros) {
		PreparedStatement ps = null;
		try {
			ps = con.prepareStatement(qrySentencia);
			for (int i = 0; i < lVarBind.size(); i++) {
				Object object = lVarBind.get(i);
				String contenido = object.toString().trim();
				if (object instanceof String) {
					ps.setString(i + 1, contenido);
				} else if (object instanceof Integer) {
					ps.setInt(i + 1, new Integer(contenido).intValue());
				} else if (object instanceof Long) {
					ps.setLong(i + 1, new Long(contenido).longValue());
				} else if (object instanceof Double) {
					ps.setDouble(i + 1, new Double(contenido).doubleValue());
				} else if (object instanceof BigDecimal) {
					ps.setBigDecimal(i + 1, new BigDecimal(contenido));
				} else if (object instanceof java.util.Calendar) {
					ps.setTimestamp(i + 1, 
										 new java.sql.Timestamp(((java.util.Calendar)object).getTime().getTime()), 
										 Calendar.getInstance());
				} else if (object instanceof java.util.Date) {
					ps.setTimestamp(i + 1, 
										 new java.sql.Timestamp(((java.util.Date)object).getTime()), 
										 Calendar.getInstance());
				} /* else if(object instanceof Fecha) {
                            ps.setNull(i+1, Types.TIMESTAMP);
                    } */ else if (object instanceof Class) {
					if ("int".equals(contenido)) {
						ps.setNull(i + 1, Types.INTEGER);
					} else if ("long".equals(contenido)) {
						ps.setNull(i + 1, Types.BIGINT);
					} else if ("double".equals(contenido)) {
						ps.setNull(i + 1, Types.DOUBLE);
					}
				}
			} //for(int i=0;i<lVarBind.size();i++)
			if (numMaxRegistros > 0) {
				ps.setMaxRows(numMaxRegistros);
			}
			return ps;
		} catch (Throwable e) {
			throw new AppException("Error al generar la consulta precompilada", 
										  e);

		}
	}

	public PreparedStatement queryPrecompilado(String query, 
															 List lVarBind) throws SQLException {
		return queryPrecompilado(query, lVarBind, 0);
	}

	public PreparedStatement queryPrecompilado(String query) throws SQLException {
		return queryPrecompilado(query, new ArrayList<>());
	}

	//////////////////////////////////////////////////
	// Ejecuta cualquier SQL dinamicamente
	//////////////////////////////////////////////////

	public CallableStatement ejecutaSP(String nombre_sp) {
		CallableStatement cstm = null;
		try {
			cstm = con.prepareCall("{call " + nombre_sp + "}");
			return cstm;
		} catch (Exception e) {
			throw new AppException("Error al ejecutar el procedimiento", e);
		}
	}

	public CallableStatement procesoPrecompilado(String proceso, 
																List lVarBind) {
		CallableStatement cs = null;
		try {
			cs = this.ejecutaSP(proceso);
			for (int i = 0; i < lVarBind.size(); i++) {
				Object object = lVarBind.get(i);
				String contenido = object.toString().trim();
				if (object instanceof String) {
					cs.setString(i + 1, contenido);
				} else if (object instanceof Integer) {
					cs.setInt(i + 1, new Integer(contenido).intValue());
				} else if (object instanceof Long) {
					cs.setLong(i + 1, new Long(contenido).longValue());
				} else if (object instanceof Double) {
					cs.setDouble(i + 1, new Double(contenido).doubleValue());
				} else if (object instanceof BigDecimal) {
					cs.setBigDecimal(i + 1, new BigDecimal(contenido));
				} else if (object instanceof java.util.Calendar) {
					cs.setTimestamp(i + 1, 
										 new java.sql.Timestamp(((java.util.Calendar)object).getTime().getTime()), 
										 Calendar.getInstance());
				} else if (object instanceof java.util.Date) {
					cs.setTimestamp(i + 1, 
										 new java.sql.Timestamp(((java.util.Date)object).getTime()), 
										 Calendar.getInstance());
				} /*else if(object instanceof Fecha) {
                                    cs.setNull(i+1, Types.TIMESTAMP);
                            } */ else if (object instanceof Class) {
					if ("int".equals(contenido)) {
						cs.setNull(i + 1, Types.INTEGER);
					} else if ("long".equals(contenido)) {
						cs.setNull(i + 1, Types.BIGINT);
					} else if ("double".equals(contenido)) {
						cs.setNull(i + 1, Types.DOUBLE);
					}
				}
			} //for(int i=0;i<lVarBind.size();i++)
			return cs;
		} catch (Exception e) {
			if (cs != null) {
				try {
					cs.close();
				} catch (Exception ex) {
					System.out.println("Error al cerrar el CallableStatement");
				}
			}
			System.out.println("AccesoDB::procesoPrecompilado(Exception) " + e);
			System.out.println("-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_");
			System.out.println("qrySentencia:" + proceso);
			System.out.println("lVarBind:" + lVarBind);
			System.out.println("-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_");
			throw new AppException("Error en procesoPrecompilado", e);
		}
	}

	//////////////////////////////////////////////////
	// Da commit o rollback a una transacci�n
	//////////////////////////////////////////////////

	public void terminaTransaccion(boolean todo_ok) {
		try {
			if (todo_ok) {
				con.commit();
			} else {
				con.rollback();
				System.out.println("terminaTransaccion(). Rollback");
			}
		} catch (Exception e) {
			if (todo_ok) {
				throw new AppException("Error al terminar la transaccion", e);
			} else {
				System.out.println("Error al terminar la transaccion (rollback): " + 
										 e.getMessage());
			}
		}
	}

	/* Regresa la Instancia de la Conexion */

	public Connection getConnection() {
		return this.con;
	}

	public void cierraConexionDB() {
		try {
			if (con != null) {
				con.close();
			}
		} catch (Exception e) {
			System.out.println("Error al cerrar laa conexion: " + e.getMessage());
		} finally {
			con = null;
		}
	}

	// El método indica si hay una conexion abierta o no.

	public boolean hayConexionAbierta() {
		if (con != null) {
			return true;
		} else {
			return false;
		}
	}


	/**
	 * Realiza una consulta a la base de datos.
	 * @param qrySentencia Cadena con la consulta SQL
	 * @param lVarBind Valores de las Variables bind
	 * @param bGetDataType Indicador de los tipo de datos de los resultados 
	 *              de la busqueda.
	 *       true Manejarlos de acuerdo a su tipo de dato en base de datos
	 *       false Manejados como cadenas
	 * @param numMaxRegistros N�mero m�ximo de registros a traer.
	 *              0 significa que no hay restricciones.
	 * 
	 * @return Objeto Registros que contiene la informaci�n 
	 *              resultante de la consulta
	 * @throws SQLException 
	 * @throws java.lang.Exception
	 */
	public Registros consultarDB(String qrySentencia, List lVarBind, 
										  boolean bGetDataType, int numMaxRegistros) throws SQLException {
		PreparedStatement ps = null;
		ResultSet rs = null;
		ResultSetMetaData rsMD = null;
		List nombres = new ArrayList();
		List renglones = new ArrayList();
		List columnas = null;
		Registros registros = new Registros();

		if (lVarBind == null) {
			lVarBind = new ArrayList();
		}
		try {
			ps = queryPrecompilado(qrySentencia, lVarBind, numMaxRegistros);
			rs = ps.executeQuery();
			ps.clearParameters();
			registros = this.getRegistrosFromRS(rs, bGetDataType);
			if (rs != null) {
				rs.close();
			}
			if (ps != null) {
				ps.close();
			}
		} catch (Exception e) {
			if (rs != null)
				rs.close();
			if (ps != null)
				ps.close();

			System.out.println("AccesoDB::consultarDB(Exception) " + e);
			System.out.println("-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_");
			System.out.println("qrySentencia:" + qrySentencia);
			System.out.println("lVarBind:" + lVarBind);
			System.out.println("-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_");
			e.printStackTrace();
			throw new AppException("Error en consultarDB", e);
		} finally {
			//if(this.showMessages) System.out.println("AccesoDB::consultarDB(S)");
		}
		return registros;
	} //consultarDB

	/**
	 * Convierte un objeto ResultSet a un Objeto Registro, SOLO usar si el
	 * numero de registros regresado en el ResultSet es peque�o.
	 * Por ejemplo en una paginaci�n.
	 * Es responsabilidad del codigo que manda a llamar este metodo, el de
	 * cerrar el resultset. Solo en caso de que se presente una excepcion
	 * se cierra el resultset
	 * @param rs ResultSet
	 * @param bGetDataType Determina si los registros seran manejados 
	 *      de acuerdo al tipo de dato en BD (bGetDataType = true) 
	 *      o como String (bGetDataType = false)
	 * @return Objeto con los registros obtenidos del ResultSet
	 */
	public Registros getRegistrosFromRS(ResultSet rs, boolean bGetDataType) {
		ResultSetMetaData rsMD = null;
		List nombres = new ArrayList();
		List renglones = new ArrayList();
		List columnas = null;
		Registros registros = new Registros();

		try {
			rsMD = rs.getMetaData();
			int numCols = rsMD.getColumnCount();
			int cont = 0;
			while (rs.next()) {
				columnas = new ArrayList();
				for (int i = 1; i <= numCols; i++) {
					if (cont == 0) {
						nombres.add(rsMD.getColumnName(i));
					} //if(cont==0)
					if (bGetDataType) {
						int colType = rsMD.getColumnType(i);
						switch (colType) {
						case Types.NUMERIC:
						case Types.DECIMAL:
						case Types.INTEGER:
							BigDecimal rs_numeric = 
												  rs.getBigDecimal(i) == null ? new BigDecimal("0") : 
												  rs.getBigDecimal(i);
							columnas.add(rs_numeric);
							break;
						case Types.DATE:
						case Types.TIME:
						case Types.TIMESTAMP:
							Timestamp rs_fecha = rs.getTimestamp(i);
							columnas.add(rs_fecha);
							break;
						default:
							String rs_campo = 
												  rs.getString(i) == null ? "" : rs.getString(i);
							columnas.add(rs_campo);
							break;
						} //switch(colType)
					} else {
						String rs_campo = 
											rs.getString(i) == null ? "" : rs.getString(i);
						columnas.add(rs_campo);
					}
				} //for(i=1;i<=numCols;i++)
				renglones.add(columnas);
				cont++;
			} //while(rs.next())
			registros.setNombreColumnas(nombres);
			registros.setData(renglones);
			return registros;
		} catch (Exception e) {
			try {
				if (rs != null) {
					rs.close();
				}
			} catch (Exception t) {
				System.out.println("AccesoDB.getRegistrosFromRS():: Error al cerrar ResultSet: " + 
										 t.getMessage());
			}
			throw new AppException("Error al convertir el ResultSet en objeto Registros", 
										  e);
		}
	}


	/**
	 * Ejecuta una consulta SQL y los resultados de esta son almacenados
	 * en un objeto de tipo Registros. En eset caso es necesario especificar
	 * una lista con los valores de las variables bind y un identificador que 
	 * determina si los valores del registro se guardan como String o como
	 * el tipo de dato que correponda.
	 * 
	 * @param qrySentencia Instrucci�n SQL
	 * @param lVarBind Valores de las variables bind
	 * @param bGetDataType true si se desea manejar los registros con el
	 *      tipo de dato que corresponda o false para manejarlo como cadena
	 * @throws java.lang.Exception
	 * @return Resultados de la consulta en un objeto de tipo Registros
	 * @throws SQLException 
	 */
	public

	Registros consultarDB(String qrySentencia, List lVarBind, 
								 boolean bGetDataType) throws SQLException {
		return consultarDB(qrySentencia, lVarBind, bGetDataType, 0);
	} //consultaDB

	/**
	 * Ejecuta una consulta SQL y los resultados de esta son almacenados
	 * en un objeto de tipo Registros. En eset caso es necesario especificar
	 * una lista con los valores de las variables bind.
	 * Los valores son guardados como String
	 * 
	 * @param qrySentencia Instrucci�n SQL
	 * @throws java.lang.Exception
	 * @return Resultados de la consulta en un objeto de tipo Registros
	 * @throws SQLException 
	 */
	public Registros consultarDB(String qrySentencia, List lVarBind) throws SQLException {
		return consultarDB(qrySentencia, lVarBind, false);
	} //consultaDB

	/**
	 * Ejecuta una consulta SQL y los resultados de esta son almacenados
	 * en un objeto de tipo Registros. 
	 * Los valores del registro son guardados como String
	 * 
	 * @param qrySentencia Instrucci�n SQL
	 * @throws java.lang.Exception
	 * @return Resultados de la consulta en un objeto de tipo Registros
	 * @throws SQLException 
	 */
	public Registros consultarDB(String qrySentencia) throws SQLException {
		return consultarDB(qrySentencia, new ArrayList());
	} //consultaDB


	public int ejecutaUpdateDB(String qrySentencia, 
										List lVarBind) throws Exception {
		System.out.println("AccesoDB::ejecutaUpdateDB(E)");
		PreparedStatement ps = null;
		int registros = 0;
		try {
			ps = queryPrecompilado(qrySentencia, lVarBind);
			registros = ps.executeUpdate();
			ps.close();
		} catch (Exception e) {
			if (ps != null)
				ps.close();
			System.out.println("AccesoDB::ejecutaUpdateDB(Exception) " + e);
			System.out.println("-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_");
			System.out.println("qrySentencia:" + qrySentencia);
			System.out.println("lVarBind:" + lVarBind);
			System.out.println("-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_");
			e.printStackTrace();
			throw e;
		} finally {
			System.out.println("AccesoDB::ejecutaUpdateDB(S)");
		}
		return registros;
	} //ejecutaQuery

	public int ejecutaUpdateDB(String qrySentencia) throws Exception {
		return ejecutaUpdateDB(qrySentencia, new ArrayList());
	} //ejecutaQuery
	public int ejecutaUpdateDB(QueryBean query) throws Exception	{
		return ejecutaUpdateDB(query.getQueryString(), query.getConditions());
	}

	/**
	 * Ejecuta una consulta SQL y los resultados de esta son almacenados
	 * en un objeto de tipo Registros. En este caso es necesario especificar
	 * la consulta usando un <tt>QueryBean</tt>.
	 * Los valores son guardados como String
	 * @throws java.lang.Exception
	 * 
	 * @param queryBean Instrucci�n SQL
	 *
	 * @return Resultados de la consulta en un objeto de tipo Registros
	 *
	 * @author Jhonatan Pacheco <jhonatanpachecohernandez@gmail.com>
	 * @since 05/05/2014 11:43:47 a.m.
	 *
	 */
	public static Registros consultarDB(QueryBean queryBean) 
		throws Exception {
		
		AccesoDB 	con 			= null;
		Registros 	registros 	= null;
		
		boolean 		exito			= true;
		
		try {
			
			con = new AccesoDB();
			con.conexionDB();
								
			registros = con.consultarDB(queryBean.getQueryString(), queryBean.getConditions(), false, 0); // SIN L�MITE M�XIMO DE REGISTROS
			
		} catch(Exception e) {
			
			exito = false;
			
			System.err.println("consultarDB(Exception)");
			System.err.println("consultarDB.queryBean = <" + queryBean+ ">");
			e.printStackTrace();
			
			throw e;
			
		} finally {
			
			if( con != null && con.hayConexionAbierta() ) {
				con.terminaTransaccion(exito); // Se agrega commit para anticipar el caso de bases remotas.
				con.cierraConexionDB();
			}
			
		}
	
		return registros;
		
	} //consultaDB
	
	/**
	 * Ejecuta una consulta SQL y los resultados de esta son almacenados
	 * en un objeto de tipo Registros. En este caso es necesario especificar
	 * la consulta usando un <tt>QueryBean</tt>.
	 * Los valores son guardados como String.
	 * Este método est� pensado para ser usado como parte de una transacci�n.
	 * Se deja al usuario hacer commit (en caso se trate de una tabla remota ) 
	 * de los cambios realizados y cerrar la conexion a la base de datos.
	 * @throws java.lang.Exception
	 *
	 * @param queryBean Instrucci�n SQL
	 * @param con <tt>AccesoDB</tt> con la conexi�n a la base de datos. 
	 *
	 * @return Resultados de la consulta en un objeto de tipo Registros
	 *
	 * @author Jhonatan Pacheco <jhonatanpachecohernandez@gmail.com>
	 * @since 05/05/2014 11:44:24 a.m.
	 *
	 */
	public static Registros consultarDB(QueryBean queryBean, AccesoDB con) 
		throws Exception {
		
		Registros 	registros 	= null;
		
		boolean 		exito			= true;
		
		try {
								
			registros = con.consultarDB(queryBean.getQueryString(), queryBean.getConditions(), false, 0); // SIN L�MITE M�XIMO DE REGISTROS
			
		} catch(Exception e) {
			
			exito = false;
			
			System.err.println("consultarDB(Exception)");
			System.err.println("consultarDB.queryBean = <" + queryBean+ ">");
			e.printStackTrace();
			
			throw e;
			
		} 
	
		return registros;
		
	} //consultaDB
	
	
}
