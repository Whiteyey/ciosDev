/**
 * 
 */
package com.app.cios;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;

import com.app.cios.beans.ClientesDTO;
import com.app.cios.utilerias.AccesoDB;
import com.app.cios.utilerias.Registros;
import com.app.cios.utilerias.ServiceLocator;
import com.app.cios.utilerias.consulta.QueryBean;

/**
 * @author Jhonatan Pacheco <jhonatanpachecohernandez@gmail.com>
 *
 */
public class ClientesData {
	
	private static final Log log = ServiceLocator.getInstance().getLog(ClientesData.class);
	
	public List<com.app.cios.beans.ClientesDTO> listaClientes(){
		
		List<com.app.cios.beans.ClientesDTO> clientes = new ArrayList<>();
		QueryBean qry = new QueryBean();
		Registros reg = null;
		try {
			qry.appendQueryString("SELECT * from tbl_clientes");
			reg = AccesoDB.consultarDB(qry);
			while(reg.next()){
				clientes.add(new ClientesDTO(
						Integer.parseInt(reg.getString("idCliente")), 
						reg.getString("nombre"), 
						reg.getString("telefono"), 
						reg.getString("correoElectronico"), 
						reg.getString("giro"), 
						reg.getString("direcctor"), 
						reg.getString("direccion"), 
						reg.getString("rfc"), 
						reg.getString("ra"), 
						reg.getString("logoA"), 
						reg.getString("logoB"), 
						reg.getString("logoC")
						));
			}
			return clientes;
		} catch (Exception e) {
			log.error("Error al consultar clientes");
		}
		
		return null;
	}

}
