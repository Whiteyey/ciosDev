/**
 * 
 */
package com.app.cios.modulos;

import java.util.HashMap;

import com.app.cios.beans.LoginDataDTO;
import com.app.cios.beans.SesUsuarioCiosDTO;
import com.app.cios.utilerias.AccesoDB;
import com.app.cios.utilerias.Registros;
import com.app.cios.utilerias.consulta.QueryBean;

/**
 * @author Jhonatan Pacheco <jhonatanpachecohernandez@gmail.com>
 *
 */
public class UsuariosDAO implements OperacionesBD {


	@Override
	public int add(int data) {
		// TODO Auto-generated method stub
		return 0;
	}





	@Override
	public int delete(HashMap<String,String> data) {
		// TODO Auto-generated method stub
		return 0;
	}





	@Override
	public int update(HashMap<String,String> data) {
		// TODO Auto-generated method stub
		return 0;
	}





	@Override
	public Object get(HashMap<String,String> data) {
		QueryBean qry = new QueryBean();
		Registros reg  = null;
		try {
			if(data.get("user-type").toString().equals("4")){
				qry.appendQueryString("SELECT * FROM tbl_clientes where ID_CLIENTE = ? ");	
				qry.appendCondition(data.get("clave"));
				reg = AccesoDB.consultarDB(qry);
				Object respuesta = new SesUsuarioCiosDTO();
				while(reg.next()){
					respuesta = new SesUsuarioCiosDTO(
							reg.getString("ID_CLIENTE"), 
							"",//reg.getString("APELLIDO_PATERNO"), 
							"",//reg.getString("APELLIDO_MATERNO"), 
							reg.getString("NOMBRE"), 
							reg.getString("DIRECTOR"), 
							"",//reg.getString("CLASIFICACION"), 
							0,//Integer.parseInt(reg.getString("ID_ESTATUS")), 
							"",//reg.getString("FECHA_ALTA"), 
							""//reg.getString("NSS")
							,data.get("login")
							);
					
				}
				return respuesta;
			}else{
				
				qry.appendQueryString("SELECT CLAVE, APELLIDO_PATERNO, "
									+ "	APELLIDO_MATERNO, NOMBRE, NOMBRE_COMPLETO,"
									+ " CLASIFICACION, ID_ESTATUS, FECHA_ALTA, NSS "
									+ " FROM tbl_empleados "
									+ " WHERE CLAVE  = ? ");
				qry.appendCondition(data.get("clave"));
				reg = AccesoDB.consultarDB(qry);
				Object respuesta = null;
				while(reg.next()){
					respuesta = new SesUsuarioCiosDTO(
							reg.getString("CLAVE"), 
							reg.getString("APELLIDO_PATERNO"), 
							reg.getString("APELLIDO_MATERNO"), 
							reg.getString("NOMBRE"), 
							reg.getString("NOMBRE_COMPLETO"), 
							reg.getString("CLASIFICACION"), 
							Integer.parseInt(reg.getString("ID_ESTATUS")), 
							reg.getString("FECHA_ALTA"), 
							reg.getString("NSS")
							,data.get("login")
							);
				}
				
				return respuesta;
			}
			

		} catch (Exception e) {
			// TODO: handle exception
		}
		
		return reg;
	}

}
