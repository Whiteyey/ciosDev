//package com.app.cios.utilerias.camposcombinacion; 
//
//import com.aspose.words.Cell;
//import com.aspose.words.CellMerge;
//import com.aspose.words.FieldMergingArgs;
//import com.aspose.words.IFieldMergingCallback;
//import com.aspose.words.ImageFieldMergingArgs;
//import com.aspose.words.NodeType;
//import com.aspose.words.Paragraph;
//
//public class CombinacionCeldas implements IFieldMergingCallback {
//
//	public void imageFieldMerging(ImageFieldMergingArgs arg0) throws Exception { } 
//
//
//	public void fieldMerging(FieldMergingArgs args) throws Exception 	{
//		// Change the text of each field of the ContactDetails region individually.			  
//		// Store the parent paragraph of the current field for easy access.
//		Paragraph parentParagraph = args.getField().getStart().getParentParagraph();
//
//		 if ("Registros".equals(args.getTableName())) {
//			// Set the text of the field based off the field name.
//			// Merge the cells of the table together.
//			 Cell cell = (Cell)parentParagraph.getAncestor(NodeType.CELL);
//			 if (cell != null)      {
//				if ( !args.getFieldValue().equals("")   )  {									   
//					cell.getCellFormat().setHorizontalMerge(CellMerge.FIRST);						
//				}else {
//					cell.getCellFormat().setHorizontalMerge(CellMerge.PREVIOUS); // Otherwise the merge is continued using "CellMerge.Previous".							
//				}
//			}
//		}	 
//	}
//	
//}