//package com.app.cios.utilerias.camposcombinacion;
//
//import com.aspose.words.IFieldMergingCallback;
//
//import java.util.LinkedHashMap;
//import java.util.List;
//
//import com.app.cios.utilerias.Registros;
//
///**
// * Interface que permite la creaci�n de archivos de word mediante plantillas con
// * campos de combinaci�n de correo.
// * 
// * @author jshernandez
// * @date 18/03/2014 07:30:45 p.m.
// *
// */
//public interface IDatosCamposCombinacion {
//
//	/**
//	 *	Devuelve un objeto de tipo <tt>Registros</tt>, con los datos de los campos de combinacion principales.
//	 * Si la plantilla no posee ningun campo de combinaci�n principal este deber� regresar <tt>null</tt>.
//	 *
//	 * @return Objeto <tt>Registros</tt> con datos de los campos de combinacion principales. 
//	 */
//	Registros  getDataSourceRaiz();
//	
//	/**
//	 * Si la plantilla posee una tabla con campos de combinacion de correo, los cuales son delimitados por los
//	 * tags: <<TableStart:..>> y <<TableEnd:...>>, se deber� regresar un objeto de tipo registros con los campos
//	 * de combinacion indicados de la tabla. Si la plantilla no tiene ninguna tabla con campos de combinaci�n, 
//	 * se deber� regresar <tt>null</tt>.
//	 * @deprecated
//    * 
//	 * @return Objeto <tt>Registros</tt> con datos de los campos de combinaci�n de la tabla. 
//	 */
//	Registros  getDataSourceTabla();
//	
//	/**
//	 * Devuelve el nombre de la tabla con campos de combinaci�n de correo. Aqu�l que se declara dentro de las
//	 * etiquetas: TableStart y TableEnd. Si la plantilla no tiene ninguna tabla con campos de combinaci�n, 
//	 * se deber� regresar <tt>null</tt>. 
//	 * @deprecated
//	 *
//	 * @return Objeto <tt>Registros</tt> con datos de los campos de combinaci�n de la tabla. 
//	 */
//	String  getDataSourceNombreTabla();
//   
//   /**
//    * Si la plantilla posee una o m�s tabla con campos de combinacion de correo, los cuales son delimitados por los
//    * tags: <<TableStart:..>> y <<TableEnd:...>>, se deber� regresar un objeto de tipo LinkedHashMap con los nombres
//    * de las tablas y sus registros asociados. Si la plantilla no tiene ninguna tabla con campos de combinaci�n, 
//    * se deber� regresar <tt>null</tt>.
//    * 
//    * @return Objeto <tt>LinkedHashMap</tt> con datos de los campos de combinaci�n de la tabla. 
//    */
//   LinkedHashMap getDataSourcesTabla();
//   
//	
//	/**
//	 * Ruta f�sica donde se encuentra la plantilla. Este campo es obligatorio.
//	 * 
//	 * @return <tt>String</tt> con la ruta f�sica de la plantilla.
//	 */
//	String  getRutaPlantilla();
//	
//	/**
//	 * Ruta del directorio temporal donde se creara el documento de word con los datos de los 
//	 * campos de combinacion de correo. Este campo es obligatorio.
//	 * 
//	 * @return <tt>String</tt> con la ruta f�sica del directorio temporal.
//	 */
//	String  getRutaDirectorioTemporal();
//	
//	/**
//	 * Devuelve el login del usuario que creo el archivo.
//	 *
//	 * @return <tt>String</tt> con el login del usuario que creo el archivo. <tt>null</tt> si esta funcionalidad no es requerida.
//	 */
//	String  getLoginUsuario();
//	
//	/**
//	 *
//	 * M�todo que se encarga de validar la plantilla indicada en el m�todo: <tt>getRutaPlantilla()</tt>.
//	 * Deber� regresar <tt>true</tt> si la validaci�n es exitosa y <tt>false</tt> en caso contrario.
//	 * En el parametro <tt>errores</tt>, se deber�n regresar todos los errores encontrados en la validaci�n.
//	 * Para poder ser usado con la clase <tt>CamposCombinacion</tt> para crear archivos, la validaci�n
//	 * deber� ser exitosa.
//	 * @throws Exception
//	 * 
//	 * @param error	     <tt>String[]</tt> en cuyo primer elemento viene un error, que no es
//	 *							  espec�fico a un campo de combianci�n de correspondencia.
//	 * @param erroresCampo <tt>List</tt> con los errores en los campos de combinaci�n de correo.
//	 * @param nombresCampo <tt>String[]</tt> con los nombres de todos los campos de combinacion de correo. 
//	 * En caso de que la plantilla posea una tabla con campos de combinaci�n estos tendr�n la siguiente forma:
//	 * "TableStart:MI_TABLA" y "TableEnd:MI_TABLA"; para todos los dem�s casos se enviar� el nombre 
//	 * simple del campo: "NOMBRE_USUARIO", inclusive los nombres de los campos de combinaci�n declarados dentro
//	 * de la tabla.
//	 *
//	 * @return <tt>true</tt> si la validaci�n fue exitosa y <tt>false</tt> en caso contrario.
//	 *
//	 */
//	boolean validaPlantilla( String[] error, List erroresCampo, String[] nombresCampo ) throws Exception;
//	
//	
//	/**
//	 *  
//	 * Clase que invoca cada vez que se reemplaza el valor de un campo de combinaci�n por su valor.
//	 * Se utiliza, por ejemplo para marcar en amarillo los campos de combinacion que no tienen valor.
//	 *  
//	 * @return Una clase que implementa <tt>IFieldMergingCallback</tt> o null, si no se desea usar
//	 * esta caracter�stica.
//	 * 
//	 */
//	public IFieldMergingCallback getFieldMergingCallback();
//	
//}
