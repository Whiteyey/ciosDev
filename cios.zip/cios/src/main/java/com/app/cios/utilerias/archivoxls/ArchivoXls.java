package com.app.cios.utilerias.archivoxls;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import java.nio.channels.FileChannel;

import java.util.HashMap;
import java.util.List;

import com.app.cios.utilerias.AppException;
import com.app.cios.utilerias.Comunes;

import com.app.cios.utilerias.Registros;
import com.app.cios.utilerias.ServiceLocator;
import com.app.cios.utilerias.Validaciones;
import com.app.cios.utilerias.archivo.ArchivoBean;


import org.apache.commons.logging.Log;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.util.CellRangeAddress;

/**
 * Clase que se encarga de crear archivos de excel(xls) a partir de una lista de objetos de datos, 
 * para ello implementar se deber� implementar la interface <tt>IDatosArchivoXls</tt>.
 *
 * @author jshernandez
 * @date 14/04/2014 12:30:18 p.m.
 *
 */
public class ArchivoXls {

	//Variable para enviar mensajes al log.
	private static final Log log  = ServiceLocator.getInstance().getLog(ArchivoXls.class);
	
	private IDatosArchivoXls iDatosArchivoXls;
	
	/**
	 * Asigna el objeto de datos que se usar� para crear el archivo xls.
	 *
	 * @param iDatosArchivoXls Objeto de datos, de tipo <tt>IDatosArchivoXls</tt>.
	 *
	 */
	public void setIDatosArchivoXls(IDatosArchivoXls iDatosArchivoXls){
		this.iDatosArchivoXls = iDatosArchivoXls;
	}
  		
	/**
	 * Crea un archivo xls de Excel. 
	 * 
	 * @param archivoBean   <tt>ArchivoBean[]</tt> en cuyo primer elemento se regresar� el archivo creado.
	 *								S�lo se regresar� el atrubuto ArchivoBean[0].rutaAbsoluta.
	 * @param msg           <tt>String[]</tt> con algun mensaje, por ejemplo cuando faltan parametros o
	 *                      falla la creaci�n del archivo.
	 *
	 * @return <tt>true</tt> si la creaci�n del archivo fue exitosa y <tt>false</tt> en caso 
	 * contrario.
	 *
	 * @author jshernandez
	 * @since 24/04/2014 07:45:25 p.m.
	 *
	 */
   public boolean crea(ArchivoBean[] archivoBean, String[] msg){
   	
   	/*
   		Nota:La siguiente clase ser� de implementaci�n opcional -> Ser�a una colecci�n de instrucciones de configuraci�n:
   	 
   		Formato formatoTitulo    = new Control[]{ Control.ESTILOS, Estilos.TITULO, Control.COLSPAN, new Integer(4) }
   		Formato fotmatoSubtitulo = new Control[]{ Control.ESTILOS, Estilos.SUBTITULO, Control.COLSPAN, new Integer(4) } 
   		formatoTitulo    || Control.ESTILOS, Estilos.TITULO, Control.COLSPAN, new Integer(4)
   		fotmatoSubtitulo || Control.ESTILOS, Estilos.SUBTITULO, Control.COLSPAN, new Integer(4)  
   	*/
   	
   	boolean				exito				= true;
   	
   	HSSFWorkbook 		excelWorkbook  = null;
   	HSSFSheet 			sheet 			= null;
   	HSSFRow 				row 				= null;
   	HSSFCell 			cell 				= null;
   	
   	FileOutputStream 	outputStream 	= null;
   	
   	String 				nombreHoja		= "";
   	List 					listaDatos 		= null;
		try {
			
			// VALIDACIONES
			
			if(       this.iDatosArchivoXls == null ){
				
				archivoBean[0] = null;
				msg[0] 			= "ArchivoXls.crea: El atributo iDatosArchivoXls es requerido.";
				exito				= false;
				
				return exito;
				
			// Validar que se haya especificado al menos un Data Source
			} else if( Validaciones.esVacio( this.iDatosArchivoXls.getDataSourceList() ) ){
				
				archivoBean[0] = null;
				msg[0] 			= "ArchivoXls.crea: El atributo IDatosArchivoXls.dataSourceList es requerido.";
				exito				= false;
				
				return exito;
				
			// Validar que se haya especificado la ruta del directorio temporal donde se crear� el archivo.
			} else if( Validaciones.esVacio(this.iDatosArchivoXls.getRutaDirectorioTemporal()) ){
				
				archivoBean[0] = null;
				msg[0] 			= "ArchivoXls.crea: El atributo IDatosArchivoXls.rutaDirectorioTemporal es requerido.";
				exito				= false;
				
				return exito;
				
			}

			// CREAR EXCEL EN MEMORIA
			
			// Definir lista de estados permitidos
			final int INICIALIZACION 			= 101;
			final int FIN 				 			= 102;
			final int DETERMINA_OPERACION 	= 103;
			// Instruccion endemicas de la operacion
			final int INSERTA_STRING			= 201;
			final int INSERTA_STRING_ARRAY	= 202;
			final int INSERTA_REGISTROS		= 203;
			final int INSERTA_OBJETO			= 204;
			final int AGREGA_SALTO_LINEA		= 205;
			final int LEE_OFFSET 				= 206;
			final int LEE_COLSPAN 				= 207;
			final int LEE_ESTILO 				= 208;
			final int AGREGA_HOJA_NUEVA 		= 209;
			final int RESETEA_FORMATO			= 210;
			// Construir excel
			int 			estado  		 			= INICIALIZACION;
			int 			elemento 				= 0;
			int 			numeroRenglon			= 0;
			// Atributos especiales
			Object 		offset					= null; // Integer || Integer[]
			Object 		colspan					= null; // Integer || Integer[]
			Object  		estilo					= null; // Estilo  || Estilo[]
			HashMap		cacheEstilos			= null;
			while(true){
				
				if( 			estado == INICIALIZACION 		){
					
					excelWorkbook 	= new HSSFWorkbook();
					listaDatos 		= this.iDatosArchivoXls.getDataSourceList();
					
					if( listaDatos.size() == 0 ){
						estado = FIN;	
						continue;
					}

					// Si no tiene hoja nueva, agregarla
					if( Instruccion.HOJA_NUEVA.equals(listaDatos.get(0)) == false ) {
						sheet 			= excelWorkbook.createSheet(); // Crear hoja vac�a
						numeroRenglon	= 0;
						offset			= null; // Integer || Integer[]
						colspan			= null; // Integer || Integer[]
						estilo			= null; // Estilo  || Estilo[]
					}					
					// Construir cache con los estilos
					cacheEstilos = createHSSFCellStyles(excelWorkbook,listaDatos);
					
					estado = DETERMINA_OPERACION;
	
				} else if(	estado == DETERMINA_OPERACION ){
					
					if( elemento == listaDatos.size() ){
						estado = FIN;
						continue;
					}
					
					Object 		value 							= listaDatos.get(elemento++);
					
					if(			value == null 									){
						archivoBean[0] = null;
						msg[0] 			= "ArchivoXls.crea: El elemento IDatosArchivoXls.dataSourceList[" + ( elemento - 1 ) + "] no puede ser nulo.";
						exito				= false;
						return exito;
					} else if( 	value instanceof String 					){
						elemento--;
						estado = INSERTA_STRING;
					} else if(	value instanceof String[] 					){
						elemento--;
						estado = INSERTA_STRING_ARRAY;
					} else if(	value instanceof Registros 				){
						elemento--;
						estado = INSERTA_REGISTROS;
					} else if(  value instanceof Instruccion == false 	){
						elemento--;
						estado = INSERTA_OBJETO;
					} else if( 	Instruccion.SALTO_LINEA.equals(value) 	){
						estado = AGREGA_SALTO_LINEA;
					} else if(	Instruccion.OFFSET.equals(value) 		){
						estado = LEE_OFFSET;
					} else if(	Instruccion.COLSPAN.equals(value) 		){
						estado = LEE_COLSPAN;
					} else if(	Instruccion.ESTILO.equals(value) 		){
						estado = LEE_ESTILO;
					} else if(	Instruccion.HOJA_NUEVA.equals(value) 	){
						estado = AGREGA_HOJA_NUEVA;
					} else if(	Instruccion.RESET_FORMATO.equals(value)){
						elemento--;
						estado = RESETEA_FORMATO;
					// El tipo de Instruccion indicada no esta reconocida
					} else {
						archivoBean[0] = null;
						msg[0] 			= "ArchivoXls.crea: La instrucci�n indicada en IDatosArchivoXls.dataSourceList[" + (elemento - 1 ) + "] no es valida.";
						exito				= false;
						return exito;
					}
					
				} else if(	estado == INSERTA_STRING 		){
					
					if( elemento == listaDatos.size() ){
						archivoBean[0] = null;
						msg[0] 			= "ArchivoXls.crea: El elemento IDatosArchivoXls.dataSourceList[" + elemento + "] es requerido.";
						exito				= false;
						return exito;
					}
					
					String stringValue = (String) listaDatos.get(elemento++);
					if ( stringValue == null ){
						// No se puede insertar valores nulos.
						archivoBean[0] = null;
						msg[0] 			= "ArchivoXls.crea: El elemento en IDatosArchivoXls.dataSourceList[" + (elemento - 1 ) + "] no puede ser nulo.";
						exito				= false;
						return exito;
					}

					// Crear nuevo renglon
					int renglonActual = numeroRenglon++;
					row  					= sheet.createRow(renglonActual);
					
					int 	   cellOffset  = getIntValue( 0, offset  );
					int	 	cellColspan = getIntValue( 0, colspan );
					Estilo 	cellEstilo	= getEstilo( 	0, estilo  );

					// Calcular posiciones
					int 	columnIndex	= 0 + cellOffset;
					
					// Create a cell and put a value in it.
					cell = row.createCell(columnIndex);					
					if( cellColspan > 1    ){
						sheet.addMergedRegion( new CellRangeAddress(renglonActual, renglonActual, columnIndex, columnIndex + cellColspan - 1 ) );
					}
					if( cellEstilo != null ){
						cell.setCellStyle( (HSSFCellStyle) cacheEstilos.get(cellEstilo) );
					}
					cell.setCellValue(stringValue);
					
					// Especificar estado siguiente
					estado = DETERMINA_OPERACION;
					
				} else if(	estado == INSERTA_STRING_ARRAY	){
					
					if( elemento == listaDatos.size() ){
						archivoBean[0] = null;
						msg[0] 			= "ArchivoXls.crea: El elemento IDatosArchivoXls.dataSourceList[" + elemento + "] es requerido.";
						exito				= false;
						return exito;
					}
					
					String[] valuesArray = (String[]) listaDatos.get(elemento++);
					if ( valuesArray == null ){
						// No se puede insertar valores nulos.
						archivoBean[0] = null;
						msg[0] 			= "ArchivoXls.crea: El elemento en IDatosArchivoXls.dataSourceList[" + (elemento - 1 ) + "] no puede ser nulo.";
						exito				= false;
						return exito;
					}

					// Crear nuevo renglon
					int renglonActual = numeroRenglon++;
					row  					= sheet.createRow(renglonActual);
						
					for(int i=0,indiceColumna=0;indiceColumna<valuesArray.length;i++,indiceColumna++){

						int 	   cellOffset  = getIntValue( i, offset  );
						int	 	cellColspan = getIntValue( i, colspan );
						Estilo 	cellEstilo	= getEstilo( 	i, estilo  );

						// Calcular posiciones
						int 		columnIndex	= i + cellOffset;
					
						// Create a cell and put a value in it.
						cell = row.createCell(columnIndex);
						if( cellColspan > 1    ){
							sheet.addMergedRegion( new CellRangeAddress(renglonActual, renglonActual, columnIndex,  columnIndex + cellColspan - 1) );
						}
						if( cellEstilo != null ){
							cell.setCellStyle( (HSSFCellStyle) cacheEstilos.get(cellEstilo) );
						}
						cell.setCellValue(valuesArray[indiceColumna]);
					}
					
					// Especificar estado siguiente
					estado = DETERMINA_OPERACION;
					
				} else if(	estado == INSERTA_REGISTROS 		){
					
					if( elemento == listaDatos.size() ){
						archivoBean[0] = null;
						msg[0] 			= "ArchivoXls.crea: El elemento IDatosArchivoXls.dataSourceList[" + elemento + "] es requerido.";
						exito				= false;
						return exito;
					}
					
					Registros registros = (Registros) listaDatos.get(elemento++);
					if ( registros == null ){
						// No se puede insertar valores nulos.
						archivoBean[0] = null;
						msg[0] 			= "ArchivoXls.crea: El elemento en IDatosArchivoXls.dataSourceList[" + (elemento - 1 ) + "] no puede ser nulo.";
						exito				= false;
						return exito;
					}

					int numeroColumnas = registros.getNombreColumnas().size();
					while( registros.next() ){
						
						// Crear nuevo renglon
						int renglonActual = numeroRenglon++;
						row  					= sheet.createRow(renglonActual);
					
						for( int i=0,indiceColumna = 1; indiceColumna <= numeroColumnas; i++,indiceColumna++ ){
							
							int 	   cellOffset  = getIntValue( i, offset  );
							int	 	cellColspan = getIntValue( i, colspan );
							Estilo 	cellEstilo	= getEstilo( 	i, estilo  );
	
							// Calcular posiciones
							int 		columnIndex	= i + cellOffset;
						
							// Create a cell and put a value in it.
							cell = row.createCell(columnIndex);
							if( cellColspan > 1    ){
								sheet.addMergedRegion( new CellRangeAddress(renglonActual, renglonActual, columnIndex,  columnIndex + cellColspan - 1) );
							}
							if( cellEstilo != null ){
								cell.setCellStyle( (HSSFCellStyle) cacheEstilos.get(cellEstilo) );
							}
							cell.setCellValue(registros.getString(indiceColumna));
							
						}
						
					}
					
					// Especificar estado siguiente
					estado = DETERMINA_OPERACION;
					
				} else if(	estado == INSERTA_OBJETO 			){
					
					if( elemento == listaDatos.size() ){
						archivoBean[0] = null;
						msg[0] 			= "ArchivoXls.crea: El elemento IDatosArchivoXls.dataSourceList[" + elemento + "] es requerido.";
						exito				= false;
						return exito;
					}
					
					Object value = listaDatos.get(elemento++);
					if ( value == null ){
						// No se puede insertar valores nulos.
						archivoBean[0] = null;
						msg[0] 			= "ArchivoXls.crea: El elemento en IDatosArchivoXls.dataSourceList[" + (elemento - 1 ) + "] no puede ser nulo.";
						exito				= false;
						return exito;
					}

					// Crear nuevo renglon
					int renglonActual = numeroRenglon++;
					row  					= sheet.createRow(renglonActual);
					
					int 	   cellOffset  = getIntValue( 0, offset  );
					int	 	cellColspan = getIntValue( 0, colspan );
					Estilo 	cellEstilo	= getEstilo( 	0, estilo  );
	
					// Calcular posiciones
					int 		columnIndex	= 0 + cellOffset;
							
					// Create a cell and put a value in it.
					cell = row.createCell(columnIndex);
					if( cellColspan > 1    ){
						sheet.addMergedRegion( new CellRangeAddress(renglonActual, renglonActual, columnIndex,  columnIndex + cellColspan - 1) );
					}
					if( cellEstilo != null ){
						cell.setCellStyle( (HSSFCellStyle) cacheEstilos.get(cellEstilo) );
					}
					cell.setCellValue(value.toString());
					
					// Especificar estado siguiente
					estado = DETERMINA_OPERACION;
					
				} else if(	estado == AGREGA_SALTO_LINEA 		){
					
					if( elemento == listaDatos.size() ){
						archivoBean[0] = null;
						msg[0] 			= "ArchivoXls.crea: El elemento IDatosArchivoXls.dataSourceList[" + elemento + "] es requerido.";
						exito				= false;
						return exito;
					}
					
					Object value = listaDatos.get(elemento++);
					if ( 			value == null ){
						// No se puede insertar valores nulos.
						archivoBean[0] = null;
						msg[0] 			= "ArchivoXls.crea: El elemento en IDatosArchivoXls.dataSourceList[" + (elemento - 1 ) + "] no puede ser nulo.";
						exito				= false;
						return exito;
					// Verificar que efectivamente se haya especificado un salto de l�nea
					} else if( 	value instanceof Integer == false ){
						archivoBean[0] = null;
						msg[0] 			= "ArchivoXls.crea: Se esperaba una instancia de Integer en IDatosArchivoXls.dataSourceList[" + (elemento - 1 ) + "].";
						exito				= false;
						return exito;
					}					
					
					// Agregar saltos de linea
					Integer saltosLinea = (Integer) value;
					if( saltosLinea > 0 ){
						numeroRenglon = numeroRenglon + saltosLinea;
					} else {
						archivoBean[0] = null;
						msg[0] 			= "ArchivoXls.crea: Se esperaba un Integer mayor a 0 en IDatosArchivoXls.dataSourceList[" + (elemento - 1 ) + "].";
						exito				= false;
						return exito;
					}
					
				} else if(	estado == LEE_OFFSET 				){
					
					if( elemento == listaDatos.size() ){
						archivoBean[0] = null;
						msg[0] 			= "ArchivoXls.crea: El elemento IDatosArchivoXls.dataSourceList[" + elemento + "] es requerido.";
						exito				= false;
						return exito;
					}
					
					Object value = listaDatos.get(elemento++);
					if ( 			value == null ){
						// No se puede insertar valores nulos.
						archivoBean[0] = null;
						msg[0] 			= "ArchivoXls.crea: El elemento en IDatosArchivoXls.dataSourceList[" + (elemento - 1 ) + "] no puede ser nulo.";
						exito				= false;
						return exito;
					} 
					
					// Verificar que efectivamente se haya especificado un salto de l�nea
					if( 		  value instanceof Integer 	){
						offset = value;
					} else if( value instanceof Integer[] 	){
						offset = value;
					} else {
						archivoBean[0] = null;
						msg[0] 			= "ArchivoXls.crea: Se esperaba una instancia de Integer o de Integer[] en IDatosArchivoXls.dataSourceList[" + (elemento - 1 ) + "].";
						exito				= false;
						return exito;
					}
					
					estado = DETERMINA_OPERACION;
					
				} else if(	estado == LEE_COLSPAN 				){
					
					if( elemento == listaDatos.size() ){
						archivoBean[0] = null;
						msg[0] 			= "ArchivoXls.crea: El elemento IDatosArchivoXls.dataSourceList[" + elemento + "] es requerido.";
						exito				= false;
						return exito;
					}
					
					Object value = listaDatos.get(elemento++);
					if ( 			value == null ){
						// No se puede insertar valores nulos.
						archivoBean[0] = null;
						msg[0] 			= "ArchivoXls.crea: El elemento en IDatosArchivoXls.dataSourceList[" + (elemento - 1 ) + "] no puede ser nulo.";
						exito				= false;
						return exito;
					} 
					
					// Verificar que efectivamente se haya especificado un salto de l�nea
					if( 		  value instanceof Integer 	){
						colspan = value;
					} else if( value instanceof Integer[] 	){
						colspan = value;
					} else {
						archivoBean[0] = null;
						msg[0] 			= "ArchivoXls.crea: Se esperaba una instancia de Integer o de Integer[] en IDatosArchivoXls.dataSourceList[" + (elemento - 1 ) + "].";
						exito				= false;
						return exito;
					}
					
					estado = DETERMINA_OPERACION;
					
				} else if(	estado == LEE_ESTILO 				){
					
					if( elemento == listaDatos.size() ){
						archivoBean[0] = null;
						msg[0] 			= "ArchivoXls.crea: El elemento IDatosArchivoXls.dataSourceList[" + elemento + "] es requerido.";
						exito				= false;
						return exito;
					}
					
					Object value = listaDatos.get(elemento++);
					if ( 			value == null ){
						// No se puede insertar valores nulos.
						archivoBean[0] = null;
						msg[0] 			= "ArchivoXls.crea: El elemento en IDatosArchivoXls.dataSourceList[" + (elemento - 1 ) + "] no puede ser nulo.";
						exito				= false;
						return exito;
					} 
					
					// Verificar que efectivamente se haya especificado un salto de l�nea
					if( 		  value instanceof Estilo 		){
						estilo = value;
					} else if( value instanceof Estilo[] 	){
						estilo = value;
					} else {
						archivoBean[0] = null;
						msg[0] 			= "ArchivoXls.crea: Se esperaba una instancia de Estilo o de Estilo[] en IDatosArchivoXls.dataSourceList[" + (elemento - 1 ) + "].";
						exito				= false;
						return exito;
					}
					
					estado = DETERMINA_OPERACION;
					
				} else if(	estado == AGREGA_HOJA_NUEVA 		){
					
					if( elemento == listaDatos.size() ){
						archivoBean[0] = null;
						msg[0] 			= "ArchivoXls.crea: El elemento IDatosArchivoXls.dataSourceList[" + elemento + "] es requerido.";
						exito				= false;
						return exito;
					}
					
					Object value = listaDatos.get(elemento++);
					if ( 			value == null ){
						// No se puede insertar valores nulos.
						archivoBean[0] = null;
						msg[0] 			= "ArchivoXls.crea: El elemento en IDatosArchivoXls.dataSourceList[" + (elemento - 1 ) + "] no puede ser nulo.";
						exito				= false;
						return exito;
					} 
					
					if( value instanceof String 		){
						String sheetName 	= supressInvalidSheetNameChars(value.toString());
						sheet 				= Validaciones.esVacio(sheetName)?excelWorkbook.createSheet():excelWorkbook.createSheet(sheetName); // Crear hoja 
						numeroRenglon		= 0;
						offset				= null; // Integer || Integer[]
						colspan				= null; // Integer || Integer[]
						estilo				= null; // Estilo  || Estilo[]
					} else {
						archivoBean[0] 	= null;
						msg[0] 				= "ArchivoXls.crea: Se esperaba una instancia de String en IDatosArchivoXls.dataSourceList[" + (elemento - 1 ) + "].";
						exito					= false;
						return exito;
					}
						
					estado = DETERMINA_OPERACION;
					
				} else if(	estado == RESETEA_FORMATO		){
					
					if( elemento == listaDatos.size() ){
						archivoBean[0] = null;
						msg[0] 			= "ArchivoXls.crea: El elemento IDatosArchivoXls.dataSourceList[" + elemento + "] es requerido.";
						exito				= false;
						return exito;
					}
					
					Object value = listaDatos.get(elemento++);
					if ( 			value == null ){
						// No se puede insertar valores nulos.
						archivoBean[0] = null;
						msg[0] 			= "ArchivoXls.crea: El elemento en IDatosArchivoXls.dataSourceList[" + (elemento - 1 ) + "] no puede ser nulo.";
						exito				= false;
						return exito;
					} 
					
					if( Instruccion.RESET_FORMATO.equals(value) ){
						offset			= null; // Integer || Integer[]
						colspan			= null; // Integer || Integer[]
						estilo			= null; // Estilo  || Estilo[]
					} else {
						archivoBean[0] = null;
						msg[0] 			= "ArchivoXls.crea: Se esperaba una instancia de Instruccion en IDatosArchivoXls.dataSourceList[" + (elemento - 1 ) + "].";
						exito				= false;
						return exito;
					}
						
					estado = DETERMINA_OPERACION;

				} else if(	estado == FIN 							){
					break;	
				}
				
			}

			// GENERAR RUTA ABSOLUTA AL ARCHIVO
			StringBuffer rutaAbsolutaArchivo	= new StringBuffer();
			rutaAbsolutaArchivo.append(this.iDatosArchivoXls.getRutaDirectorioTemporal());
			if( !Validaciones.esVacio(this.iDatosArchivoXls.getLoginUsuario() ) ){
				rutaAbsolutaArchivo.append( this.iDatosArchivoXls.getLoginUsuario() );
				rutaAbsolutaArchivo.append( "." );
			}
			// Generar Nombre Aleatorio del Archivo
			rutaAbsolutaArchivo.append( Comunes.cadenaAleatoria(16) );
			// Agregar extension
			rutaAbsolutaArchivo.append( ".xls" );
				
			// GUARDAR ARCHIVO EN DISCO
			outputStream = new FileOutputStream(rutaAbsolutaArchivo.toString());
			excelWorkbook.write(outputStream);
			
			// CREAR ArchivoBean QUE GUARDARA EL ARCHIVO CREADO
			ArchivoBean archivoExcel = new ArchivoBean();
			// Agregar ruta absoluta del archivo extraido
         archivoExcel.setRutaAbsoluta( rutaAbsolutaArchivo.toString() );
            
			// ENVIAR RESULTADO
			archivoBean[0] = archivoExcel;
			msg[0] 			= null;
			
		} catch(Exception e){
			
			exito = false;
			
			log.error("crea(Exception)");
			log.error("crea.msg         = <" + msg             + ">");
			log.error("iDatosArchivoXls = <" + iDatosArchivoXls + ">");
			e.printStackTrace();
			 
			archivoBean[0] = null;
			msg[0] 			= e.getMessage();
			
		} finally {
			
			if( outputStream != null ) { try{ outputStream.close(); }catch(Exception e){} }
			
		}
    
		return exito;
		
	}

	private int getIntValue( int indice, Object valor ){
		
		int resultado = 0;
		if( valor == null ){
			resultado = 0;
		} else if( valor instanceof Integer ){
			resultado = ( (Integer) valor ).intValue();
		} else if( valor instanceof Integer[] ){
			Integer[] integerArray = (Integer[]) valor;
			if(        indice              <  0 ){
				resultado = 0;
			} else if( integerArray.length == 0 ){
				resultado = 0;
			} else if( indice >= integerArray.length ){
				resultado = integerArray[integerArray.length-1].intValue();
			} else {
				resultado = integerArray[indice].intValue();
			}
		}
		
		return resultado;
		
	}
	
	private Estilo getEstilo( int indice, Object valor ){
		
		Estilo resultado = null;
		if( valor == null ){
			resultado = null;
		} else if( valor instanceof Estilo ){
			resultado = (Estilo) valor;
		} else if( valor instanceof Estilo[] ){
			Estilo[] estiloArray = (Estilo[]) valor;
			if(        indice              <  0 ){
				resultado = null;
			} else if( estiloArray.length == 0 ){
				resultado = null;
			} else if( indice >= estiloArray.length ){
				resultado = estiloArray[estiloArray.length-1];
			} else {
				resultado = estiloArray[indice];
			}
		}
		
		return resultado;
		
	}
	
	private HashMap createHSSFCellStyles( HSSFWorkbook excelWorkbook, List listaDatos ){
		
		HashMap cache = new HashMap();
		for(int i=0;i<listaDatos.size();i++){
			Object  value = listaDatos.get(i);
			if( 			value instanceof Estilo 	){
				
				Estilo			estilo		= (Estilo) value;
				
				if( cache.containsKey(estilo) ){
					continue;
				}
					
				HSSFFont			font 			= excelWorkbook.createFont();
				font.setFontHeightInPoints(	estilo.getFontHeightInPoints()	);
				font.setColor(						estilo.getColor()						);
				font.setBoldweight(				estilo.getBoldweight()				);
				font.setFontName(					estilo.getFontName()					);
				
				HSSFCellStyle 	cellStyle 	= excelWorkbook.createCellStyle();
				cellStyle.setFont(font);
				cellStyle.setFillForegroundColor( 	estilo.getFillForegroundColor() 	);
				cellStyle.setFillPattern( 				estilo.getFillPattern() 			);
				cellStyle.setBorderBottom( 			estilo.getBorderBottom() 			);
				cellStyle.setBorderLeft( 				estilo.getBorderLeft() 				);
				cellStyle.setBorderRight( 				estilo.getBorderRight() 			);
				cellStyle.setBorderTop( 				estilo.getBorderTop() 				);
				cellStyle.setAlignment( 				estilo.getAlignment() 				);
				cellStyle.setVerticalAlignment( 		estilo.getVerticalAlignment() 	);
				
				cache.put(estilo, cellStyle );
				
			} else if( 	value instanceof Estilo[] 	){
				
				Estilo[]			estiloArray		= (Estilo[]) value;
				for(int j=0;j<estiloArray.length;j++){
					
					Estilo			estilo		= (Estilo) estiloArray[j];
				
					if( cache.containsKey(estilo) ){
						continue;
					}
						
					HSSFFont			font 			= excelWorkbook.createFont();
					font.setFontHeightInPoints(	estilo.getFontHeightInPoints()	);
					font.setColor(						estilo.getColor()						);
					font.setBoldweight(				estilo.getBoldweight()				);
					font.setFontName(					estilo.getFontName()					);
					
					HSSFCellStyle 	cellStyle 	= excelWorkbook.createCellStyle();
					cellStyle.setFont(font);
					cellStyle.setFillForegroundColor( 	estilo.getFillForegroundColor() 	);
					cellStyle.setFillPattern( 				estilo.getFillPattern() 			);
					cellStyle.setBorderBottom( 			estilo.getBorderBottom() 			);
					cellStyle.setBorderLeft( 				estilo.getBorderLeft() 				);
					cellStyle.setBorderRight( 				estilo.getBorderRight() 			);
					cellStyle.setBorderTop( 				estilo.getBorderTop() 				);
					cellStyle.setAlignment( 				estilo.getAlignment() 				);
					cellStyle.setVerticalAlignment( 		estilo.getVerticalAlignment() 	);
					
					cache.put(estilo, cellStyle );
				
				}
				
			}
		}
		return cache;
	}

	private String supressInvalidSheetNameChars(String sheetName){
		
		String caracteresProhibidos 	= "[\u0000\u0003:\\\\*\\?/\\[\\]]";
		String comillaInicial 			= "^[ \t]*'";
		String comillaFinal 			= "'[ \t]*$";
		
		sheetName = sheetName.replaceAll(caracteresProhibidos,"");
		sheetName = sheetName.replaceAll(comillaInicial,"");
		sheetName = sheetName.replaceAll(comillaFinal,"");
		
		return sheetName;
		
	}
	
}
