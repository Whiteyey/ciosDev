/**
 * 
 */
package com.app.cios.beans;

/**
 * @author Jhonatan Pacheco <jhonatanpachecohernandez@gmail.com>
 *
 */
public class SesUsuarioCiosDTO {

	private String userId;
	private String nombre;
	private String apellidoPaterno; 
	private String apellidoMaterno;
	private String nombreCompleto;
	private String clasificacion;
	private int idEstus;
	private String fechaAlta;
	private String nss;
	
	private String login;
	
	
	/**
	 * @param userId
	 * @param nombre
	 * @param apellidoPaterno
	 * @param apellidoMaterno
	 * @param nombreCompleto
	 * @param clasificacion
	 * @param idEstus
	 * @param fechaAlta
	 * @param nss
	 * 
	 */
	public SesUsuarioCiosDTO(String userId, String nombre, String apellidoPaterno, String apellidoMaterno,
			String nombreCompleto, String clasificacion, int idEstus, String fechaAlta, String nss) {
		super();
		this.userId = userId;
		this.nombre = nombre;
		this.apellidoPaterno = apellidoPaterno;
		this.apellidoMaterno = apellidoMaterno;
		this.nombreCompleto = nombreCompleto;
		this.clasificacion = clasificacion;
		this.idEstus = idEstus;
		this.fechaAlta = fechaAlta;
		this.nss = nss;
	}
	/**
	 * @param userId
	 * @param nombre
	 * @param apellidoPaterno
	 * @param apellidoMaterno
	 * @param nombreCompleto
	 * @param clasificacion
	 * @param idEstus
	 * @param fechaAlta
	 * @param nss
	 * @param login
	 */
	public SesUsuarioCiosDTO(String userId, String nombre, String apellidoPaterno, String apellidoMaterno,
			String nombreCompleto, String clasificacion, int idEstus, String fechaAlta, String nss, String login) {
		super();
		this.userId = userId;
		this.nombre = nombre;
		this.apellidoPaterno = apellidoPaterno;
		this.apellidoMaterno = apellidoMaterno;
		this.nombreCompleto = nombreCompleto;
		this.clasificacion = clasificacion;
		this.idEstus = idEstus;
		this.fechaAlta = fechaAlta;
		this.nss = nss;
		this.login = login;
	}
	public SesUsuarioCiosDTO() {
		// TODO Auto-generated constructor stub
	}
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	/**
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}
	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	/**
	 * @return the apellidoPaterno
	 */
	public String getApellidoPaterno() {
		return apellidoPaterno;
	}
	/**
	 * @param apellidoPaterno the apellidoPaterno to set
	 */
	public void setApellidoPaterno(String apellidoPaterno) {
		this.apellidoPaterno = apellidoPaterno;
	}
	/**
	 * @return the apellidoMaterno
	 */
	public String getApellidoMaterno() {
		return apellidoMaterno;
	}
	/**
	 * @param apellidoMaterno the apellidoMaterno to set
	 */
	public void setApellidoMaterno(String apellidoMaterno) {
		this.apellidoMaterno = apellidoMaterno;
	}
	/**
	 * @return the nombreCompleto
	 */
	public String getNombreCompleto() {
		return nombreCompleto;
	}
	/**
	 * @param nombreCompleto the nombreCompleto to set
	 */
	public void setNombreCompleto(String nombreCompleto) {
		this.nombreCompleto = nombreCompleto;
	}
	/**
	 * @return the clasificacion
	 */
	public String getClasificacion() {
		return clasificacion;
	}
	/**
	 * @param clasificacion the clasificacion to set
	 */
	public void setClasificacion(String clasificacion) {
		this.clasificacion = clasificacion;
	}
	/**
	 * @return the idEstus
	 */
	public int getIdEstus() {
		return idEstus;
	}
	/**
	 * @param idEstus the idEstus to set
	 */
	public void setIdEstus(int idEstus) {
		this.idEstus = idEstus;
	}
	/**
	 * @return the fechaAlta
	 */
	public String getFechaAlta() {
		return fechaAlta;
	}
	/**
	 * @param fechaAlta the fechaAlta to set
	 */
	public void setFechaAlta(String fechaAlta) {
		this.fechaAlta = fechaAlta;
	}
	/**
	 * @return the nss
	 */
	public String getNss() {
		return nss;
	}
	/**
	 * @param nss the nss to set
	 */
	public void setNss(String nss) {
		this.nss = nss;
	}
	/**
	 * @return the login
	 */
	public String getLogin() {
		return login;
	}
	/**
	 * @param login the login to set
	 */
	public void setLogin(String login) {
		this.login = login;
	}
	
	
	
	
	
	
	
}
