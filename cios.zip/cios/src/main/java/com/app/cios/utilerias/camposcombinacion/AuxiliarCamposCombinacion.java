//package com.app.cios.utilerias.camposcombinacion;
//
//import com.aspose.words.IMailMergeDataSource;
//
//import com.app.cios.utilerias.Registros;
//
///**
// * Clase Auxiliar de la clase <tt>CamposCombinacion</tt>. Esta clase es de uso privado
// * y no podr� ser extendida. Esta clase implmenta la interfaz: IMailMergeDataSource
// * de la API Apose.Words.
// *
// * @author jshernandez
// * @date 18/03/2014 07:31:58 p.m.
// *
// */
//class AuxiliarCamposCombinacion implements IMailMergeDataSource {
//
//	private Registros registros;
//	private String    tableName;
//	
//	AuxiliarCamposCombinacion(Registros registros){
//	  
//		this.registros 		= registros;
//		this.tableName 		= null;
//	}
//	
//	AuxiliarCamposCombinacion(Registros registros, String nombreTabla ){
//		this.registros 		= registros;
//		this.tableName 		= nombreTabla;
//	}
//	
//	/**
//	 * Regresa el nombre de la tabla con los campos de combinaci�n de correo (aquella definida dentro de los
//	 * tags: TableStart y TableEnd). Si el data source no contiene datos para una tabla se deber� regresar 
//	 * <tt>null</tt>.
//	 *
//	 * @return <tt>String</tt> con el nombre de la tabla.
//	 */
//	public String getTableName() {
//		return this.tableName;
//	}
//
//	/**
//	 * Se ejecuta para "extraer" los registros que se van a leer.
//	 * 
//	 * @return <tt>true</tt> en caso de que haya m�s registros por leer y <tt>false</tt> en caso
//	 * contrario.
//	 */
//	public boolean moveNext() {
//		return this.registros.next();
//	}
//
//	/**
//	 * Guarda el valor del campo solicitado con nombre <tt>fieldName</tt>, en la primera posicion del array <tt>String[]</tt>.
//	 *
//	 * @return <tt>true</tt> si el campo con nombre <tt>fieldName</tt> fue encontrado y <tt>false</tt> en caso contrario (tambien
//	 * deber� regresarse null en fieldValue[0]).
//	 */
//	public boolean getValue(String fieldName, Object[] fieldValue) {
//		return this.registros.getValue(fieldName, fieldValue);
//	}
//
//	/**
//	 * Devuelve Data Source hijo. Se usa cuando se encuentra una tabla con campos de combinaci�n de correo anidada dentro de otra
//	 * tabla.
//	 *
//	 * @return Objeto de tipo <tt>IMailMergeDataSource</tt>. Si no se tienen tablas anidadas deber� regresar <tt>null</tt>.
//	 *
//	 */
//	public IMailMergeDataSource getChildDataSource(String tableName) {
//		return null;
//	}
//	
//}
