package com.app.cios.utilerias.correo;

import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;

import java.util.*;

import java.sql.*;

import com.app.cios.utilerias.ParametrosGlobalesApp;
import com.app.cios.utilerias.ServiceLocator;

import com.app.cios.utilerias.archivo.ArchivoBean;

import org.apache.commons.logging.Log;

/**
 *  Clase que agiliza el env�o de correos, mediante el uso la interfaz IMensajeCorreo.
 * 
 * @author jshernandez
 * @since 10/04/2014 04:44:28 p.m.
 */
public class Correo {

	private static final String EMBEBIDO	= "E";
	
	public Correo(IMensajeCorreo mensajeCorreo){
		this.mensajeCorreo = mensajeCorreo;
		// Se habilita por default la depuraci�n de los mensajes de correo.
		this.debug			 = true; 
	}
	
	// ATRIBUTOS ASOCIADOS A LA INTERFACE IMensajeCorreo
	
	private IMensajeCorreo mensajeCorreo;

	// METODOS ASOCIADOS A LA INTERFACE IMensajeCorreo
	
	//Variable para enviar mensajes al log.
	private static final Log log = ServiceLocator.getInstance().getLog(Correo.class);
	
	/**
	 * Este m�todo se encarga de enviar correos en base a la funcionalidad definida en la interface IMensajeCorreo.
	 *
	 * @param msg <tt>String[]</tt> con el detalle del mensaje en el elemento 0, por ejemplo cuando falla la 
	 * validacion, el env�o, etc.
	 * @param detalleValidacion <tt>List</tt>, con el detalle de los "errores" encontrados en la 
	 * validaci�n.
	 * @param mensajeCorreoBean <tt>MensajeCorreoBean[]</tt> con los datos del correo enviado.
	 *
	 * @return <tt>true</tt> si el env�o del correo fue exitoso y <tt>false</tt> en caso contrario.
	 *
	 */
	public boolean enviar( LinkedHashMap detalleValidacion, MensajeCorreoBean[] mensajeCorreoBean, String[] msg ){
		
		boolean 				exito							= true;
		MensajeCorreoBean vistaMensajeCorreoBean	= null;
		
		try {
	
			// Preparar Bean con el detalle de la informaci�n del correo que ser� enviado
			if( !mensajeCorreo.construyeVistaMensajeCorreoBean( mensajeCorreoBean, msg ) ){ 
				msg[0] 				= "El correo no pudo ser enviado, debido a que ocurri� un error al construir el cuerpo del mensaje: " + msg[0];
				mensajeCorreoBean[0] = null;
				exito  					= false;
				return exito;
			}
			
			// Validar que el Bean de Mensaje de Correo construido cumpla con los requisitos
			vistaMensajeCorreoBean  = mensajeCorreoBean[0];	
			if( !mensajeCorreo.validaParametrosCorreo( vistaMensajeCorreoBean, detalleValidacion, msg ) ){
				//msg[0] 					= msg[0]; // "El correo no pudo ser enviado. " + msg[0];
				mensajeCorreoBean[0] = null;
				exito 					= false;
				return exito;
			}
			
			// Enviar el correo.
			// Agregar nombre del usuario al remitente.
			String remitente 			= vistaMensajeCorreoBean.getNombreUsuario() + "<" + vistaMensajeCorreoBean.getRemitente() +">";
			// Debug info: queda pendiente adaptar lista de archivos adjuntos.
			Correo.enviar(
				remitente, 													// From:
				vistaMensajeCorreoBean.getDestinatarios(), 		// To:
				vistaMensajeCorreoBean.getCcDestinatarios(),  	// CC: 
				vistaMensajeCorreoBean.getBccDestinatarios(),	// BCC: 
				vistaMensajeCorreoBean.getAsunto(), 				// T�tulo del Correo
				vistaMensajeCorreoBean.fetchCuerpoCorreo(0),		// Cuerpo del Mensaje
				vistaMensajeCorreoBean.getArchivos(),				// Archivos Adjuntos o Embebidos al mensaje del correo.
				this.debug
			);

			// Guarda una copia del mensaje de correo a ser enviado
			if( !mensajeCorreo.guardarVistaMensajeCorreoBean( vistaMensajeCorreoBean, msg ) ){
				msg[0] 					= "El correo fue enviado con �xito, pero no pudo ser guardado: " + msg[0];
				mensajeCorreoBean[0] = null;
				exito  					= false;
				return exito;
			}
			
			// Regresar el bean con la informaci�n del correo enviado.
			msg[0]					= null;
			mensajeCorreoBean[0] = vistaMensajeCorreoBean;
			
		} catch(Exception e){
			
			log.error("enviar(Exception)");
			log.error("detalleValidacion = <" + detalleValidacion + ">");
			log.error("mensajeCorreoBean = <" + mensajeCorreoBean + ">");
			log.error("msg               = <" + msg               + ">");
			if( vistaMensajeCorreoBean != null ){
			   log.error("vistaMensajeCorreoBean.dump()");
				vistaMensajeCorreoBean.dump();
			}
			e.printStackTrace();
			
			msg[0] 					= "Fall� en env�o del Correo: "+ e.getMessage();
			mensajeCorreoBean[0] = null;
			exito 					= false;
			
		} 
		
		return exito;
		
	}
	
	
	// ATRIBUTOS AUXILIARES DE LA CLASE
	
	private boolean debug = false;
	
	// METODOS AUXILIARES DE LA CLASE
	
	/**
	 * Habilita el envio a la consola de mensajes de Depuracion
	 * en el siguiente metodo: sendMail() 
	 */
	public void enableDebug(){
		this.debug = true;
	}
	
	/**
	 * Deshabilita el envio a la consola de mensajes de Depuracion
	 * en el siguiente metodo: sendMail() 
	 */
	public void disableDebug(){
		this.debug = false;
	}
	
	public static void enviar(
			String	remitente, 						// From:
			String	destinatarios, 				// To:
			String	copiaDestinatarios,   		// CC: 
			String	copiaOcultaDestinatarios,	// BCC: 
			String	tituloMensaje, 
			String	contenidoMensaje, 
			List		listaDeArchivos,    			// Archivos Adjuntos o Embebidos al mensaje del correo.
			boolean  debug
		) throws Exception {				
	
		try {

			String 	 	 mailHost 	= ParametrosGlobalesApp.getInstance().getParametro("SMTP_HOST");
			
			Properties props 		= System.getProperties();
			props.put("mail.smtp.host", mailHost);
			
			Session mailSession = Session.getDefaultInstance(props, null);
			mailSession.setDebug(debug);
		
			MimeMessage message = new MimeMessage(mailSession);
			message.setSubject(tituloMensaje,"UTF-8");
			if( remitente != null && remitente.indexOf("<") != -1 ){ // => mensaje = "Nombre del Ususario<direccion@decorreo.com>"
				
				int 		indiceMenorQue = remitente.indexOf("<");
				String 	nombreUsuario	= remitente.substring(0,indiceMenorQue);
				
				int 		indiceMayorQue = remitente.indexOf(">");
				remitente					= remitente.substring(indiceMenorQue+1,indiceMayorQue);
				
				message.setFrom( new InternetAddress(remitente,nombreUsuario) );
			} else {
				message.setFrom( new InternetAddress(remitente) );
			}
			message.addRecipients(Message.RecipientType.TO, destinatarios);
			if(copiaDestinatarios != null && !copiaDestinatarios.equals("")){
				message.addRecipients(Message.RecipientType.CC, copiaDestinatarios.replaceAll(",",";"));							
			}
			if(copiaOcultaDestinatarios != null && !copiaOcultaDestinatarios.equals("")){
				message.addRecipients(Message.RecipientType.BCC, copiaOcultaDestinatarios.replaceAll(",",";"));							
			}
			MimeMultipart multipart = new MimeMultipart("related");
		
			// Contenido
			BodyPart messageBodyPart = new MimeBodyPart();   
			messageBodyPart.setContent(contenidoMensaje, "text/html; charset=\"UTF-8\""); // contenidoMensaje = "<H1>Hello</H1><img src=\"cid:imagen_adjunta_id\">";
		
			multipart.addBodyPart(messageBodyPart);
				 				  
			// Archivos adjuntos o embebidos
			if(listaDeArchivos != null){
				
				for(int indice=0;indice<listaDeArchivos.size();indice++){
										
					ArchivoBean 	archivoBean  = (ArchivoBean) listaDeArchivos.get(indice);
					messageBodyPart = new MimeBodyPart();
					// FILE_FULL_PATH
					DataSource fds  = new FileDataSource(archivoBean.getRutaAbsoluta()); // FILE_FULL_PATH: { "/home/images/images.jpg", "/root/00Comunes/css/acuses.css" }
					messageBodyPart.setDataHandler(new DataHandler(fds));
					// FILE_ID
					if( EMBEBIDO.equals( archivoBean.getTipo() ) ){
						messageBodyPart.setHeader("Content-ID","<"+archivoBean.getTituloArchivo()+">"); 		// FILE_ID:  { imagen_adjunta_id, acuses_css } 
					}																										// HTML TAG: { "<img src=\"cid:imagen_adjunta_id\">", "<link href=\"cid:acuses_css\" rel=\"stylesheet\" type=\"text/css\"  />" } 
					// FILE_NAME
					String fileName = archivoBean.getTituloArchivo();										// "Mi Archivo.pdf"
					if( fileName != null && !fileName.trim().equals("")){
						messageBodyPart.setFileName(fileName); 				// NOMBRE DEL ARCHIVO ADJUNTO
					}else{
						messageBodyPart.setFileName(fds.getName()); 			// NOMBRE DEL ARCHIVO ADJUNTO
					}
					// TODO: queda opcional validacion donde se supriman los siguientes caracteres invalidos del nombre del archivo:
					// fileName.replaceAll("[\\\\/:\\*\\?\"<>\\|]","") 
					// TODO: Tambi�n queda opcional restringir longitud m�xima del nombre del archivo a 256 caracteres.
					// AGREGAR MENSAJE
					multipart.addBodyPart(messageBodyPart);// add it
	
				}
				
			}
			
			// Poner todo junto
			message.setContent(multipart);
		
			// Enviar el mensaje
			Transport.send(message);
			
		}catch(Exception ex){
			
			log.error("Correo::enviar(Exception)");
			log.error("");
			log.error("El siguiente correo, NO SERA ENVIADO; datos del correo:");
			log.error("   De:            " + remitente);
			log.error("   Para:          " + destinatarios);
			log.error("   Copia:         " + copiaDestinatarios);
			log.error("   Copia Oculta:  " + copiaOcultaDestinatarios);
			log.error("   Titulo:        " + tituloMensaje);
			log.error("--------------------------------------------------------------------------");
			log.error(contenidoMensaje);
			log.error("--------------------------------------------------------------------------");
			log.error("   Archivos adicionales: ");
			if(listaDeArchivos == null || listaDeArchivos.size() == 0){
				log.error("No hay archivos adicionales ");
			}
			if(listaDeArchivos != null ){
				for(int indice=0;indice<listaDeArchivos.size();indice++){
					
					log.error("   Archivo["+indice+"]:");
					ArchivoBean datos  = (ArchivoBean) listaDeArchivos.get(indice);
					if( EMBEBIDO.equals( datos.getTipo() ) ){
						log.error("      FILE_ID        = <" + datos.getTituloArchivo() + ">");
					} else {
						log.error("      FILE_ID        = <>");
					}
					log.error("      FILE_NAME      = <" + datos.getTituloArchivo()    + ">");
					log.error("      FILE_FULL_PATH = <" + datos.getRutaAbsoluta() 	 + ">");
					
				}
			}
			log.error("");
					
			ex.printStackTrace();	
					
			throw ex;
			
		}
				  
	}
					
}
