package com.app.cios.utilerias.archivo;

import com.app.cios.utilerias.ServiceLocator;
import com.app.cios.utilerias.Validaciones;
import org.apache.commons.logging.Log;

/**
 * Bean que facilita el manejo de archivos con propietario.
 * @author jshernandez
 * @since 21/04/2014 12:57:30 p.m.
 */
public class ArchivoBean {

	// VARIABLES AUXILIARES
	
	private static final Log log = ServiceLocator.getInstance().getLog(ArchivoBean.class);

	// ATRIBUTOS
	
	/**
	 * Nombre con el que el archivo ser� presentado al usuario. Debe tener extension.
	 */
	private String tituloArchivo;
	
	/**
	 *  Ruta absoluta al archivo
	 */
	private String rutaAbsoluta;

	/**
	 * Tipo de archivo. Se usa en el env�o de correos: 'A' Adjunto � 'E', Embebido.
	 * Podr�a usarse por ejemplo, para almacenar al valor de SGAPS_BIT_ENVIO_EMAIL_ARCH.CS_TIPO. 
	 */
	private String tipo;
	
	/**
	 * Id del Archivo, generalmente este par�metro se asigna cuando el archivo ya ha sido
	 * guardado en la Base de Datos.
	 * Podr�a usarse por ejemplo, para almacenar al valor de SGAPS_BIT_ENVIO_EMAIL_ARCH.IC_ENVIO_EMAIL_ARCH.
	 */
	private Object id;
	
	// GETTERS / SETTERS

	public String getTituloArchivo() {
		return tituloArchivo;
	}

	public void setTituloArchivo(String tituloArchivo) {
		this.tituloArchivo = tituloArchivo;
	}

	public String getRutaAbsoluta() {
		return rutaAbsoluta;
	}

	public void setRutaAbsoluta(String rutaAbsoluta) {
		this.rutaAbsoluta = rutaAbsoluta;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public Object getId() {
		return id;
	}

	public void setId(Object id) {
		this.id = id;
	}

	// M�TODOS AUXILIARES.
	
	public void dump(){
		
		log.error("ArchivoBean.tituloArchivo = <" + tituloArchivo + ">");
		log.error("ArchivoBean.rutaAbsoluta  = <" + rutaAbsoluta  + ">");
		log.error("ArchivoBean.tipo  			 = <" + tipo          + ">");
		log.error("ArchivoBean.id   			 = <" + id            + ">");
		
	}
	
	/**
	 * Devuelve la ruta relativa al directorio temporal con respecto al directorio raiz proporcionado
	 * en el par�metro <tt>directorioRaiz</tt>.
	 */
	public String getDirectorioTemporal( String directorioRaiz ){
			
		if( Validaciones.esVacio(this.rutaAbsoluta)){
			return null;
		}
		
		int				lastIndexPathSeparator	= this.rutaAbsoluta.lastIndexOf("/");
		int 				lastIndexOfBackSlash 	= this.rutaAbsoluta.lastIndexOf("\\");		
		
		if( lastIndexOfBackSlash > lastIndexPathSeparator ){
			 lastIndexPathSeparator = lastIndexOfBackSlash;
		}
		
		// Agregar directorio del archivo
		String fileDirectory = this.rutaAbsoluta.substring(0,lastIndexPathSeparator+1);
		// Remover la seccion correspondiente al web root
		fileDirectory = fileDirectory.replaceFirst( "^\\Q" + directorioRaiz + "\\E", "");
		
		return fileDirectory;
		
	}
	
	/**
	 * Devuelve la ruta relativa al archivo con respecto al directorio raiz proporcionado
	 * en el par�metro <tt>directorioRaiz</tt>.
	 */
	public String getRutaRelativa( String directorioRaiz ){
			
		if( Validaciones.esVacio(this.rutaAbsoluta)){
			return null;
		}
				
		// Agregar directorio del archivo
		String rutaRelativa = this.rutaAbsoluta;
		// Remover la seccion correspondiente al web root
		rutaRelativa = rutaRelativa.replaceFirst( "^\\Q" + directorioRaiz + "\\E", "");
		
		return rutaRelativa;
		
	}
	
	/**
	 * Devuelve el nombre del archivo sin el propietario (<tt>loginUsuario</tt>), siempre
	 * y cuanndo este coincida con el indicado en el nombre del archivo.
	 */
	public String getNombreArchivo( String loginUsuario ){
			
		if( Validaciones.esVacio(this.rutaAbsoluta)){
			return null;
		}
		
		int				lastIndexPathSeparator	= this.rutaAbsoluta.lastIndexOf("/");
		int 				lastIndexOfBackSlash 	= this.rutaAbsoluta.lastIndexOf("\\");		
		
		if( lastIndexOfBackSlash > lastIndexPathSeparator ){
			 lastIndexPathSeparator = lastIndexOfBackSlash;
		}
				
		// Agregar nombre protegido del archivo
		String fileName = this.rutaAbsoluta.substring(lastIndexPathSeparator+1);
		if( !Validaciones.esVacio(loginUsuario) && fileName.matches( "^\\Q" + loginUsuario + ".\\E.*" ) ){
			fileName = fileName.substring( loginUsuario.length() + 1 );
		} 
		
		return fileName;
		
	}
	
	
	/**
	 * Devuelve la ruta relativa del archivo sin considerar el propietario ni el directorio
	 * raiz, como por ejemplo el del web context root.
	 */
	public String getRutaRelativa(String directorioRaiz, String propietario){
		
		StringBuffer 	ruta 							= new StringBuffer();
	
		int				lastIndexPathSeparator	= this.rutaAbsoluta.lastIndexOf("/");
		int 				lastIndexOfBackSlash 	= this.rutaAbsoluta.lastIndexOf("\\");		
		
		if( lastIndexOfBackSlash > lastIndexPathSeparator ){
			 lastIndexPathSeparator = lastIndexOfBackSlash;
		}
		
		// Agregar directorio del archivo
		String fileDirectory = this.rutaAbsoluta.substring(0,lastIndexPathSeparator+1);
		// Remover la seccion correspondiente al web root
		fileDirectory = fileDirectory.replaceFirst( "^\\Q" + directorioRaiz + "\\E", "");
		ruta.append(fileDirectory);
		
		// Agregar nombre protegido del archivo
		String fileName		= this.rutaAbsoluta.substring(lastIndexPathSeparator+1);
		if( !Validaciones.esVacio(propietario) && fileName.matches( "^\\Q" + propietario + ".\\E.*" ) ){
			ruta.append(fileName.substring( propietario.length() + 1 ));
		} else {
			ruta.append(fileName);
		}
		
		return ruta.toString();
		
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result
				+ ((rutaAbsoluta == null) ? 0 : rutaAbsoluta.hashCode());
		result = prime * result + ((tipo == null) ? 0 : tipo.hashCode());
		result = prime * result
				+ ((tituloArchivo == null) ? 0 : tituloArchivo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ArchivoBean other = (ArchivoBean) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (rutaAbsoluta == null) {
			if (other.rutaAbsoluta != null)
				return false;
		} else if (!rutaAbsoluta.equals(other.rutaAbsoluta))
			return false;
		if (tipo == null) {
			if (other.tipo != null)
				return false;
		} else if (!tipo.equals(other.tipo))
			return false;
		if (tituloArchivo == null) {
			if (other.tituloArchivo != null)
				return false;
		} else if (!tituloArchivo.equals(other.tituloArchivo))
			return false;
		return true;
	}

		
}
