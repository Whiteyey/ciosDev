/**
 * 
 */
package com.app.cios.web.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.app.cios.beans.SesUsuarioCiosDTO;

/**
 * 
 * @author JR Alvarado <jr.alvaradogarcia@gmail.com>
 *
 */
@Controller
public class BalanceController {
	
	@RequestMapping(value = "/balance", method = RequestMethod.GET)
	public String mainPage(ModelMap model,HttpServletRequest request) {

		ModelAndView aux= com.app.cios.utilerias.LoginUtil.isValidLogin(request);
		if(aux!=null){
//			model.addAttribute("title","Balance");
//			model.addAttribute("user", "yey");
//			
//			return "main/balance";
			return "redirect:/";
		}
		HttpSession session = request.getSession();

		SesUsuarioCiosDTO u = (SesUsuarioCiosDTO) session.getAttribute("sesUsuario");

//		model.addAttribute("titlePage", "Main");
		model.addAttribute("title","Balance");
		model.addAttribute("user", u.getNombreCompleto());
		
		return "main/balance";
	}
}

