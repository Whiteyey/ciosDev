package com.app.cios.utilerias.correo;

import java.util.LinkedHashMap;
import java.util.List;

/**
 * Interface que se utiliza para facilitar el env�o de correos, solicitando
 * al usuario, unicamente que defina los m�todos siguientes.
 * 
 * @author jshernandez
 * @date 10/04/2014 12:00:17 p.m.
 */
public interface IMensajeCorreo {

	/**
	 *
	 * Este m�todo toma el Bean de Mensaje Correo, generando uno nuevo 
	 * que cumpla con los requisitos para ser enviado por correo: Todo el 
	 * cuerpo del mensaje deber� venir con formato HTML en el primer elemento del campo:
	 * cuerpoCorreo. Cada elemento de la lista de archivos, debe tener las siguientes 
	 * propiedades: FILE_ID, FILE_NAME y FILE_FULL_PATH.
	 * 
	 * Para que se pueda realizar el env�o de correos este m�todo deber� regresar 
	 * <tt>true</tt>.
	 *
	 * @param mensajeCorreoBean <tt>MensajeCorreoBean[]</tt> con el detalle del correo a enviar.
	 * @param msg <tt>String[]</tt> con algun mensaje, por ejemplo cuando
	 * falla la operaci�n de guardado.
	 *
	 * @return <tt>true</tt> si la operaci�n es exitosa y <tt>false</tt> en caso 
	 * contrario.
	 *
	 */
	boolean construyeVistaMensajeCorreoBean( MensajeCorreoBean[] mensajeCorreoBean, String[] msg );

	/**
	 * Este m�todo debe regresar <tt>true</tt> si la validaci�n de los par�metros
	 * del Bean de MesajeCorreo es exitosa y <tt>false</tt> en caso contrario.
	 *
	 * Para que se pueda realizar el env�o de correos este m�todo deber� regresar 
	 * <tt>true</tt>.
	 *
	 * @param vistaMensajeCorreoBean <tt>MensajeCorreoBean</tt> con el detalle del correo a enviar.
	 * @param detalleValidacion <tt>List</tt>, con el detalle de los "errores" encontrados en la 
	 * validaci�n.
	 * @param msg <tt>String[]</tt> con algun mensaje, por ejemplo cuando
	 * falla la operaci�n de validacion.
	 *
	 * @return <tt>true</tt> si la validaci�n es exitosa y <tt>false</tt> en caso 
	 * contrario.
	 */
	boolean validaParametrosCorreo( MensajeCorreoBean vistaMensajeCorreoBean, LinkedHashMap detalleValidacion, String[] msg );
	
	/**
	 * Guarda en Bit�cora el contenido del Bean de MensajeCorreo proporcionado en el par�metro: 
	 * <tt>vistaMensajeCorreoBean</tt>
	 *
	 * Para que se pueda realizar el env�o de correos este m�todo deber� regresar 
	 * <tt>true</tt>.
	 *
	 * @param vistaMensajeCorreoBean <tt>MensajeCorreoBean</tt> con el detalle del correo a enviado.
	 * @param msg <tt>String[]</tt> con algun mensaje, por ejemplo cuando
	 * falla la operaci�n de guardado.
	 *
	 * @return <tt>true</tt> si el guardado del Bean fue exitoso y <tt>false</tt> 
	 * en caso contrario.
	 */
	boolean guardarVistaMensajeCorreoBean( MensajeCorreoBean vistaMensajeCorreoBean, String[] msg );
		
}
