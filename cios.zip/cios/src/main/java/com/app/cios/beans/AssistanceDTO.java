package com.app.cios.beans;

public class AssistanceDTO {

	private int idCliente;
	private int idElement;
	private String date;
	private String turn;
	
	private String nameElement;
	
	public AssistanceDTO(){}

	public AssistanceDTO(int idCliente, int idElement,
			String date, String turn){
		this.idCliente = idCliente;
		this.idElement = idElement;
		this.date = date;
		this.turn = turn;
	}

	public AssistanceDTO(String nameElement, int idElement,
			String date, String turn){
		this.nameElement = nameElement;
		this.idElement = idElement;
		this.date = date;
		this.turn = turn;
	}
	
	public int getIdCliente() {
		return idCliente;
	}

	public void setIdCliente(int idCliente) {
		this.idCliente = idCliente;
	}

	public int getIdElement() {
		return idElement;
	}

	public void setIdElement(int idElement) {
		this.idElement = idElement;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getTurn() {
		return turn;
	}

	public void setTurn(String turn) {
		this.turn = turn;
	}

	public String getNameElement() {
		return nameElement;
	}

	public void setNameElement(String nameElement) {
		this.nameElement = nameElement;
	}
	
	
}
