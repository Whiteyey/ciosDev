package com.app.cios.utilerias.archivoxls;

public class Instruccion {

	public final static Instruccion SALTO_LINEA 		= new Instruccion(101);
	public final static Instruccion OFFSET 			= new Instruccion(102);
	public final static Instruccion COLSPAN 			= new Instruccion(103);
	public final static Instruccion ESTILO 			= new Instruccion(104);
	public final static Instruccion HOJA_NUEVA 		= new Instruccion(105);
	public final static Instruccion RESET_FORMATO	= new Instruccion(106);
	// public final static EXCLUIR_COLUMNAS 			= new Instruccion(107); // Nota: Para implementacion futura
	// public final static RENDERER   					= new Instruccion(108); // Nota: Se podr�a utilizar para aplicar estilos 
																									// especificos para ciertos valores, se deja para
																									// una implementaci�n futura.
	
	private int clave;

	private Instruccion(int clave) {
		this.clave = clave;
	}
	
	public int hashCode() {
	
		final int prime = 31;
		int result = 1;
		result = prime * result + clave;
		return result;
		
	}

	public boolean equals(Object obj) {
	
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Instruccion other = (Instruccion) obj;
		if (clave != other.clave)
			return false;
		return true;
		
	}
		
}
